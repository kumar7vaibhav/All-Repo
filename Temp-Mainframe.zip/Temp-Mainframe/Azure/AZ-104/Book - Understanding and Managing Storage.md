---
exam: 104
module: storage 
---
# Azure Storage Account Services
[Introduction to Azure Storage](https://learn.microsoft.com/en-us/azure/storage/common/storage-introduction)
1. Blob
2. Elastic SAN
3. Queues
4. Tables
5. Files
6. Disks
7. Container Storage
8. NetApp Files

| Feature                     | Description                                                                                                                                                                                                                                                                                                                                                                                                                                                |
| --------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **Azure Blobs**             | Allows unstructured data to be stored and accessed at a massive scale in block blobs.                                                                                                                                                                                                                                                                                                                                                                      |
| **Azure Elastic SAN**       | Azure Elastic SAN is a fully integrated solution that simplifies deploying, scaling, managing, and configuring a SAN, while also offering built-in cloud capabilities like high availability.                                                                                                                                                                                                                                                              |
| **Azure Queues**            | Allows for asynchronous message queueing between application components.                                                                                                                                                                                                                                                                                                                                                                                   |
| **Azure Tables**            | Allows you to store structured NoSQL data in the cloud, providing a key/attribute store with a schemaless design.                                                                                                                                                                                                                                                                                                                                          |
| **Azure Files**             | Offers fully managed cloud file shares that you can access from anywhere via the industry standard [Server Message Block (SMB) protocol](https://learn.microsoft.com/en-us/windows/win32/fileio/microsoft-smb-protocol-and-cifs-protocol-overview), [Network File System (NFS) protocol](https://en.wikipedia.org/wiki/Network_File_System), and [Azure Files REST API](https://learn.microsoft.com/en-us/rest/api/storageservices/file-service-rest-api). |
| **Azure Disks**             | Allows data to be persistently stored and accessed from an attached virtual hard disk.                                                                                                                                                                                                                                                                                                                                                                     |
| **Azure Container Storage** | Azure Container Storage is a volume management, deployment, and orchestration service that integrates with Kubernetes and is built natively for containers.                                                                                                                                                                                                                                                                                                |
| **Azure NetApp Files**      | Offers a fully managed, highly available, enterprise-grade NAS service that can handle the most demanding, high-performance, low-latency workloads requiring advanced data management capabilities.                                                                                                                                                                                                                                                        |
# Types of Storage Accounts
[Storage account overview](https://learn.microsoft.com/en-us/azure/storage/common/storage-account-overview)
Azure Storage currently offers several different types of storage accounts,
![[Pasted image 20230519164704.png]]

| Type of storage account     | Supported storage services                                                                | Redundancy options                            |
| :-------------------------- | ----------------------------------------------------------------------------------------- | --------------------------------------------- |
| Standard general-purpose v2 | Blob Storage (including Data Lake Storage), Queue Storage, Table Storage, and Azure Files | LRS / GRS / RA-GRS <br>  <br>ZRS/GZRS/RA-GZRS |
| Premium block blobs         | Blob Storage (including Data Lake Storage)                                                | LRS / ZRS                                     |
| Premium file shares         | Azure Files                                                                               | LRS / ZRS                                     |
| Premium page blobs          | Page blobs only                                                                           | LRS / ZRS                                     |
- Data Lake Storage is a set of capabilities dedicated to big data analytics, built on Azure Blob Storage.
> You can't change a storage account to a different type after it's created.
# Azure Disk Storage
- Disks that are used for VMs are stored in Azure Blob storage as page blobs.
- VM has two disks.
	- The actual operating system. (VHD)
	- Temporary data disk
- Two different performance tiers that Azure offers
	- Standard disk
	- Premium disk
- Unmanaged vs Managed Disks
	- Manged disks are the default disk type and automatically created storage account for you.
	- Unmanaged disks are legacy disks. Require manually storage account creation.
# Storage Access Tiers
How frequently data is accessed.
## Hot
- In Active use.
- Storage cost is higher.
- Reading cost is lower.
## Cool
- Most suitable for storing data that is not accessed frequently (less than once in 30 days.)
- Lower storage cost.
- Higher access cost
## Cold
- For storing data that is rarely accessed or modified, but still requires fast retrieval. 
- Should be stored for a minimum of 90 days.
- Lower storage costs and higher access costs compared to the cool tier.
## Archive
- Set on the blob level and not on the storage level. 
- Lowest cost of storing data.
- Highest cost of accessing data.
- Data should remain archived for 180 days.
- [Blob rehydration from the archive tier](https://learn.microsoft.com/en-gb/azure/storage/blobs/archive-rehydrate-overview?tabs=azure-portal)
# Redundancy
Redundancy refers to the number of copies of data that are available at any time.

## Locally Redundant Storage
- 3 Copies within a single physical location.
- Copied synchronously within the location
- Cheapest
- ![[Pasted image 20230625194648.png]]

## Zone-Redundant Storage
- Data copied asynchronously across three Azure Availability Zones.
- Protects data at data center layer.
- Recommended for High Availability.
- ![[Pasted image 20230625195310.png]]

## Geo-Redundant Storage
- Protect against a region failure.
- Protection within a single data center for each region.
- You get 6 copies of data.
- Asynchronous.
- ![[Pasted image 20230625195606.png]]

## Geo-Zone-Redundant Storage
- Protect against a region failure while also offering HA and protection within each region.
- 6 copies.
- ![[Pasted image 20230625195704.png]]

# Point-In-Time Restoration
Restore a specific version of a resource, such as a virtual machine or a database, to a previous state.

# Soft Delete for Blob Storage
Soft delete for Azure Blob Storage is a feature that allows you to recover deleted blobs or containers within a specified retention period.
