
---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Azure Kubernetes Service Terminology
> Azure operates as a hosted Kubernetes service and performs critical functions like health monitoring and maintenance. 

AKS employs components like - 
- Nodes
- Pods
- Pools
![[Pasted image 20230504180355.png]]
## Pools
Group of notes that have identical configuration
## Nodes
Individual virtual machine that run containerized applications
## Pods
Single instance of an application. Can have multiple containers.
## Containers
Executable image that contains software and all of its dependencies.
## Deployment
One or more identical pods managed by Kubernetes
## Manifest
YAML file that describes the deployment.

# AKS cluster and node architecture
> An Azure Kubernetes Service cluster is divided into two components: Azure-managed nodes and customer-managed nodes.

Azure-managed nodes provide the core Kubernetes services and orchestration of application workloads in your AKS cluster. Customer-managed nodes run your application workloads in your AKS cluster.
**![[Pasted image 20230504181139.png]]**

# AKS Networking
> Kubernetes nodes are connected to a virtual network, which provides inbound and outbound connectivity for pods.

- The kube-proxy component runs on each node to provide the network features.
- Network policies configure security and filtering of the network traffic for pods.
- Network traffic can be distributed by using a load balancer.
- Complex routing of application traffic can be achieved with Ingress Controllers.

# Azure Kubernetes Service
> Azure platform helps to simplify virtual networking for Azure Kubernetes Service clusters

Service Types - 
- Cluster IP
- NodePort
- LoadBalancer
- ExternalName

# AKS Storage
> Four Core Concepts - 
> 1. AKS: storage volumes
> 2. Persistent volumes
> 3. Storage classes
> 4. Volume claims.

![[Pasted image 20230504182924.png]]

## Storage Volumes
> Storage volumes represent a way to store, retrieve, and persist data across pods and through the application lifecycle.

- Create them manually or have Kubernetes automatically create them.
- Storage volumes can use Azure Disks or Azure Files

## Persistent Volumes
> A persistent volume (`PersistentVolume`) is a storage resource that's created and managed by the Kubernetes API that can exist beyond the lifetime of an individual pod.

- Use Azure Disks or Azure Files to provide a persistent volume.
- Can be statically created by a cluster administrator, or dynamically created by the Kubernetes API server.
- Dynamic provisioning uses a `StorageClass` type to identify what kind of Azure Storage needs to be created.

## Storage Classes
> To define different tiers of storage, such as Premium and Standard, you can configure a `StorageClass` type.

The `reclaimPolicy` definition controls the behavior of the underlying Azure Storage resource when the pod is deleted and the persistent volume might no longer be required.

| StorageClass Type | Description                |
| ----------------- | -------------------------- |
| default           | StandardSSD                |
| managed-preminum  | Preminum with managed disk |
| azurefile         | Standard                   |
| azurefile-premium | Premium with Azure Files   | 

## Persistent Volume Claims
> The Kubernetes API server can dynamically provision the underlying Azure storage resource if no existing resource can fulfill the claim based on the defined StorageClass.

A persistent volume claim (`PersistentVolumeClaim`) requests either Azure Disks or Azure Files storage of a particular `StorageClass`, access mode, and size.

![[Pasted image 20230504190723.png]]

## AKS Scaling
> The process of scaling involves adjusting the compute resources allocated for your application instances to meet workload demands.

![[Pasted image 20230504190906.png]]

# AKS Burst Scaling to Azure Container Instances
> Automatically adds extra computing power from ACI when your AKS workload needs it.

![[Pasted image 20230504191815.png]]

Allows AKS to automatically and seamlessly scale out to ACI when additional compute capacity is needed for short periods of time. This helps to optimize resource utilization and reduce costs by scaling workloads on-demand, while ensuring high availability and performance.

- The Virtual Kubelet component is installed in your AKS cluster. The component pre1sents your container instance as a virtual Kubernetes node.
- Kubernetes schedules pods to run as container instances through virtual nodes, rather than pods on virtual machine nodes directly in your AKS cluster.

> [!note] Further Reading
>## Learn more
>-   Read about [Kubernetes](https://kubernetes.io/).
>-   Peruse [Azure Kubernetes Service documentation](https://learn.microsoft.com/en-us/azure/aks/).
>-   Get started with [Azure Kubernetes Service](https://learn.microsoft.com/en-us/azure/aks/intro-kubernetes).
>-   Review [network concepts for applications in Azure Kubernetes Service](https://learn.microsoft.com/en-us/azure/aks/concepts-network).
>-   Explore [storage options for applications in Azure Kubernetes Service](https://learn.microsoft.com/en-us/azure/aks/concepts-storage).
>-   Review [security concepts for applications and clusters in Azure Kubernetes Service](https://learn.microsoft.com/en-us/azure/aks/concepts-security)
>-   Scale the [node count in an Azure Kubernetes Service cluster](https://learn.microsoft.com/en-us/azure/aks/scale-cluster).
>-   Execute burst scaling to [Azure Container Instances from Azure Kubernetes Service](https://learn.microsoft.com/en-us/azure/aks/concepts-scale#burst-to-azure-container-instances)
>## Learn more with self-paced training
>-   Complete an [Introduction to Kubernetes](https://learn.microsoft.com/en-us/training/modules/intro-to-kubernetes/).