---
exam: 104
module: Identity
---
![[Docs - Governance Strategy]]

# Azure RBAC concepts
The core concepts of RBAC: ^792390
- Security Principal
	An object that represents something that requests access to resources.
- Role definition
	A set of permissions that lists the allowed operations.
	Comes with built-in role definitions but we can make our own.
- Scope
	How much access is granted.
- Assignment
	An **assignment** attaches a **role definition** to a **security principal** at a particular **scope**.

**Consider**
1. Your Requestors
2. Your roles
3. Scope of permissions
4. Built-in or custom definitions.

# Create a role definition
>  A role definition consists of sets of permissions that are defined in a JSON file.

Some examples of permission sets include:
-   _Actions_ permissions identify what actions are allowed.
-   _NotActions_ permissions specify what actions aren't allowed.
-   _DataActions_ permissions indicate how data can be changed or used.
-   _AssignableScopes_ permissions list the scopes where a role definition can be assigned.
![[Pasted image 20230430203157.png]]

In PowerShell Output - 
```
Name: Owner
ID: 01010101-2323-4545-6767-987453021523
IsCustom: False
Description: Manage everything, including access to resources
Actions: {*}             # All actions allowed
NotActions: {}           # No actions denied
AssignableScopes: {/}    # Role can be assigned to all scopes
```

Things to know about role definitions
- Azure RBAC provides built-in roles and permissions sets.
- You can also create custom roles and permissions.
- The _Owner_ built-in role has the highest level of access privilege in Azure.
- `Effective Permission` = `Actions ` - `NoActions`
- The AssignableScopes permissions for a role can be management groups, subscriptions, resource groups, or resources.

# Role Permissions
Use the _Actions_ and _NotActions_ permissions together to grant and deny the exact privileges for each role.
![[Pasted image 20230430203649.png]]
# Role scopes

After you define the role permissions, you use the _AssignableScopes_ permissions to specify how the role can be assigned. Let's look at a few examples.

-   Scope a role as available for assignment in two subscriptions:
    `"/subscriptions/c276fc76-9cd4-44c9-99a7-4fd71546436e", "/subscriptions/e91d47c4-76f3-4271-a796-21b4ecfe3624"`
-   Scope a role as available for assignment only in the Network resource group:
    `"/subscriptions/c276fc76-9cd4-44c9-99a7-4fd71546436e/resourceGroups/Network"`
-   Scope a role as available for assignment for all requestors:
    `"/"`

**Consider**
- Built-in roles
- Creating custom definitions 
- Limiting access scope
- Controlling changes to data
- Applying deny assignments

# Create a role assignment
> Process of scoping the role definition to limit the permissions for a requestor.

Characteristics of role assignments:
- Purpose of role assignment is to control access
- Scope limits available permissions for a requestor.
- Access is revoked by removing a role assignment. 
- Resource inherits role assignment from parent resource.
- Effective Permission for a requestor = Permissions for the requestor's assigned role and Permission for the roles assigned to the requested resource.

![[Pasted image 20230430215056.png]]

# Roles in Azure
Three types of roles are available for access management in Azure:
-   Classic subscription administrator roles
-   Azure role-based access control (RBAC) roles
-   Azure Active Directory (Azure AD) administrator roles

## AD Roles vs RBAC Roles
-   **Azure AD admin roles** are used to manage resources in Azure AD, such as users, groups, and domains. These roles are defined for the Azure AD tenant at the root level of the configuration.
-   **Azure RBAC roles** provide more granular access management for Azure resources. These roles are defined for a requestor or resource and can be applied at multiple levels: the root, management groups, subscriptions, resource groups, or resources.

# Fundamental Azure RBAC Roles
Azure RBAC provides over 100 pre-defined role definitions. 
Roles can grant access to data within an object.
![[Pasted image 20230430215744.png]]

> [!info] Further Reading
> [RBAC - Docs](https://learn.microsoft.com/en-us/azure/role-based-access-control/)
> [Overview](https://learn.microsoft.com/en-us/azure/role-based-access-control/overview)
> [Role Definitions](https://learn.microsoft.com/en-us/azure/role-based-access-control/role-definitions)
> [Custom Roles](https://learn.microsoft.com/en-us/azure/role-based-access-control/custom-roles)
