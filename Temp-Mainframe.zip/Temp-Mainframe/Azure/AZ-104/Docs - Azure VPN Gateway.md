---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Azure VPN Gateway Uses
Read [[Docs - Azure Virtual Network Peering#Gateway transit and connectivity]]
>  Used to send encrypted traffic between your Azure virtual network and an on-premises location over the public internet.

> Can also be used to send encrypted traffic between your Azure virtual networks over the Microsoft network.


![[Pasted image 20230505210802.png]]
The configuration shows a virtual network connection with a VPN gateway. The virtual network has a site-to-site connection to an on-premises network that uses the IPsec IKEv2 protocol.

Things to know about VPN gateways
- VPN service intercepts your data and applies encryption before it reaches the internet.
- The VPN service uses a secure pathway (called a VPN tunnel) for movement of data.
- A virtual network can have only one VPN gateway.
- Multiple connections can be created to the same VPN gateway.
	- All connections share the same available gateway bandwidth.

# Virtual Network Gateway
Read - [[02 Knowledge/Microsoft/Azure/AZ-900/Docs - Azure VPN Gateway#VPN Gateways]]
> A virtual network gateway is composed of two or more virtual machines that are deployed to a specific subnet that you create called the _gateway subnet_.

- The virtual machines are created when you create the virtual network gateway.
- The virtual machines contain routing tables and run specific gateway services.
- You can't directly configure the virtual machines that are part of a virtual network gateway.

# Create Site-to-Site Connections
https://learn.microsoft.com/en-us/azure/vpn-gateway/design#s2smulti

![[Pasted image 20230505213348.png]]

Step 1. Create [[Docs - Azure Virtual Networks#Subnets|Subnets]]
Step 2. Specify [[Docs - Azure DNS]]
Step 3. Create Gateway Subnet

## Gateway Subnet
> The gateway subnet is part of the virtual network IP address range that you specify when you configure your virtual network.

Things to know 
-   You deploy a gateway in your virtual network by adding a gateway subnet.
-   Your gateway subnet must be named _GatewaySubnet_.
-   The gateway subnet contains the IP addresses that are used by your virtual network gateway resources and services.
-   When you create your gateway subnet, gateway virtual machines are deployed to the gateway subnet and configured with the required VPN gateway settings.

![[Pasted image 20230505214446.png]]

## Create VPN Gateways
[[02 Knowledge/Microsoft/Azure/AZ-900/Docs - Azure VPN Gateway#VPN Gateways]]
![[Pasted image 20230505215018.png]]

### Determine the type
1. Role Based
2. Policy Based

The VPN gateway type can be either route-based or policy-based, and most configurations require a route-based VPN. Use a route-based VPN if your virtual network coexists with an Azure ExpressRoute gateway, or if you need to use the IKEv2 protocol. Policy-based VPNs have limitations, such as only being compatible with the Basic gateway SKU, having only one VPN tunnel, and only being able to use for S2S connections under certain configurations.

> [!info] After a virtual network gateway is created, you can't change the VPN type.

### Determine SKU
The following tables provide sample gateway Stock Keeping Units that are available for implementation. Because the Basic SKU is considered a legacy SKU, samples aren't shown for this option. 
> Examples - VpnGw1, VpnGw2, VpnGw5AZ

The tables identify the following information for each SKU type and generation:
- **Tunnels**: The maximum number of site-to-site (S2S) and Net-to-VNet tunnels that can be created for the SKU.
- **Connections**: The maximum number of point-to-site (P2S) IKEv2 connections that can be created for the SKU.
- **Throughput**: The benchmark is based on measurements of multiple VPN tunnels aggregated through a single gateway. 

## Local Network Gateway
> The local network gateway typically refers to the on-premises location. 

To create a local gateway, you provide a name for the site, along with the IP address or FQDN of the on-premises VPN device for the connection.

![[Pasted image 20230505215946.png]]

## On-Premises VPN Device
> A validated list of standard VPN devices that work well with the VPN gateway is available for developers. The list was created in partnership with device manufacturers like Cisco, Juniper, Ubiquiti, and Barracuda Networks.

[Validated VPN Devices and device configuration guide](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-devices#devicetable)
To configure your VPN device, you need the following information:
-   **A shared key**. This key is the same shared key that you specify when you create the VPN connection.
-   **The public IP address of your VPN gateway**. The IP address can be new or existing.
[Configutaion Scripts](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-download-vpndevicescript)

## VPN Connection
> The last step in the site-to-site connection process is to establish the connection between your VPN gateways. If your virtual networks are in the same subscription, you can use the Azure portal to create the connection. Several parameters need to be configured to create the connection.

![[Pasted image 20230505220328.png]]

## High Availability Scenarios
> By creating two or more VPN gateways in an active-active or active-passive configuration, you can ensure that VPN traffic can still flow if one of the VPN gateways fails.

In an active-active configuration, both VPN gateways are active and traffic is load balanced across them. In an active-passive configuration, one VPN gateway is active and the other is in standby mode, ready to take over if the active gateway fails.

### Active-Standby
> Any disruption that happens to the _active_ instance, the _standby_ instance takes over (failover) automatically

![[Pasted image 20230505220739.png]]

- The switch over causes a brief interruption.
- For planned maintenance, connectivity is commonly restored within 10 to 15 seconds.
- For unplanned issues, the connection recovery can be longer, taking from 1 minute to 1 and a half minutes in the worst case.
- For point-to-site VPN client connections to the gateway, the P2S connections are disconnected and users need to reconnect from the client machines.

### Active-Active
Configuring an Azure VPN gateway in an active-active configuration involves deploying two gateway instances that establish site-to-site VPN tunnels to an on-premises VPN device, with each gateway instance having a unique public IP address and both VPN tunnels part of the same connection. 

This provides high availability, but requires configuration of the on-premises VPN device to accept or establish two S2S VPN tunnels to the two Azure VPN gateway public IP addresses.

![[Pasted image 20230505221028.png]]

> [!note] Further Reading
> ## Learn more
>-   Peruse [Azure VPN Gateway documentation](https://learn.microsoft.com/en-us/azure/vpn-gateway/).
>-   Discover [VPN Gateway configuration settings](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-gateway-settings).
>-   Create and manage a [VPN gateway by using the Azure portal](https://learn.microsoft.com/en-us/azure/vpn-gateway/tutorial-create-gateway-portal).
>-   Create a [site-to-site VPN connection in the Azure portal](https://learn.microsoft.com/en-us/azure/vpn-gateway/tutorial-site-to-site-portal).
>-   Explore [VPN Gateway design options: S2S, P2S, VNet-to-VNet, and high availability](https://learn.microsoft.com/en-us/azure/vpn-gateway/design)
>-   Review [highly available cross-premises and VNet-to-VNet connectivity](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-highlyavailable).
>-   Find [validated VPN devices and IPsec/IKE parameters for S2S VPN Gateway connections](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpn-devices).
>-   Plan your [Azure VPN Gateway solution](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-about-vpngateways#planningtable).
>## Learn more with self-paced training
>-   Review an [introduction to Azure VPN Gateway](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-vpn-gateway/).
>-   Connect [your on-premises network to Azure with Azure VPN Gateway (sandbox)](https://learn.microsoft.com/en-us/training/modules/connect-on-premises-network-with-vpn-gateway/)

