---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Windows Virtual Machine in Azure

## Size your VM
![[Pasted image 20230505004610.png]]
## Choose storage options
## Map storage to disks
- Unmanaged disks
	- Storage account has a fixed rate limit of 20,000 I/O opertaions/sec.
	- Single storage account is capable of supporting 40 standard VHD.
- Managed disks
	- Newer and recommended.
	- Put the burden of management on Azure
# Azure VM Network Settings
## Open ports in Azure VMs
- By default, new VMs are locked down. 
- Apps can make outgoing requests.
- Inbound traffic is allowed from the virtual network.
- You can open common ports - RDP, HTTP, HTTPS and SSH.
	- If you need other ports, you will have to open them yourself. 
## Network Security Group
> Network Security Groups (NSGs) are the main tool you use to enforce and control network traffic rules at the networking level.

Security groups can be associated to a network interface (for per-host rules), a subnet in the virtual network (to apply to multiple resources), or both levels.

## Security group rules
NSGs use _rules_ to allow or deny traffic moving through the network. Each rule identifies the source and destination address (or range), protocol, port (or range), direction (inbound or outbound), a numeric priority, and whether to allow or deny the traffic that matches the rule. The following illustration shows NSG rules applied at the subnet and network-interface levels.
![[Pasted image 20230505013139.png]]

## Azure uses network rules
For inbound traffic, Azure processes the security group associated to the subnet, then the security group applied to the network interface. Outbound traffic is processed in the opposite order (the network interface first, followed by the subnet).

The rules are evaluated in _priority order_, starting with the **lowest priority** rule. Deny rules always **stop** the evaluation. For example, if an outbound request is blocked by a network interface rule, any rules applied to the subnet will not be checked. In order for traffic to be allowed through the security group, it must pass through _all_ applied groups.

The last rule is always a **Deny All** rule. This is a default rule added to every security group for both inbound and outbound traffic with a priority of 65500. That means to have traffic pass through the security group, _you must have an allow rule_ or it will be blocked by the default final rule.