---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Domains and Custom Domains
> Azure DNS enables you to host your DNS domains in Azure and access name resolution for your domains by using Microsoft Azure infrastructure.

> You can configure and manage your custom domains with Azure DNS in the Azure portal.

## Initial Domain Names and Custom Domain Names

- When you create Azure subscription, Azure automatically creates an Azure AD domain for your subscription.
- In Azure AD, domain names must be globally unique
- Azure applies an initial domain name to your initial domain instance.
  `<your domain name>` followed by `.onmicrosoft.com`
- The initial domain name is intended to be used until your custom domain name is _verified_.
- The initial domain name can't be changed or deleted, but you can add a routable custom domain name that you control.
- Custom domain to provide a simplified form of your domain name to support specific users or tasks.
  like - instead of `azureadminincorg.onmicrosoft.com` use `azureadmininc.org`
- The custom domain name must be added to your directory and verified.

# Verify Custom Domain Names
> Before you can use a custom domain name for your Azure AD instance, your custom domain name must be _verified_.

After you add a custom domain name for your Azure AD instance in the Azure portal, you must verify ownership of your custom domain name.
You initiate the verification process by adding a **DNS record** for your custom domain name. The DNS record type can be `MX`(Mail Exchange) or `TXT` (Text), as shown in the following image:
![[Pasted image 20230505191146.png]]

# Azure DNS Zones
> An Azure **DNS zone** hosts the DNS records for a domain.

![[Pasted image 20230505191804.png]]

- Within a resource group the name of DNS zone must be **unique**
- DNS name server addresses are used to locate the DNS zone and its associated resources.
- When multiple DNS zones share the same name, each DNS zone instance is assigned to a different DNS name server address.
- The Root/Parent domain is registered at the registrar and then pointed to Azure DNS.
- Child domains are registered directly in Azure DNS.

## DNS Name Servers
When you create a DNS zone in Azure DNS, the service allocates DNS name servers from a pool of servers to handle queries for the zone. These name servers are responsible for responding to DNS queries for the DNS zone. Once the DNS name servers are assigned, Azure DNS automatically creates authoritative NS (or Name server) records in your DNS zone.

## NS Records
These NS records contain the names of the assigned name servers and their IP addresses, and they are used by other DNS servers to locate and query the name servers for the DNS zone. By creating these NS records automatically, Azure DNS ensures that your DNS zone is properly configured and can be resolved by other DNS servers on the internet.

# Delegate DNS domains
> To delegate your domain to Azure DNS, you need to identify the DNS name servers for your DNS zone.

The delegation process for your domain involves several steps:
1.  Identify your DNS name servers
2.  Update your parent domain
3.  Delegate subdomains (optional)

## Find DNS Name servers
> Easiest - Through Azure Portal

![[Pasted image 20230505193222.png]]

## Update your parent domain
> Ask the third-party registrar to use the `NS` records created by Azure DNS.

Here's a basic process you can follow to update your parent domain information with your registrar:

1.  Go to your registrar's DNS management page.
2.  Find the existing `NS` records for your parent domain.
3.  Replace the existing `NS` records with the `NS` records created for your domain by Azure DNS.

Things ot consider with NS records - 
- Make sure to copy the `.` at the end of FQDN. Like `ns1-02.azure-dns.com.`
- To delegate your domain to Azure DNS, you must use the exact names of the DNS name servers as created by Azure DNS.
- Always copy all DNS name server NS records for your domain to the parent domain.

## Delegate subdomains
>  Delegate a subdomain for your domain in Azure DNS by setting up a separate child DNS zone.

Example -
If you have `azureadmininc.org` and you want a domain for partners, you can create `partners.azureadmininc.org`

Here are the steps to delegate a subdomain:
1.  Go to the parent DNS zone for your domain in the Azure portal.
2.  Find the existing `NS` records for your parent domain.
3.  Create new `NS` records for your child DNS zone (subdomain).

> [!info] The key difference is you don't work with your registrar to delegate a subdomain. You delegate the child DNS zone in the Azure portal.

# DNS Record Sets
> DNS record sets are collections of DNS records that share the same properties, such as the same record type, name, and TTL (Time to Live) value. 
> A DNS record set contains one or more DNS records.

A DNS record set (also known as a _resource record set_) is a collection of records in a DNS zone.

![[Pasted image 20230505194504.png]]

## Properties
- All records in a DNS record set must have the same name and the same record type.
- A DNS record set can't contain two identical records.
- A record set of type `CNAME` can contain only one record.
- A record set that doesn't have any records is called an empty record set.
- Empty record sets doesn't appear on your Azure DNS name servers

## Advantages
- No custom DNS solution required
- Support for common DNS records types
- Automatic hostname record management
- Hostname resolution between virtual networks
- Familiar tools and user experience
- Split-horizon DNS support
- Azure region support

> [!note] Further Reading
> ## Learn more
>-   Peruse [Azure DNS documentation](https://learn.microsoft.com/en-us/azure/dns/).
>-   Read about [Azure DNS](https://learn.microsoft.com/en-us/azure/dns/dns-overview) and [Azure Private DNS](https://learn.microsoft.com/en-us/azure/dns/private-dns-overview).
>-   Explore [DNS zones and records](https://learn.microsoft.com/en-us/azure/dns/dns-zones-records).
>-   Create [Azure DNS zones and records in the Azure portal](https://learn.microsoft.com/en-us/azure/dns/dns-getstarted-portal).
>## Learn more with self-paced training
>-   Complete an [introduction to Azure DNS](https://learn.microsoft.com/en-us/training/modules/intro-to-azure-dns/).
>-   Host [your domain on Azure DNS (sandbox)](https://learn.microsoft.com/en-us/training/modules/host-domain-azure-dns/).

