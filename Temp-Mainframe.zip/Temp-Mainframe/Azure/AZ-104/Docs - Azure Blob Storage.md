---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Implement Azure Blob Storage
[[Docs - Storage Accounts#Azure Blob Storage]]
To implement Blob Storage, you configure several settings:
-   Blob container options
-   Blob types and upload options
-   Blob Storage access tiers
-   Blob lifecycle rules
-   Blob object replication options

## Configure a container
You get two options
1. Name
	   Should be lowercase. 
	   Upto 63 chars
2. Public Access Level
	1. Private: (default) No outside access
	2. Blob: Read access to externals
	3. Container: Read/Write access to externals

# Blob Access Tiers
1. Hot Tier
2. Cool Tier
3. Archive Tier
4. Permium Blob Storage

![[Pasted image 20230501181510.png]]

# Lifecycle management rules
> You can use lifecycle policy rules to transition your data to the appropriate access tiers, and set expiration times for the end of a data set's lifecycle.

![[Pasted image 20230501182152.png]]

# Blob object replication
> Object replication copies blobs in a container to another as per the policy rules.

![[Pasted image 20230501182457.png]]

Things to know - 
- Blob versioning should be enabled on both containers
- Doesn't support blob snapshots. 
- Both source and destination should be in hot or cool tier. 
- Policy contains the information about source storage account and destination storage account
- Policy identifies the blobs in the source container to replicate.

# Upload Blobs
> A blob can be any type of data and any size file. Azure Storage offers three types of blobs: _block blob_, _page blob_, and _append blob_.

1. **Block blobs**
   Most used. Like Files, images and videos.
2. **Append blobs**
   Add data to block blobs. Like logs.
3. **Page blobs**
   Only upto 8TB. Like OS for VMs and data disks.

> [!INFO] After you create a blob, can't change it's type.

Use Azure Storage Explorer to upload blobs to your Azure storage account.

> [!note] Further Reading
> [Blob Documentation](https://learn.microsoft.com/en-us/azure/storage/blobs/)

