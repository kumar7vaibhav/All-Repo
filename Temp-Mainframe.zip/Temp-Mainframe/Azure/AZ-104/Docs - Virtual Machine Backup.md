---
exam: 104
module: Monitor
---
```dataviewjs
dv.view('toc')
```
# VM backup options
> Azure Backup, Azure Site Recovery, Azure managed disks snapshots and Images

1. Azure Backup
	- Back up Azure Virtual Machines running workloads
	- Create application-consistent backups/
	  
2. Azure Site Recovery
	- Quickly recover specific application
	- Replicate to the Azure region of your choice.
	  
3. Azure managed disks -  snapshot
	- Quickly backup your VM that use Azure managed disk at any time.
	- Support dev and test environment.
	  
4. Azure managed disks - Images
	- Create an image from your custom VHD in an Azure storage account
	- Create hundreds of VM by using your custom image without copying or managing any storage account.

# Create VM Snapshot in Azure Backup
> Create snapshot in two phases - 
> 1. Take a snapshot of VM data
> 2. Transfer the snapshot to an Azure Recovery Services vault

![[Pasted image 20230507194143.png]]

> [!tip] Things to know

- By default, Azure Backup keeps snapshots for 2 days.
	- You can set the default value from 1-5 days.
- Incremental snapshots are stored as Azure page blobs (Azure disks)
- Recovery points for a VM are available only after both phases of the Azure Backup job are complete.
	- RP are listed in the Azure Portal and are labeled with a recovery point type.
	- For the first snapshot, the RP is labeled 'snapshot' recovery type.
	- After the snapshot is transferred to the Azure Recovery Services vault, the recovery point type changes to 'snapshot and vault'

To use Azure Backup to protect your Azure virtual machines, you follow a simple three-step process: create a vault, define your backup options, and trigger the backup job.
![[Pasted image 20230507194818.png]]

# System Center DPM & Azure Backup Server
> System Center Data Protection Management

> You can use these services sto back up specialized workload (SharePoint, Exchange, SQL Server), VMs or files and folders.

- You can backup data to System Center DPM and MABS storage, and then back up the DPM or MABS storage to an Azure Recovery Services vault.

> [!tip] Things to know

- You select to back up to the MABS or DPM for short-term storage.
- Specify when to run the backup
- For on-premises, System Center DPM and MABS storage should be located on-premises
- For Azure VMs, they must be run as Azure VM and located in Azure.
- Agent must be installed on all the machines you want to protect.

# Soft delete for VMs
> Azure Storage now offers the _soft delete_ option for Azure Blob objects. With this feature, you can more easily recover your data when it's erroneously modified or deleted by an application or other storage account user.

![[Pasted image 20230507200318.png]]

> [!note] preserved in the soft-delete state for 14 more days.

# Azure Site Recovery
> Azure Site Recovery helps ensure business continuity by keeping business applications and workloads running during outages.

![[Pasted image 20230507200533.png]]
Azure Site Recovery supports many configurations and complements various Azure services. You can implement Site Recovery to back up your virtual machines and physical machines in the following scenarios:

- Replicate Azure virtual machines from one Azure region to another
- Replicate on-premises VMware virtual machines, Hyper-V virtual machines, physical servers (Windows and Linux), and Azure Stack virtual machines to Azure
- Replicate AWS Windows instances to Azure
- Replicate on-premises VMware virtual machines, Hyper-V virtual machines managed by System Center VMM, and physical servers to a secondary site

> [!note] Further Reading
> ## Learn more
> -   Read an [overview of Azure virtual machine backup](https://learn.microsoft.com/en-us/azure/backup/backup-azure-vms-introduction).
> -   Explore the [Azure Backup center](https://learn.microsoft.com/en-us/azure/backup/backup-center-overview).
> -   Preuse [Azure Site Recovery documentation](https://learn.microsoft.com/en-us/azure/site-recovery/site-recovery-overview).
> -   Discover [System Center Data Protection Manager (DPM)](https://learn.microsoft.com/en-us/system-center/dpm/dpm-overview). 
> -   Discover [Microsoft Azure Backup Server (MABS)](https://learn.microsoft.com/en-us/azure/backup/backup-mabs-whats-new-mabs).
> -   Install the [Microsoft Azure Virtual Machine Agent](https://learn.microsoft.com/en-us/azure/virtual-machines/extensions/agent-windows#install-the-vm-agent).
> -   Deploy the [System Center DPM (and MABS) protection agent](https://learn.microsoft.com/en-us/system-center/dpm/deploy-dpm-protection-agent).

