---
exam: 104
module: Network
---
Read - [[Docs - Azure DNS]]

# What is DNS?
> Converts human-readable domain names into known IP address.

DNS server is also known as a DNS name server or just name server.

# How does DNS work?
> Two primary functions
> 1. Maintains a local cache of recently accessed or used domain names and their IP.
> 2. Maintains a key-value pair database of IP and host domain over which the DNS server has authority

## DNS Record Types
> Configurtaion information for you DNS server is stored as a file within a zone on your DNS server. Each file is called a record. 

- **A** is the host record, and is the most common type of DNS record. It maps the domain or host name to the IP address.
- **CNAME** is a Canonical Name record that's used to create an alias from one domain name to another domain name. If you had different domain names that all accessed the same website, you would use CNAME.
- **MX** is the mail exchange record. It maps mail requests to your mail server, whether hosted on-premises or in the cloud.
- **TXT** is the text record. It's used to associate text strings with a domain name. Azure and Microsoft 365 use TXT records to verify domain ownership.

# What is Azure DNS?
> Azure DNS allows you to host and manage your domains by using a globally distributed name server infrastructure. It allows you to manage all of your domains by using your existing Azure credentials.

## Security Features
- Role-based access control
- Activity logs
- Resource locking

## Ease of use
> Azure DNS can manage DNS records for your Azure services, and provide DNS for your external resources.
> Azure DNS uses the same Azure credentials, support contract, and billing as your other Azure services.

## Private Domains
> Azure DNS handles the translation of external domain names to an IP address.

## Alias record sets
> Alias records sets can point to an Azure resource.

The alias record set is supported in the following DNS record types:
- A
- AAAA
- CNAME

# Azure DNS to host your domain
## Step 1: Create a DNS zone in Azure
## Step 2: Get your Azure DNS name servers
## Step 3: Update the domain registrar setting
## Step 4: Verify delegation of domain name services
## Step 5: Configure your custom DNS settings

# Apex Domain