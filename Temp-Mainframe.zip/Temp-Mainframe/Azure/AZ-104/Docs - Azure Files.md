---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Azure Files
Read - [[Docs - Azure Storage#[Azure File Fundamentals](https://docs.microsoft.com/en-us/learn/modules/azure-storage-fundamentals/azure-file-storage)|Azure Files]]
> Share data by suing mounted shares.

Characteristics - 
- Any number of VMs or roles can mount and access the Azure Files
- Mount like any other SMB shared files.
- Ideal to lift and shift an application to the cloud
- A good option when you want to store development and debugging tools that need to be accessed from many virtual machines.

# Manage Azure Files Share
> To access your files, you need an Azure storage account

> [!TIP] Things to consider
> 1. Open port 445: SMB communicates over TCP port 445. 
> 2. Enable secure transfer

## Map to Windows
You can connect your Azure Files share with Windows or Windows Server in the Azure portal. Specify the **Drive** where you want to map the share, and choose the **Authentication method**.  The system supplies you with PowerShell commands to run when you're ready to work with the file share.

## Map to Linux
Azure Files shares can be mounted in Linux distributions by using the CIFS kernel client.
File mounting can be done on-demand with the `mount` command or on-boot (persistent) by creating an entry in /etc/fstab.

# Create file share snapshots
> File share snapshots capture a point-in-time, read-only copy of your data.

- Snapshot capability at the file share level
- Snapshots are incremental in nature.
- Can restore individual files.
- To delete the File Share you must delete all the snapshots first.

# Azure File Sync
> Cache several Azure Files shares on an on-premises Windows Server or cloud virtual machine

You can use Azure File Sync to centralize your organization's file shares in Azure Files.

## Cloud Tiering
> Optional Feature
> Frequently accessed files are cached locally on the server while all other files are tiered to Azure Files based on policy settings.
> _Just like OneDrive_

## File Sync Components
>  Provide caching for Azure Files shares on an on-premises Windows Server or cloud virtual machine.

1. **Storage Sync Service**
   Storage Sync Service forms sync relationships with multiple storage accounts by using multiple sync groups.
2. **Sync Group**
   A sync group defines the sync topology for a set of files.
3. **Registered Server**
4. **Azure File Sync Agent**
   Azure File Sync agent is a downloadable package that enables Windows Server to be synced with an Azure Files share.
5. **Server endpoint**
   A specific location on a registered server, such as a folder on a server volume.
6. **Cloud endpoint**
   A cloud endpoint is an Azure Files share that's part of a sync group.

## Deploy Azure File Sync
![[Pasted image 20230501223605.png]]

> [!Note] Further Reading
> [File Share Documentation](https://learn.microsoft.com/en-us/azure/storage/files/)
> [ File Sync Documentation](https://learn.microsoft.com/en-us/azure/storage/file-sync/)
> [Cloud Tiering](https://learn.microsoft.com/en-us/azure/storage/file-sync/file-sync-cloud-tiering-overview)
> 