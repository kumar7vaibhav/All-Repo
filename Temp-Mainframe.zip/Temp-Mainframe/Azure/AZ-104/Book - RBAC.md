---
exam: 104
module: Identity 
---
# Role Based Access Control
In summary RBAC consists of three main sections
1. Security Princiapal
2. Role
3. Scope

Permission Types:
1. Actions
2. NoAction
> [!info] NotActions always takes preference over Action items.

[[Book - Azure Policy]]

# Tags
https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/tag-resources?tabs=json
