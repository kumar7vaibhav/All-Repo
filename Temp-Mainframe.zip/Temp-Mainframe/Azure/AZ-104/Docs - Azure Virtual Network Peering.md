---
exam: 104
module: Network 
---
# Azure Virtual Network
> Azure Virtual Network peering lets you connect virtual networks in the same or different regions, so resources in both networks can communicate with each other.

Virtual Network peering enables you to seamlessly connect two Azure virtual networks.
![[Pasted image 20230505200857.png]]
[[Docs - Azure Virtual Networks#Plan Virtual Network]]
Two types.
1. Regional Peering
2. Global Peering

# Gateway transit and connectivity
Read [[02 Knowledge/Microsoft/Azure/AZ-900/Docs - Azure VPN Gateway]]
> Azure VPN gateway is a virtual network gateway that creates a secure connection between your on-premises network and an Azure virtual network. It allows you to extend your network to Azure and access resources in your virtual network securely.

- When you allow VPN gateway transit, the virtual network can communicate to resources outside the peering.
- A virtual network can have only one VPN gateway.
- Gateway transit is supported for both regional and global virtual network peering.
- You don't need to deploy a VPN gateway in the peer virtual network.

# Extend Peering
There are a few ways to extend the capabilities of your peering for resources and virtual networks outside your peering network:

-   Hub and spoke networks
-   User-defined routes
-   Service chaining



> [!note] Further Reading
> ## Learn more
>-   Peruse [Azure Virtual Network peering documentation](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-network-peering-overview).
>-   Connect [virtual networks with Azure Virtual Network peering in the Azure portal](https://learn.microsoft.com/en-us/azure/virtual-network/tutorial-connect-virtual-networks-portal).
>-   Create, change, or delete [virtual network peering](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-network-manage-peering).
>-   Configure [Azure VPN Gateway transit for virtual network peering](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-peering-gateway-transit).
>-   Create [peering for virtual networks in different deployment models](https://learn.microsoft.com/en-us/azure/virtual-network/create-peering-different-deployment-models).
>-   Explore [hub-spoke network topology in Azure and virtual network peering](https://learn.microsoft.com/en-us/azure/architecture/reference-architectures/hybrid-networking/hub-spoke?tabs=cli#virtual-network-peering).
>-   Troubleshoot [virtual network peering issues](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-network-troubleshoot-peering-issues).
>## Learn more with self-paced training
>-   Distribute [your services across Azure virtual networks and integrate them by using Azure Virtual Network peering (sandbox)](https://learn.microsoft.com/en-us/training/modules/integrate-vnets-with-vnet-peering/).

