---
exam: 104
module: Compute 
---
# What is Azure CLI?
> The Azure CLI can help you manage Azure resources such as virtual machines and disks from the command line or in scripts.

Read -
[[Docs - Azure services with CLI]]
[[Azure CLI - Examples]]

---
# Exercises
## Create a Linux VM
```PowerShell
az vm create \
  --resource-group learn-26438309-03c3-4043-bc41-746b12f74550 \
  --location centralindia \
  --name SampleVM \
  --image UbuntuLTS \
  --admin-username kvaibhav \
  --generate-ssh-keys \
  --verbose
```

> [!success] Output
> {
  "fqdns": "",
  "id": "/subscriptions/722978d8-654a-4ef2-aabc-c59643fcf775/resourceGroups/learn-26438309-03c3-4043-bc41-746b12f74550/providers/Microsoft.Compute/virtualMachines/SampleVM",
  "location": "centralindia",
  "macAddress": "60-45-BD-73-97-56",
  "powerState": "VM running",
  "privateIpAddress": "10.0.0.4",
  "publicIpAddress": "20.204.21.230",
  "resourceGroup": "learn-26438309-03c3-4043-bc41-746b12f74550",
  "zones": ""
}

## SSH into the VM
```
ssh kvaibhav@20.204.21.230
```

## Listing images
```
az vm image list --output table
```

## Pre-defined VM sizes
```
az vm list-sizes --location eastus --output table
```

## Specify a size during VM creation
```
az vm create \
    --resource-group [sandbox resource group name] \
    --name SampleVM2 \
    --image UbuntuLTS \
    --admin-username azureuser \
    --generate-ssh-keys \
    --verbose \
    --size "Standard_DS2_v2"
```

## Resize a existing VM
```
az vm list-vm-resize-options \
    --resource-group [sandbox resource group name] \
    --name SampleVM \
    --output table
```
