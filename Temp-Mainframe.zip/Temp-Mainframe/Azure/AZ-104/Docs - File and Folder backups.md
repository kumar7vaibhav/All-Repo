---
exam: 104
module: Monitor 
---
```dataviewjs
dv.view('toc')
```
# Azure Backup
> Azure Backup is the Azure-based service you can use to back up (or protect) and restore your data in the Microsoft cloud.

Things to know about - 
- Offload on-premises backup
- Back up Azure IaaS VMs
- Get unlimited data transfer
- Keep data secure
- Get app-consistent backups
- Retain short and long-term data
- Automatic storage management
- Multiple storage options
	- Locally redundant storage [[Docs - Storage Accounts#Replication Strategies#1. Locally redundant storage (LRS)|(LRS)]]
	- Geo-redundant storage [[Docs - Storage Accounts#3. Geo-redundant storage (GRS)|(GRS)]]

# Backup Center
> Backup center for Azure Backup provides a single unified management experience in Azure.

![[Pasted image 20230507190508.png]]

# Azure Recovery Services
> The **Recovery Services vault** is a storage entity in Azure that stores data. Recovery Services vaults make it easy to organize your backup data, while minimizing management overhead.

- Can be used to back up [[Docs - Azure Files#Azure Files|Azure Files]] file shares or on-premises files and folders
- Stores backup data of various Azure services. Like VMs, SQL
- Create Recovery Services vault from the Backup Center dashboard.

![[Pasted image 20230507191128.png]]

> [!TIP] Things to know

- If you're using Azure Backup for [[Docs - Azure Files#Azure Files|Azure Files]] file shares, you don't need to configure the storage replication type. 
	- Azure Files backup is snapshot-based, and no data is transferred to the vault. 
	- Snapshots are stored in the [[Docs - Azure Storage Account|Azure Storage account]] as your backed-up file share.
- There are three types of storage replication options
	1. Geo-redundant (GRS)
	2. Locally redundant (LRS)
	3. Zone redundant
- You can specify how to restore data in a secondary, Azure paired region by enabling the **Cross Region Restore**

# Microsoft Azure Recovery Services (MARS)
> Azure Backup uses MARS agent to back up files, folders, and system data from your on-premises machines and Azure VMs.

- MARS agent should be installed on Windows Client or Windows Server
- You can back up files and folders on VMs or Physical machines. Both on cloud and on-premises.
- Agent does not require separate backup server.
- Agent isn't application aware.

> [!TIP] Things to know

Backup scenario
- On-premises direct backup
- Back up for specific files or folders
- Back up to MARS or System Center DPM

# Configure On-premises file and folder backup

Steps - 
1. Create Recovery Service vault
2. Download MARS agent and credential file
3. Install and register MARS agent
4. Configure backups

> [!note] Further Reading
> ## Learn more
> -   Read about [Azure Backup](https://learn.microsoft.com/en-us/azure/backup/backup-overview).
> -   Discover [Azure file share backup](https://learn.microsoft.com/en-us/azure/backup/azure-file-share-backup-overview).
> -   Explore [Azure Recovery Services vaults](https://learn.microsoft.com/en-us/azure/backup/backup-azure-recovery-services-vault-overview).
> -   Explore [Backup center for Azure Backup and Azure Site Recovery](https://learn.microsoft.com/en-us/azure/backup/backup-center-overview).
> -   Back up [Azure file shares in the Azure portal](https://learn.microsoft.com/en-us/azure/backup/backup-azure-files).
> -   Create and configure an [Azure Recovery Services vault](https://learn.microsoft.com/en-us/azure/backup/backup-create-recovery-services-vault).
> -   Manage [Azure file share backups](https://learn.microsoft.com/en-us/azure/backup/manage-afs-backup).
> -   Install the [Azure Backup MARS agent](https://learn.microsoft.com/en-us/azure/backup/install-mars-agent).
> -   Review [Azure Backup compliance offerings](https://learn.microsoft.com/en-us/azure/backup/compliance-offerings).

