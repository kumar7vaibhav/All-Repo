---
exam: 104
module: Compute
---
```dataviewjs
dv.view('toc')
```
# Virtual Machines
> Azure Virtual Machines is the basis of the Azure infrastructure as a service (IaaS) model

## Plan for VM
- Start with the network.
	- By default, no outside service access.
	- Can allow external access, if needed.
-   Choose a name for the virtual machine.
	- 15 characters for Windows and 64 characters for Linux
	- Name elements - Purpose, location, instance, product, role
-   Decide the location for the virtual machine.
	- Every location has different hardware in datacenter
	- Price differs by location
-   Determine the size of the virtual machine.
	  The best way to determine the appropriate machine size is to consider the type of workload your machine needs to run.
-   Review the pricing model and estimate your costs.
	- **Compute expenses** are priced on a per-hour basis but billed on a per-minute basis.
		- **Consumption-based**: With the consumption-based option, you pay for compute capacity by the second.
		- **Reserved Virtual Machine Instances**: option is an advance purchase of a virtual machine for one or three years in a specified region.
-   Identify which Azure Storage to use with the virtual machine.
	  Azure creates and manages the disk. As you add disks or scale the virtual machine up and down, you don't have to worry about the storage being used.
-   Select an operating system for the virtual machine.
	- Windows and Linux
	- Search Marketplace
	- Bring your own image.

## Virtual Machine Sizes
| Classification           | Scenarios                   |
| ------------------------ | --------------------------- |
| General Purpose          | Testing and Dev             |
| Compute Optimized        | Medium traffic web servers  |
| Memory Optimized         | Relational Database servers |
| Storage Optimized        | Big Data, SQL, NoSQL        |
| GPU                      | Model Training              |
| High Performance Compute | High network traffic        | 

### Resizing
Can resize any time. But that might restart the VM.


# Virtual Machine Storage
> All Azure VMs have two disks:
> 1. OS disk
> 2. Temporary disk
> 3. Can also have one or more data disks.

All disks are stored as virtual hard disks (VHDs). A VHD is like a physical disk in an on-premises server but, virtualized.

## Operating System Disk
> Every VM has one attached OS disk.

- Pre-installed OS
- Registered as SATA drive.
- Labeled `C:`

## Temporary Disk
> Data on this disk can be lost during any changes to the VM

- Labeled `D:` on Windows.
- On Linux, `/dev/sdb`

## Data Disk
> Store application data

- Registered as SCSI drives. 
- Labeled the letter you choose.
- Size of the VM determine how many drives you can attach and of what type.

# Connect to Virtual Machines
> Connect Azure virtual machines with the SSH and RDP protocols, Cloud Shell, and Azure Bastion.

> [!note] Further Reading
>-   Peruse [Azure Virtual Machines documentation](https://learn.microsoft.com/en-us/azure/virtual-machines/).
>-   Find [virtual machines for your configuration with the Virtual machines selector](https://azure.microsoft.com/pricing/vm-selector/).
>-   Choose [disk storage for your virtual machine workload](https://learn.microsoft.com/en-us/training/modules/choose-the-right-disk-storage-for-vm-workload/).
>-   Connect to [virtual machines through the Azure portal with Azure Bastion](https://learn.microsoft.com/en-us/training/modules/connect-vm-with-azure-bastion/). _Azure subscription required_.

