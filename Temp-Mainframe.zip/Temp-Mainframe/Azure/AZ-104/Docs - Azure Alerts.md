---
exam: 104
module: Monitor 
---
# Azure Monitor Alerts
>  Azure alerts to initiate responsive action and send notifications based on your telemetry data collected by [[Docs - Azure Monitor|Azure Monitror]]

1. Capture telemetry data
2. Create alerts to work with the data
3. Create alerts rules and actions
![[Pasted image 20230508213234.png]]

## Composition of an alert rule
- **RESOURCE**
    - The _target resource_ to be used for the alert rule. I
- **CONDITION**
    - The _signal type_ to be used to assess the rule. The signal type can be a metric, an activity log, or logs.
    - The _alert logic_ applied to the data that's supplied via the signal type. 
- **ACTIONS**
    - The _action_, like sending an email, sending an SMS message, or using a webhook.
    - An _action group_, which typically contains a unique set of recipients for the action.
- **ALERT DETAILS**
    - An _alert name_ and an _alert description_ that should specify the alert's purpose.
    - The _severity_ of the alert if the criteria or logic test evaluates `true`. The five severity levels are:
        - **0**: Critical
        - **1**: Error
        - **2**: Warning
        - **3**: Informational
        - **4**: Verbose

# Alert Types
> There are different types of alerts to support various configuration and monitoring scenarios, such as metrics, logs, and events.

## Metric Alerts
> Evaluates metric data from your resources at regular intervals.

## Logs Alerts
> Evaluate resource logs at a predefined frequency 

## Activity log events
> Implement alerts to trigger when a new activity log event occurs that meet your conditions.

1. Resource Health Alerts
2. Service Health Alerts

## Smart detection alerts
> Receive automatic warning about potential performance issues and failure anomalies.

# Alert States
> Three states - New, Acknowledged and Closed.

1. New - Issue is new and note in review
2. Acknowledged - The issue is in review and work is in progress
3. Closed - The issues is complete

# Stateless and Stateful Alerts
Stateless alerts trigger each time your alert rule condition matches your data, even if the same alert already exists. 
- You can configure log alerts and metric alerts as stateless.

Stateful alerts trigger when your alert rule condition matches your data and the same alert doesn't exist. 
- A stateful alert doesn't trigger any more actions until the current alert rule conditions clear. 
- You can configure log alerts and metric alerts as stateful. 
- Activity log alerts are always stateless.

# Actions Groups
> An action group is a collection of notification preferences.
> When Azure Monitor detects an issue in your telemetry data, your alert triggers and your alert rule actions initiate

> [!note] Further Reading
> -   Check out the [new alerts experience in Azure Monitor](https://learn.microsoft.com/en-us/azure/monitoring-and-diagnostics/monitoring-overview-unified-alerts).
> -   Review [types of Azure Monitor alerts](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-types).
> -   Create an [alert rule](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-create-new-alert-rule).
> -   Create and manage [action groups in the Azure portal](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/action-groups).
> -   Deploy [Azure Monitor alerts and automated actions with recommended practices](https://learn.microsoft.com/en-us/azure/azure-monitor/best-practices-alerts).
> -   Manage your [alert rules](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-manage-alert-rules).
> -   Manage your [alert instances](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-manage-alert-instances).

