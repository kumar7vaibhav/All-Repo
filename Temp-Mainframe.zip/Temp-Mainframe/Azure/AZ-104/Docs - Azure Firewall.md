---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Azure Firewall
> Azure Firewall is a cloud-based network security service that provides protection for your Azure virtual network resources by acting as a barrier between your virtual network and the internet.

![[Pasted image 20230505173303.png]]

Features - 
1. Public IP Address
2. Buildin high availability
3. Availability Zones
4. Unrestricted cloud scalability
5. Application FQDN filtering rules
6. Network traffic filterring rules
7. Thread intelligence 
8. Azure Monitor integration

# Azure Firewall Implementation
> Implement Hub-Spoke network topology.

![[Pasted image 20230505173813.png]]

**Hub** - Central point of connectivity to your on-premises network.
**Spokes** - Virtaul Networks that peer with Hub.

# Azure Firewall Rules
> By default, Azure Firewall denies all traffic through your virtual network.

Three kinds of rules that you can configure.
1. NAT
2. Network
3. Application
## How rules are processed
Network Rule > Application Rule > NAT Rule

## NAT
> Azure Firewall destination network address translation (DNAT) rules to translate and filter inbound traffic to your subnets. Each rule in your NAT rule collection is used to translate your firewall public IP and port to a private IP and port.

## Network Rules
> Any non-HTTP/S traffic that's allowed to flow through your firewall must have a network rule.

Consider a scenario where resources in one subnet must communicate with resources in another subnet. In this case, you can configure a network rule from the source to the destination.

## Application Rules
> Application rules define fully qualified domain names (FQDNs) that can be accessed from a subnet

Example is when you need to allow Windows Update network traffic through the firewall.


> [!note] Further Reading
>-   Peruse [Azure Firewall documentation](https://learn.microsoft.com/en-us/azure/firewall/).
>-   Discover [Azure Firewall Premium features](https://learn.microsoft.com/en-us/azure/firewall/premium-features).
>-   Understand [Azure Firewall threat intelligence-based filtering](https://learn.microsoft.com/en-us/azure/firewall/threat-intel).
>-   Filter [inbound internet traffic with Azure Firewall DNAT by using the Azure portal](https://learn.microsoft.com/en-us/azure/firewall/tutorial-firewall-dnat).
>-   Explore [Azure Firewall SNAT private IP address ranges](https://learn.microsoft.com/en-us/azure/firewall/snat-private-range).
>-   Deploy and configure [Azure Firewall from the Azure portal](https://learn.microsoft.com/en-us/azure/firewall/tutorial-firewall-deploy-portal).