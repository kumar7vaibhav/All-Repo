---
exam: 104
module: Identity 
---
# Resource Groups
Some important points to note when defining resource groups are outlined here:
• A resource can only belong in a single resource group at any time.
• Resources can be added and removed from a resource group at any time.
• Resource group metadata (the data describing the resource group and resources) is
stored in the region where the resource group is created.
• Resources in a resource group are not bound by the location defined for the
resource group and can be deployed into different regions.
• If the resource group's region is temporarily unavailable, then resources in the
group cannot be updated since the metadata is unavailable. However, resources
deployed in other regions will continue to function as expected, with the caveat that
they cannot be updated or managed.

## Resource Locks
1. CanNotDelete
2. ReadOnly

Permission Required for creating a deleting locks:
- Owner
- User Accesss Administrator

