---
exam: 104
module: Prerequisites 
---
# Template Advantages
1. Templates improve consistency.
2. Templates help express complex deployments.
3. Templates reduce manual, error-prone tasks.
4. Templates promote reuse.
5. Templates are linkable.
6. Templates simplify orchestration.

A Resource Manager template can contain sections that are expressed using JSON notation,
```JSON
{
    "$schema": "http://schema.management.​azure.com/schemas/2019-04-01/deploymentTemplate.json#",​
    "contentVersion": "",​
    "parameters": {},​
    "variables": {},​
    "functions": [],​
    "resources": [],​
    "outputs": {}​
}
```


Here's an example that illustrates two parameters: one for a virtual machine's username, and one for its password:
```JSON
"parameters": {
  "adminUsername": {
    "type": "string",
    "metadata": {
      "description": "Username for the Virtual Machine."
    }
  },
  "adminPassword": {
    "type": "securestring",
    "metadata": {
      "description": "Password for the Virtual Machine."
    }
  }
}
```

# Azure Bicep
> It is Domain-Specific Lanuguage

- Declarative syntac to deploy Azure resources.
## How does Bicep work?
- Write template in Bicep
- Resource Manager still require JSON to work.
- Bicep file is transpilated into JSON
![[Pasted image 20230428163623.png]]

Example - 
```bicep
param location string = resourceGroup().location
param storageAccountName string = 'toylaunch${uniqueString(resourceGroup().id)}'

resource storageAccount 'Microsoft.Storage/storageAccounts@2021-06-01' = {
  name: storageAccountName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    accessTier: 'Hot'
  }
}
```
- Simpler Syntax
- Modules
- Automatic Dependency Management
- Type Validation and Intellisense