---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Application Gateway
> Administrators implement an application gateway to manage traffic to their web apps. Like a load balancer.

![[Pasted image 20230506223518.png]]

Advantages- 
- Application Layer routing
- Round-robin load balancing
- Session stickiness
- Supported protocols
- Firewall protection
- Encryption
- Load autoscaling

Things to know -
- Azure Application Gateway is a service that provides routing options for web applications.
- It offers two primary methods for routing traffic: 
	- path-based routing and multi-site routing. 
- Additionally, it can redirect traffic to another listener or external site and rewrite HTTP headers. 
- It also allows you to create custom error pages instead of default error pages. 
- These features provide flexibility and control for managing web application traffic.

## Path bases routing
> Direct requests for specific URL paths to the appropriate back-end pool.

![[Pasted image 20230506224659.png]]

## Multi-site routing
> Support multiple web apps on the same application gateway instance.

![[Pasted image 20230506224841.png]]

- Multi-site configurations are useful for supporting multi-tenant applications, where each tenant has its own set of virtual machines or other resources hosting a web application.

## Components
> Series of components that combine to route requests to a pool of web servers and to check the health of these web servers. 


![[Pasted image 20230506230158.png]]
Components  include - 
### IP Addresses
> The front-end IP address receives the client requests.

- Your application gateway can have a public or private IP address, or both. 
- You can have only one public IP address and only one private IP address.

### Listeners
> One or more listeners receive the traffic and route the requests to the back-end pool.

- Listeners accept traffic based on a combination of protocol, port, host, and IP address.
- Each listener routes requests to a back-end pool of servers based on your routing rules.
- There are two types of listeners: 
	- Basic and Multi-site.
	- Basic listeners route requests based on the path in the URL.
	- Multi-site listeners can route requests based on the hostname element of the URL.
- Listeners handle TLS/SSL certificates for securing the application between the user and Application Gateway.

### Routing Rules
>Routing rules define how to analyze the request to direct the request to the appropriate back-end pool.

- A routing rule binds listeners to back-end pools.
- It specifies how to interpret hostname and path elements in the URL and direct requests to the appropriate back-end pool.
- A routing rule has an associated set of HTTP settings that determine whether and how traffic is encrypted between Application Gateway and the back-end servers.
- Other configuration information includes protocol, session stickiness, connection draining, request timeout period, and health probes.

### Back-end pools
> A back-end pool contains web servers for resources like virtual machines or Virtual Machine Scale Sets. Each pool has a load balancer to distribute the workload across the resources.

### Health probes
> Health probes determine which back-end pool servers are available for load-balancing.

### Firewall
> An optional firewall checks incoming traffic for common threats before the requests reach the listeners.

> [!note] Further Reading
> ## Learn more
> -   Read about [Azure Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/overview).
> -   Examine [Application Gateway components](https://learn.microsoft.com/en-us/azure/application-gateway/application-gateway-components).
> -   Discover [Application Gateway features](https://learn.microsoft.com/en-us/azure/application-gateway/features).
> -   Read about [Azure Web Application Firewall on Application Gateway](https://learn.microsoft.com/en-us/azure/web-application-firewall/ag/ag-overview).
> -   Explore [Application Gateway redirection routing](https://learn.microsoft.com/en-us/azure/application-gateway/redirect-overview).
> -   Configure an [application gateway to host multiple web sites](https://learn.microsoft.com/en-us/azure/application-gateway/create-multiple-sites-portal).
> -   Rewrite [HTTP headers and URL with Application Gateway](https://learn.microsoft.com/en-us/azure/application-gateway/rewrite-http-headers-url).

