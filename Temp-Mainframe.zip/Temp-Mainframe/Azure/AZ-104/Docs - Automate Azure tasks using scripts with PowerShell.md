---
exam: 104
module: Prerequisites 
---
# How to Choose an administrative tool

There's approximate parity between the portal, the Azure CLI, and Azure PowerShell with respect to the Azure objects they can administer and the configurations they can create. They're also all cross-platform. Typically, you'll consider several other factors when making your choice:

-   **Automation**: Do you need to automate a set of complex or repetitive tasks? Azure PowerShell and the Azure CLI support automation, while Azure portal doesn't.
    
-   **Learning curve**: Do you need to complete a task quickly without learning new commands or syntax? The Azure portal doesn't require you to learn syntax or memorize commands. In Azure PowerShell and the Azure CLI, you must know the detailed syntax for each command you use.
    
-   **Team skillset**: Does your team have existing expertise? For example, your team may have used PowerShell to administer Windows. If so, they'll quickly become comfortable using Azure PowerShell.

# Create an Azure Virtual Machine
```PowerShell
New-AzVm
       -ResourceGroupName <resource group name>
       -Name <machine name>
       -Credential <credentials object>
       -Location <location>
       -Image <image name>
```

# Update VM
```PowerShell
$ResourceGroupName = "ExerciseResources"
$vm = Get-AzVM  -Name MyVM -ResourceGroupName $ResourceGroupName
$vm.HardwareProfile.vmSize = "Standard_DS3_v2"

Update-AzVM -ResourceGroupName $ResourceGroupName  -VM $vm
```

# Delete VM
```PowerShell
# Stop VM
Stop-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName

# Remove VM
Remove-AzVM -Name $vm.Name -ResourceGroupName $vm.ResourceGroupName

# Check Resource Group
Get-AzResource -ResourceGroupName $vm.ResourceGroupName | Format-Table
```

# Azure PowerShell Script
```PowerShell
param([string]$resourceGroup)
$adminCredential = Get-Credential -Message "Enter Login"

For ($i = 1; $i -le 3; $i++)
{
    $vmName = "ConferenceDemo" + $i
    Write-Host "Creating VM: " $vmName
    New-AzVm -ResourceGroupName $resourceGroup -Name $vmName -Credential $adminCredential -Image Canonical:0001-com-ubuntu-server-focal:20_04-lts:latest
}
```

> [!Success] Output
```
Name              : ConferenceDemo1                                                                                  
ResourceGroupName : learn-ed7bc7c4-96f5-4210-8ee8-413b340dd30b
ResourceType      : Microsoft.Compute/virtualMachines
Location          : westus
ResourceId        : /subscriptions/f27a2135-1ae7-44b2-b514-f0b7b1dcbfba/resourceGroups/learn-ed7bc7c4-96f5-4210-8ee8-413b340dd30b/providers/Microsoft.Compute/virtualMachines/ConferenceDemo1
Tags              : 

Name              : ConferenceDemo2
ResourceGroupName : learn-ed7bc7c4-96f5-4210-8ee8-413b340dd30b
ResourceType      : Microsoft.Compute/virtualMachines
Location          : westus
Tags              : 

Name              : ConferenceDemo3
ResourceGroupName : learn-ed7bc7c4-96f5-4210-8ee8-413b340dd30b
ResourceType      : Microsoft.Compute/virtualMachines
Location          : westus
ResourceId        : /subscriptions/f27a2135-1ae7-44b2-b514-f0b7b1dcbfba/resourceGroups/learn-ed7bc7c4-96f5-4210-8ee8413b340dd30b/providers/Microsoft.Compute/virtualMachines/ConferenceDemo3
Tags              : 

```

> [!Note] Check
> `Get-AzResource -ResourceType Microsoft.Compute/virtualMachines`

> [!Note] Clean up
> `Remove-AzResourceGroup -Name MyResourceGroupName`

