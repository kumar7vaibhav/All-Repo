---
exam: 104
module: Identity
---
# Identify Azure Regions
Things to know about regions
- Available in 60 regions and 120 countries.
- Regions provide flexibility and scalability.
- Regions preserve data residency and offer compliance and reiliency options.

# Terms of Region Pairs
1. Physical isolation - at least 300 miles of separation between datacenters in a regional pair.
2. Platform-provided replication - Some services like Geo-Redundant Storage provide automatic replication to the paired region.
3. Region recovery order -  Recovery of one region is prioritized out of every pair.
4. Sequential updates - Planned Azure system updates are rolled out to paired regions sequentially
5. Data residency - Regions reside within the same geography as their enabled set (except for the Brazil South and Singapore regions).

# Obtain an Azure subscription
1. Enterprise Agreement
2. Microsoft Reseller
3. Microsoft Partner
4. Free Account

# Apply Cost Savings
1. Reservations - Pay in advance
2. Azure Hybrid Benefits 
3. Azure Credits - For Visual Studio subscriber, free credits for Azure monthly.
4. Azure Regions - Cost differ by regions.
5. Budgets - Use the inbuilt budgeting tools.
6. Pricing Calculator

