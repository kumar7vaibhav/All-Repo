---
exam: 104
module: Network
---
# Azure Virtual WAN
> Azure Virtual WAN (wide-area network) is a networking service that provides optimized and automated branch connectivity to, and through, Azure.

![[Pasted image 20230506002238.png]]
It allows you to easily connect and manage multiple branch offices to Azure using Site-to-Site VPN, Azure ExpressRoute, or over the public internet using VPN technology.

Two types of virtual WAN
-   **Basic**: A Basic Virtual WAN can be implemented only in an S2S VPN connection.
-   **Standard**: A Standard Virtual WAN can be implemented with Azure ExpressRoute and a User VPN (P2S).

> [!note] Further Reading
> -   Peruse [Azure ExpressRoute documentation](https://learn.microsoft.com/en-us/azure/expressroute/).
> -   Peruse [Azure Virtual WAN documentation](https://learn.microsoft.com/en-us/azure/virtual-wan/).
> -   Find [partners that support connectivity automation with Azure Virtual WAN VPN](https://learn.microsoft.com/en-us/azure/virtual-wan/virtual-wan-locations-partners).

