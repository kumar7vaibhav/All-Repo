---
exam: 104
module: Network 
---
IP addressing schema is a hierarchical naming system used to uniquely identify and locate devices connected to a network using IP addresses. IP addressing schema typically consist of one or more subnets that are identified by a network address and a subnet mask. IP addresses are assigned to devices within a subnet, and they allow devices to communicate with each other within the same network. The IP addressing schema can be either IPv4 or IPv6, and it determines the size of the network and the range of IP addresses that can be assigned to devices. A well-designed IP addressing schema can improve network performance, security, and management.