---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Access Azure Storage
> Files stored in Azure Storage are accessed by clients over HTTP/HTTPS.

Four options are available.
1. Public Access
2. [[Docs - Azure Active Directory#Azure Active Directory|Azure Active Directory]]
3. [[Docs - Azure Storage Security#Create Shared Access Signatures|Shared Access Signature]] (SAS)
4. Shared Key

## Public Access
> Anonymous public read access for containers and blobs

There are two separate settings that affect public access:
-   **The Storage Account.** Configure the storage account to allow public access by setting the _AllowBlobPublicAccess_ property. When set to true, Blob data is available for public access only if the container's public access setting is also set.
    
-   **The Container.** You can enable anonymous access only if anonymous access has been allowed for the storage account. A container has two possible settings for public access: _Public read access for blobs_, or _public read access for a container and its blobs_. Anonymous access is controlled at the container level, not for individual blobs. This means that if you want to secure some of the files, you need to put them in a separate container that doesn't permit public read access.

## Azure Active Directory
Read - [[Docs - Azure Active Directory#Azure Active Directory]]
Use the Azure AD option to securely access Azure Storage without storing any credentials in your code.
Use this form of authentication if you're running an app with managed identities or using security principals.

## Shared Key
> Azure Storage creates two 512-bit access keys for every storage account that's created.

- These keys grant anyone with access the equivalent of root access to your storage.
-  Recommend: Manage storage keys with Azure Key Vault

## Shared access signature
Read - [[Docs - Azure Storage Security#Create Shared Access Signatures]]
>  SAS lets you grant granular access to files in Azure Storage, such as read-only or read-write access, with expiration time.

-  Should be protected in the same manner as an account key.

### Types of SAS
-   **User delegation SAS**: Can only be used for Blob storage and is secured with Azure AD credentials.
-   **Service SAS**: A service SAS is secured using a storage account key. A service SAS delegates access to a resource in any one of four Azure Storage services: Blob, Queue, Table, or File.
-   **Account SAS**: An account SAS is secured with a storage account key. An account SAS has the same controls as a service SAS, but can also control access to service-level operations, such as Get Service Stats.

### How SAS work
A SAS has two components:
1. URI
2. Token

Example
```
https://medicalrecords.blob.core.windows.net/patient-images/patient-116139-nq8z7f.jpg?sp=r&st=2020-01-20T11:42:32Z&se=2020-01-20T19:42:32Z&spr=https&sv=2019-02-02&sr=b&sig=SrW1HZ5Nb6MbRzTbXCaPm%2BJiSEn15tC91Y4umMPwVZs%3D
```

URI
```
https://medicalrecords.blob.core.windows.net/patient-images/patient-116139-nq8z7f.jpg?
```

Token
```
sp=r&st=2020-01-20T11:42:32Z&se=2020-01-20T19:42:32Z&spr=https&sv=2019-02-02&sr=b&sig=SrW1HZ5Nb6MbRzTbXCaPm%2BJiSEn15tC91Y4umMPwVZs%3D
```
The SAS token contains other components, or query parameters.

# Stored Access Policy
> Use stored access policies to delegate access to Azure Storage

You can create a stored access policy on four kinds of storage resources:
-   Blob containers
-   File shares
-   Queues
-   Tables

The stored access policy you create for a blob container can be used for all the blobs in the container and for the container itself. A stored access policy is created with the following properties:

-   **Identifier**: The name you use to reference the stored access policy.
-   **Start time**: A DateTimeOffset value for the date and time when the policy might start to be used. This value can be null.
-   **Expiry time**: A DateTimeOffset value for the date and time when the policy expires. After this time, requests to the storage will fail with a 403 error-code message.
-   **Permissions**: The list of permissions as a string that can be one or all of **acdlrw**.