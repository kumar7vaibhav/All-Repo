---
exam: 104
module: Compute
---
# Azure Container Instances
> Container-based virtualization allows you to virtualize the operating system. This approach lets you run multiple applications within the same instance of an operating system, while maintaining isolation between the applications. 

![[Pasted image 20230504173556.png]]

Things ot know about Azure container instances
-  start in seconds without the need to provision and manage virtual machines.
- Containers can be directly exposed to the internet with an IP address and FQDN
- Container applications are as isolated in a container
- Container nodes can be scaled dynamically
-  Containers support direct mounting of Azure Files file shares.
- Instances can schedule both Windows and Linux containers

# Container Groups
> A container group is a collection of containers that get scheduled on the same host machine.

- A container group is similar to a pod in Kubernetes.
-  Two common ways to deploy a multi-container group: Azure Resource Manager (ARM) templates and YAML files.
	- Azure Resource Manager Template - When you want deploy containers along with other Azure services.
	- YAML Files - When you want to deploy just containers.
- Containers in a group share a port namespace.
![[Pasted image 20230504174326.png]]

> [!note] Further Reading
>-   Compare [containers for Windows versus virtual machines](https://learn.microsoft.com/en-us/virtualization/windowscontainers/about/containers-vs-vm).
>-   Peruse [Azure Container Instances documentation](https://learn.microsoft.com/en-us/azure/container-instances/).
 Learn more with self-paced training
>-   Complete an [introduction to Docker containers](https://learn.microsoft.com/en-us/training/modules/intro-to-docker-containers/).
>-   Build a containerized web application with Docker.

