---
exam: 104
module: Monitor 
---
# Log Analytic Uses
> Tool for [[Docs - Azure Monitor|Azure Monitor]] that's available in the Azure portal. 

- Edit and run log queries for the data collected in [[Docs - Azure Monitor#Logs|Azure Monitor Logs]]
- Log Analytics offer query features and tools
- Supports KQL (Kusto Query Language).

# Log Analytics Workspace
>  Captured logs and data in Azure Monitor are stored in a Log Analytics workspace. 


> [!note] Further Reading
> -   Read about [Log Analytics in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-overview).
> -   Explore the [Kusto Query Language (KQL)](https://learn.microsoft.com/en-us/azure/data-explorer/kusto/query/).
> -   Create a [Log Analytics workspace (Azure portal, PowerShell, the Azure CLI, or Azure Resource Manager (ARM) template)](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/quick-create-workspace).
> -   Get started with [log queries in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/get-started-queries).
> -   Get started with [Log Analytics](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-tutorial).
> -   Discover how to [analyze and visualize data](https://learn.microsoft.com/en-us/azure/azure-monitor/best-practices-analysis).
> -   Explore the [KQL quick reference](https://learn.microsoft.com/en-us/azure/data-explorer/kql-quick-reference).
> -   Explore the [Azure Monitor Logs table reference](https://learn.microsoft.com/en-us/azure/azure-monitor/reference/tables/tables-category).
> -   Explore the [Log Analytics REST API reference](https://learn.microsoft.com/en-us/rest/api/loganalytics/).

