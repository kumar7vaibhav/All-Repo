---
exam: 104
module: Identity 
---
> Creating and Managing Governance
# Azure Policy
Mechanism for effecting organizational compliance.

## How does Azure Policy work?
Assesses compliance by comparing resource properties to business rule defined in a JSON format. These are known as policy definitions.

## Policy initiative
Grouping of definitions that align with business objectives. 

## Policy Assignment
Azure policy resides above the subscription and management group layers and it can therefore be assigned to various scope levels.

## Azure Policy vs RBAC
- Azure Policy focuses on resource properties.
- RBAC focuses on user actions at different scopes.