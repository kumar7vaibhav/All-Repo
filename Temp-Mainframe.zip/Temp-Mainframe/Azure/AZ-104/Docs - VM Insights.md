---
exam: 104
module: Monitor 
---
# Azure Monitor VM Insights
> Azure Monitor VM Insights is a feature of Azure Monitor that relies on Azure Monitor Logs.
> A feature that provides a predefined, curated monitoring experience, with little configuration required.


- Azure Monitor VM Insights use a table named InsightsMetrics.
- 