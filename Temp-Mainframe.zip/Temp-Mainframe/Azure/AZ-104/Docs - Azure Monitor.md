---
exam: 104
module: Monitor 
---
```dataviewjs
dv.view('toc')
```
# Azure Monitor - Capabilities
> Azure Monitor provides you with a comprehensive solution for collecting, analyzing, and responding to telemetry data from your on-premises and cloud environments.

![[Pasted image 20230508201524.png]]

> [!tip] Things to know

Azure Monitor provides features and capabilities in three areas:
1. Monitor and visualize metrics
2. Query and analyze logs
3. Set up alerts and actions

# Azure Monitor Components 
> The monitoring and diagnostic services offered in Azure are divided into broad categories such as Core, Application, Infrastructure, and Shared Capabilities.

[[Docs - Monitoring Services#Azure Monitor]]

![[Pasted image 20230508210417.png]]

- Data stores in Azure Monitor hold your metrics and logs. The two base types of data used by the service. 
	- Azure Monitor Metrics
		- **Metrics** are numerical values that describe some aspect of a system at a particular point in time. 
		- Metrics are lightweight and capable of supporting near real-time scenarios.
	- Azure Monitor Logs
		- **Logs** contain different kinds of data organized into records with different sets of properties for each type. 
		- Data like events and traces are stored as logs along with performance data so all the data can be combined for analysis.
- Various monitoring sources provide Azure Monitor with the metrics and data to analyze.
- Azure Monitor Insights performs different functions with the collected data, including analysis, alerting and streaming to external systems.

## Metrics
![[Pasted image 20230508211341.png]]

## Logs
![[Pasted image 20230508211350.png]]

# Monitoring Data Tiers
> 1. Application
> 2. Guest OS
> 3. Azure Resource
> 4. Azure Subscription
> 5. Azure tenant

# Activity log events
> The Azure Monitor activity log is a subscription log that provides insight into subscription-level events

- Activity logs are kept for 90 days.

![[Pasted image 20230508212243.png]]


> [!note] Further Reading
> ## Learn more
>-   Peruse [Azure Monitor documentation](https://learn.microsoft.com/en-us/azure/azure-monitor/).
>-   Explore [Azure Monitor Metrics](https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/data-platform-metrics) and [Azure Monitor Logs](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/data-platform-logs).
>-   Discover [Azure Monitor Insights](https://learn.microsoft.com/en-us/azure/azure-monitor/insights/insights-overview).
>-   Read about [Log Analytics in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/log-analytics-overview).
>-   Get started with [metrics explorer in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/metrics-getting-started).
>-   Get started with [log queries in Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/get-started-queries).
>-   Use queries in [Azure Monitor Logs (Log Analytics)](https://learn.microsoft.com/en-us/azure/azure-monitor/logs/queries).
>-   Monitor [virtual machines with Azure Monitor](https://learn.microsoft.com/en-us/azure/azure-monitor/vm/monitor-virtual-machine).
>-   View the [schema for Azure Monitor activity log events and categories](https://learn.microsoft.com/en-us/azure/azure-monitor/essentials/activity-log-schema).
>-   Review [types of Azure Monitor alerts](https://learn.microsoft.com/en-us/azure/azure-monitor/alerts/alerts-types).

