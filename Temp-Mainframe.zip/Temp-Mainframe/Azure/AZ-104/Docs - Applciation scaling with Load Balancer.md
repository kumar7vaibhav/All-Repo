---
exam: 104
module: Network 
---

# Azure Load Balancer features and capabilities

Azure Load Balancer, you can spread user requests across multiple virtual machines or other services, allowing you to scale the app to larger sizes than a single virtual machine can support, and ensuring that users get service even when a virtual machine fails.

## Distribute traffic with Azure Load Balancer
Load balancers use a hash-based distribution algorithm. By default, a five-tuple hash is used to map traffic to available servers. 

The hash is made from the following elements:
-   **Source IP**: The IP address of the requesting client.
-   **Source port**: The port of the requesting client.
-   **Destination IP**: The destination IP of the request.
-   **Destination port**: The destination port of the request.
-   **Protocol type**: The specified protocol type, TCP or UDP.

![[Pasted image 20230507025641.png]]

Load balancers aren't physical instances. Load balancer objects are used to express how Azure configures its infrastructure to meet your requirements.

With Load Balancer, you can use [[Docs - Virtual Machine Availability#Availablity Sets|availability sets]] and [[Docs - Virtual Machine Availability#Availability Zones|availability zones]] to ensure that virtual machines are always available.

![[Pasted image 20230507025833.png]]

![[Pasted image 20230507025846.png]]

## Internal and external load balancers
> An external load balancer operates by distributing client traffic across multiple virtual machines. 
> An external load balancer permits traffic from the internet. 

>An internal load balancer distributes a load from internal Azure resources to other Azure resources. 
>No traffic is allowed from internet sources. 

![[Pasted image 20230507030206.png]]