---
exam: 104
module: Identity
---
# What is SSPR?
With SSPR, users can reset their passwords in a web browser or from a Windows sign-in screen to regain access

# How SSPR works?
User initiates a password reset by
1. Going to password reset portal.
2. Going to 'Can't access your account' link.

## Steps taken by the reset portal
1. Localization
2. Verification
3. Authentication
4. Password Reset
5. Notification

## Authenticate Password Reset
1. Mobile App Notification
2. Mobile app code
3. Email - Sends a codde to address
4. Mobile Phone - SMS/call
5. Office Phone - Call
6. Security questions 

## Require minimum number of authentication methods
You can specify the minimum number of methods that the user must set up: one or two.
For the security question method, you can specify a minimum number of questions.

## Accounts associated with administrator roles
-   A strong, two-method authentication policy is always applied to accounts with an administrator role, regardless of your configuration for other users.
-   The security questions method isn't available to accounts that are associated with an administrator role.

