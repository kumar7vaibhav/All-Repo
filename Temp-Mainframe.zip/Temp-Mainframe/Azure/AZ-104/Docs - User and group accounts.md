---
exam: 104
module: Identity
---
# Create User Accounts
 A user account has all the information required to authenticate the user during the sign-in process.

Types of user accounts - 
1. Cloud Identity - A user account with a _cloud identity_ is defined only in Azure AD.
2. Directory-Synchronized Identity - Defined in an on-premises Active Directory. Synced with Azure AD. 
3. Guest User - _Guest user_ accounts are defined outside Azure. The source for guest user accounts is Invited user.

# Manage User Accounts
![[Pasted image 20230429234430.png]]
User accounts can also be added to Azure AD through Microsoft 365 Admin Center, Microsoft Intune admin console, and the Azure CLI.

# Create bulk user accounts
![[Pasted image 20230429234550.png]]
> Only Global administrators or User administrators have privileges to create and delete user accounts in the Azure portal.

# Create group accounts
Azure Active Directory (Azure AD) allows your organization to define two different types of group accounts. 
## Security group
Used to manage member and computer access to shared resources for a group of users. You can create a security group for a specific security policy and apply the same permissions to all members of a group. 
## Microsoft 365 groups
Provide collaboration opportunities. Group members have access to a shared mailbox, calendar, files, SharePoint site, and more.
# Consider when adding group members
## Assigned
Add specific users as members of a group, where each user can have unique permissions.
## Dynamic
1. **Dynamic User** -  If the member attributes no longer meet the rule requirements, the member is removed.
2. **Dynamic Device** -  If the device attributes no longer meet the rule requirements, the device is removed.

