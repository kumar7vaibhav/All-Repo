---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Azure Storage
> Azure Storage is a service that you can use to store files, messages, tables, and other types of information.

## Categories
1. Virtual Machine Data
2. Unstructured Data
3. Structured Data

## Storage Account Tiers
1. Standard - HDD
2. Permium - SSD

# Azure Storage Services
1. Azure Blob
2. Azure Files
3. Azure Queue
4. Azure Table Storage
![[Pasted image 20230519163913.png]]

## Azure Blob Storage 
> [[Docs - Azure Storage#Azure Blob Storage Fundamentals|Blob Storage]] is optimized for storing massive amounts of unstructured or _non-relational_ data using NFS protocol.

## Azure Files Storage
> [[Docs - Azure Storage#[Azure File Fundamentals](https://docs.microsoft.com/en-us/learn/modules/azure-storage-fundamentals/azure-file-storage)|Azure Files]] enables you to set up highly available network file shares. 
> Shares can be accessed by using the Server Message Block (SMB) protocol and the Network File System (NFS) protocol

## Azure Queue Storage
> Azure Queue Storage is used to store and retrieve messages.
- Queue messages can be up to 64 KB in size, and a queue can contain millions of messages. 
- Queues are used to store lists of messages to be processed asynchronously.

## Azure Table Storage 
([[Docs - Azure Cosmos DB]])
> Azure Table Storage is now part of Azure Cosmos DB, which is a fully managed NoSQL database service for modern app development.

# Replication Strategies

We'll explore four replication strategies:
## 1.  Locally redundant storage (LRS)
This is storage within a single Azure datacenter. It's good for workloads that don't require high levels of data durability.

## 2.  Zone redundant storage (ZRS)
This type of storage replicates data across multiple Azure datacenters within a single region. It's more durable than LRS and provides protection against datacenter-level failures.

## 3.  Geo-redundant storage (GRS)
This storage type is used for disaster recovery. It replicates data to a paired Azure region located far away, so that if a whole region goes offline, data is still available.

## 4.  Geo-zone-redundant storage (GZRS)
This is the highest level of durability and availability. It replicates data across multiple Azure datacenters in two or more regions. This protects against both datacenter and region-level failures.

# Access Storage
> Every object you store in Azure Storage has a unique URL address.

The combination of the subdomain and the domain name, which is specific to each service, forms an endpoint for your storage account.
To access the _myblob_ data in the _mycontainer_ location in your storage account, we use the following URL address:
`//`**`mystorageaccount`**`.blob.core.windows.net/`**`mycontainer`**`/`**`myblob`**.
## Configure Custom Domains
Two types -
1. **Direct mapping** - enable a custom domain for a subdomain to an Azure storage account.
2. **Intermediary domain mapping** - is applied to a domain that's already in use within Azure