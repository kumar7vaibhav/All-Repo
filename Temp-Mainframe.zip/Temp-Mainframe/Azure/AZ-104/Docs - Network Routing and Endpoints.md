---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
Azure virtual networking provides capabilities to help you customize your network routes, establish service endpoints, and access private links.

# System Routes
> Azure uses _system routes_ to direct network traffic between virtual machines, on-premises networks, and the internet using route table.

- A route table contains a set of rules (called routes) that specifies how packets should be routed in a virtual network.
- Packets are matched to routes by using the destination. 
	- The destination can be an IP address, a virtual network gateway, a virtual appliance, or the internet.
- When a matching route can't be found, the packet is dropped.
![[Pasted image 20230506003306.png]]

# User Defined Routes
> User-Defined Routes (UDRs) allow you to customize the routing of network traffic in a virtual network.

![[Pasted image 20230506003709.png]]

- UDRs control network traffic by defining routes that specify the _next hop_ of the traffic flow.
- The next hop can be one of the following targets:
    - Virtual network gateway
    - Virtual network
    - Internet
    - Network virtual appliance (NVA)
- Similar to system routes, UDRs also access route tables.
- Each route table can be associated to multiple subnets.
- Each subnet can be associated to one route table only.
- There are no charges for creating route tables in Microsoft Azure.

# Service Endpoint
> A virtual network _service endpoint_ provides the identity of your virtual network to the Azure service.

Service endpoints are a way to secure Azure service resources by extending virtual network identity. This is done through virtual network rules which remove public internet access and only allow traffic from the virtual network. Service endpoints take traffic directly from the virtual network to the service on the Azure backbone network and are configured through the subnet without requiring extra overhead.

![[Pasted image 20230506004319.png]]

# Azure Private Link
>Azure Private Link provides private connectivity from a virtual network to Azure platform as a service (PaaS), customer-owned, or Microsoft partner services.

It provides a secure and scalable way to access services over a private endpoint in your virtual network, instead of over the public internet. This helps to ensure that traffic to and from the service remains within the Microsoft Azure network, providing greater security and isolation for your resources.

- Azure Private Link keeps all traffic on the Microsoft global network. There's no public internet access.
- Private Link is global and there are no regional restrictions. You can connect privately to services running in other Azure regions.
- Services delivered on Azure can be brought into your private virtual network by mapping your network to a private endpoint.
- Private Link can privately deliver your own services in your customer's virtual networks.
- All traffic to the service can be routed through the private endpoint. No gateways, NAT devices, Azure ExpressRoute or VPN connections, or public IP addresses are required.

![[Pasted image 20230506004824.png]]

> [!note] Further Reading
> -   Peruse [virtual network traffic routing documentation](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-networks-udr-overview).
> -   Read about [Virtual network traffic routing](https://learn.microsoft.com/en-us/azure/virtual-network/virtual-networks-udr-overview).
> -   Route [network traffic with a route table by using the Azure portal](https://learn.microsoft.com/en-us/azure/virtual-network/tutorial-create-route-table-portal).
> -   Configure [BGP for Azure VPN Gateway by using PowerShell](https://learn.microsoft.com/en-us/azure/vpn-gateway/vpn-gateway-bgp-resource-manager-ps).
> -   Create [custom routes](https://learn.microsoft.com/en-us/azure/virtual-network/manage-route-table#create-a-route).
> -   View [all routes for a subnet and diagnose virtual machine routing problems](https://learn.microsoft.com/en-us/azure/virtual-network/diagnose-network-routing-problem).
> -   Determine [the next hop type between a virtual machine and a destination IP address](https://learn.microsoft.com/en-us/azure/network-watcher/diagnose-vm-network-routing-problem#use-next-hop).
> -   Explore [user-defined routes and forced-tunneling in Azure Firewall](https://learn.microsoft.com/en-us/azure/firewall/forced-tunneling).

