---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```

# Storage Explorer
> Storage Explorer is a GUI application used to simplify access and management of data stored in Azure storage accounts.

# Azure Storage Types
Read [[Docs - Azure Storage]] and [[Docs - Introduction#Storage]]

- **Azure Blob Storage**. Blob storage is used to store unstructured data as a binary large object (blob).
- **Azure Table Storage**. Table storage is used to store NoSQL, semi-structured data.
- **Azure Queue Storage**. Queue storage is used to store messages in a queue, which can then be accessed and processed by applications through HTTP(S) calls.
- **Azure Files**. Azure Files is a file-sharing service that enables access through the Server Message Block protocol, similar to traditional file servers.
- **Azure Data Lake Storage**. Azure Data Lake, based on Apache Hadoop, is designed for large data volumes and can store unstructured and structured data. Azure Data Lake Storage Gen1 is a dedicated service. Azure Data Lake Storage Gen2 is Azure Blob Storage with the hierarchical namespace feature enabled on the account.

# Local emulators
> During the development phase of your project, you might not want developers to incur additional costs by using Azure storage accounts. In those cases, you can use a locally based emulator.

Storage Explorer supports two emulators: Azure Storage Emulator and Azurite.
- Azure Storage Emulator uses a local instance of Microsoft SQL Server 2012 Express LocalDB. It emulates Azure Table, Queue, and Blob storage.
- Azurite, which is based on Node.js, is an open-source emulator that supports most Azure Storage commands through an API.

Requirements - 
- Emulator should be running before you open Storage Explorer.
- To connect - choose **Attach to a local emulator** connection type

# Connection to Azure
> You can use Storage Explorer with only the read data role.

You need two permissions to access your Azure storage account: management and data.
	- The data layer is used to access blobs, containers, and other data resources.
	- The management role grants access to see lists of your various storage accounts, containers, and service endpoints.

> [!info] To learn more about Storage Explorer, see the following articles:
> -   [Azure Storage Explorer download](https://azure.microsoft.com/features/storage-explorer/)
> -   [Use Azure Storage Explorer to manage directories, files, and ACLs in Azure Data Lake Storage Gen2](https://learn.microsoft.com/en-us/azure/storage/blobs/data-lake-storage-explorer)

