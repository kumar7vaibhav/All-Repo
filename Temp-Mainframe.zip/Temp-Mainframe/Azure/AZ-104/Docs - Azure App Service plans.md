---
exam: 104
module: Compute 
---
# Azure App Service plan
> An App Service plan defines a set of compute resources for a web application to run.

Comparing this to an on premises environment, the app service environment is the server, or servers on which your application is deployed.

Each App Service plan defines three settings:
-   **Region**: The region for the App Service plan, such as West US, Central India, North Europe, and so on.
-   **Number of VM instances**: The number of virtual machine instances to allocate for the plan.
-   **Size of VM instances**: The size of the virtual machine instances in the plan, including Small, Medium, or Large.

Pricing Tiers
![[Pasted image 20230504001101.png]]

There are two methods for scaling your Azure App Service plan and applications: _scale up_ and _scale out_.

# Azure App Service Autoscale
> The autoscale process allows you to have the right amount of resources running to handle the load on your application

- Specify the minimum, and maximum number of instances to run by using a set of rules
- Autoscale rules include a trigger and a scale action (in or out). The trigger can be metric-based or time-based.
	- **Metric-based** rules measure application load and add or remove virtual machines based on the load.
	- **Time-based** rules (or, schedule-based) allow you to scale when you see time patterns in your load and want to scale before a possible load increase or decrease occurs. 

> [!note] Further Reading
>  Learn more
>-   Read about [Azure App Service plans](https://learn.microsoft.com/en-us/azure/app-service/overview-hosting-plans).
>-   Manage [App Service plans in Azure](https://learn.microsoft.com/en-us/azure/app-service/app-service-plan-manage).
>-   Scale up [applications in Azure App Service](https://learn.microsoft.com/en-us/azure/app-service/manage-scale-up).

