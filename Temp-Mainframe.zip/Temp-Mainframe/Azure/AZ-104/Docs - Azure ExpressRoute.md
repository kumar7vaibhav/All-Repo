---
exam: 104
module: Network 
---
# Azure ExpressRoute
> Azure ExpressRoute provides a high-speed private connection to connect your on-premises networks to Microsoft cloud services.

Read - [[02 Knowledge/Microsoft/Azure/AZ-900/Docs - Azure ExpressRoute]]
![[Pasted image 20230506001300.png]]

Site-to-site VPN traffic travels encrypted over the public internet
![[Pasted image 20230506001912.png]]

# ExpressRoute connection models

1.  **Colocation at a cloud exchange**: This involves physically colocating your networking equipment at a cloud exchange provider's facility, where you can directly connect to the Microsoft cloud over high-speed, low-latency connections.
2.  **Point-to-point Ethernet connection**: This option involves setting up a dedicated, private connection between your on-premises network and the Microsoft cloud over an Ethernet link. This connection can be used for high-speed data transfer and low-latency communication.
3.  **Any-to-any (IPVPN) connection**: This involves using a virtual private network (VPN) to securely connect your on-premises network to the Microsoft cloud. This option provides the flexibility to connect to the cloud from any location using an internet connection.