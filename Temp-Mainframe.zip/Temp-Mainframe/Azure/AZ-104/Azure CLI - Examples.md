---
exam: 104
module: Prerequisites 
---
# Examples
```powershell
# Log in to Azure
az login
```

```
# Set the active subscription
az account set --subscription <subscription_id>
```

```
# Create a new resource group
az group create --name <resource_group_name> --location <location>
```

```
# Create a new virtual machine
az vm create --name <vm_name> --resource-group <resource_group_name> --image <image_name> --admin-username <username> --admin-password <password>
```

```
# List virtual machines
az vm list --output table
```

```
# Delete a resource group and all its resources
az group delete --name <resource_group_name> --yes
```

```
# Create a new Azure App Service
az webapp create --name <app_service_name> --resource-group <resource_group_name> --plan <app_service_plan_name> --runtime <runtime>
```

```
# View the logs for an Azure App Service
az webapp log tail --name <app_service_name> --resource-group <resource_group_name>
```

# Lab
## Create Resource Group
```PowerShell
# Variables
LOCATION = $(az group show --name 'LocalPS' --query location --out tsv)
RGNAME = 'LocalPS2'

# Create Command
az group create --name $RGNAME --location $LOCATION
```

## Create Managed Disk
```powershell
# variables
DISKNAME = 'somedisk'

# Create command
az disk create \
--resource-group $RGNAME \
--name $DISKNAME \
--sku 'Standard_LRS' \
--size-gb 32
```

Show disk
```PowerShell
az disk show --resource-group $RGNAME --name $DISKNAME
```

## Update the disk configuration
```PowerShell
az disk update --resource-group $RGANAME --name $DISKNAME --size-gb 64
```

