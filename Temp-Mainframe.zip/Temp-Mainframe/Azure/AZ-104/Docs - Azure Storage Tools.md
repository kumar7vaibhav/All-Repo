---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Azure Storage Explorer
> With Azure Storage Explorer, you can access multiple accounts and subscriptions, and manage all your Storage content.

- Azure Storage Explorer requires both management (Azure Resource Manager) and data layer permissions to allow full access to your resources.
- Azure Storage Explorer lets you attach to external storage accounts so storage accounts can be easily shared.
- Access keys provide access to the entire storage account.
- You're provided two access keys.
- We recommend regenerating your access keys regularly.
- You must update any Azure resources and applications to use the new keys.

# Azure Import/Export Service
>  Securely import large amounts of data to Azure Blob Storage and Azure Files by shipping disk drives to an Azure datacenter

## Azure Import Jobs
> Create Import Job. Staff Uploads the data to cloud at datacenter.

![[Pasted image 20230501225501.png]]
Install the WAImportExport tool on the disks.

## Azure Export Jobs
> Create Export Job. Staff Downloads the data from cloud at datacenter.

![[Pasted image 20230501225540.png]]

# WAImportExport tool
> Import/Export service tool used to prepare drives before importing data, and to repair any corrupted or missing files after data transfer.

> [!note] The WAImportExport tool is available in two versions:
> Version 1 is best for importing and exporting data in Azure Blob Storage. 
> Version 2 is best for importing data into Azure Files.

-   Before you create an [[Docs - Azure Storage Tools#Azure Import Jobs|Import job]], use the WAImportExport tool to copy data to the hard disk drives you intend to ship to Microsoft.

# AzCopy tool
Command-line utility for copying data to and from [[Docs - Storage Accounts#Azure Blob Storage|Azure Blob Storage]] and [[Docs - Azure Storage#Azure File Fundamentals|Azure Files]]

![[Pasted image 20230501231611.png]]
```console
azcopy copy [source] [destination] [flags]
```

> [!Note] Further Reading
>-   Get started [with Azure Storage Explorer](https://learn.microsoft.com/en-us/azure/vs-azure-tools-storage-manage-with-storage-explorer?tabs=windows).
>- Get started [with the AzCopy tool](https://learn.microsoft.com/en-us/azure/storage/common/storage-use-azcopy).
>- Read about [the Azure Import/Export service](https://azure.microsoft.com/documentation/articles/storage-import-export-service/).
>- Choose [an Azure solution for data transfer](https://learn.microsoft.com/en-us/azure/storage/common/storage-choose-data-transfer-solution).
>-   Set up [the Azure Import/Export service and WAImportExport tool](https://learn.microsoft.com/en-us/azure/import-export/storage-import-export-tool-setup-v1).
>-   Download [Azure Storage Explorer](https://azure.microsoft.com/products/storage/storage-explorer/).
>-   Download the [Microsoft Azure Import/Export service](https://www.microsoft.com/download/details.aspx?id=42659).

