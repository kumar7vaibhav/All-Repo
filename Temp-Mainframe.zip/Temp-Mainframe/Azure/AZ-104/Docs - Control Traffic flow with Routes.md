---
exam: 104
module: Network 
---
# Azure Routing
>Network traffic in Azure is automatically routed across Azure subnets, virtual networks, and on-premises networks. This routing is controlled by system routes, which are assigned by default to each subnet in a virtual network.

The following diagram shows an overview of system routes and shows how traffic flows among subnets and the internet by default

![[Pasted image 20230507023928.png]]

Within Azure, there are other system routes. Azure will create these routes if the following capabilities are enabled:

-   [[Docs - Azure Virtual Network Peering|Virtual network peering]]
-   Service chaining
  ![[Pasted image 20230507024307.png]]
    
-   [[02 Knowledge/Microsoft/Azure/AZ-104/Docs - Azure VPN Gateway#Virtual Network Gateway|Virtual network gateway]]
  ![[Pasted image 20230507024323.png]]
  
-   [[Docs - Network Routing and Endpoints#Service Endpoint|Virtual network service endpoint]]

## Border gateway protocol
> A network gateway in your on-premises network can exchange routes with a virtual network gateway in Azure by using BGP

![[Pasted image 20230507024450.png]]

# Route selection and priority
Azure selects the route based on the type in the following order of priority:
1.  User-defined routes
2.  BGP routes
3.  System routes

# Network Virtual Appliance
>Network virtual appliances (NVAs) are virtual machines that control the flow of network traffic by controlling routing.

Consists of various layers like:
-   a firewall
-   a WAN optimizer
-   application-delivery controllers
-   routers
-   load balancers
-   IDS/IPS
-   proxies

You can configure a Windows virtual machine and enable IP forwarding after routing tables, user-defined routes, and subnets have been updated. Or you can use a partner image from Azure Marketplace.