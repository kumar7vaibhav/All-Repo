---
exam: 104
module: Identity
---
# What are user accounts in Azure AD?
> A user's account access consists of the type of user, their role assignments, and their ownership of individual objects.

Azure AD uses permissions to help you control the access rights a user or group is granted. This is done through roles.

1. Administrator Role
2. Member Users
3. Guest Users

# Add User Accounts
Add using PowerShell or Cli
```
# Create new user
az ad user create
```
```PowerShell
New-AzureADUser
```

# Delete User
```
az ad user delete
```
```PowerShell
Remove-AZADUser
```
When you delete a user, the account remains in a suspended state for 30 days. During that 30-day window, the user account can be restored.

# Access management
[[Docs - Role-Based Access Control#AD Roles vs RBAC Roles|AD Roles vs RBAC]]
-   **Azure AD roles**: Use Azure AD roles to manage Azure AD-related resources like users, groups, billing, licensing, application registration, and more.
-   **Role-based access control (RBAC) for Azure resources**: Use RBAC roles to manage access to Azure resources like virtual machines, SQL databases, or storage. For example, you could assign an RBAC role to a user to manage and delete SQL databases in a specific resource group or subscription.

There are different ways you can assign access rights:
-   **Direct assignment**: Assign a user the required access rights by directly assigning a role that has those access rights.
-   **Group assignment**: Assign a group the required access rights, and members of the group will inherit those rights.
-   **Rule-based assignment**: Use rules to determine a group membership based on user or device properties.

> [!Info] Further Reading
> [Assign user roles](https://learn.microsoft.com/en-us/azure/active-directory/fundamentals/active-directory-users-assign-role-azure-portal)

