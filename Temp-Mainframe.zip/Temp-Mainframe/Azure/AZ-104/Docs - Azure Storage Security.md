---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```

# Review Azure Storage security strategies 
- Encryption - All data is encrypted.
- Authentication - Use Azure AD and Azure RBAC to manage storage access.
- Data between transit is secured by Client-side encryption, HTTPS and SMB 3.0
- Delegate access using Shared Access Signature (SAS)

# Create Shared Access Signatures
> A shared access signature (SAS) is a uniform resource identifier (URI)
> Grants restricted access rights to Azure Storage resources

- Granular control over type of access. 
- Account level SAS can delegate access to multiple storage services.
- Can specify the time interval for which the SAS is valid.

Types of control SAS provides- 
1. Account Level
   Delegates access to resources in one or more Azure storage services.
2. Service Level
   Delegates access to a resource in only one Azure Storage service.
Optional - 
- IP Addresses
- Protocols

# Configure Customer-Managed Keys
In the Azure portal, you can configure customer-managed encryption keys.
![[Pasted image 20230501193453.png]]

> [!note] Futher Reading
> [SAS](https://learn.microsoft.com/en-us/azure/storage/common/storage-sas-overview)
> [Customer Managed Keys](https://learn.microsoft.com/en-us/azure/storage/common/customer-managed-keys-overview)
> 