---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Plan for Maintenance and Donwtime

- An **unplanned hardware maintenance** event occurs when the Azure platform predicts that the hardware or any platform component associated to a physical machine is about to fail
- **Unexpected downtime** occurs when the hardware or the physical infrastructure for your virtual machine fails unexpectedly.
- **Unexpected downtime** occurs when the hardware or the physical infrastructure for your virtual machine fails unexpectedly.

# Availablity Sets
> An availability set is a logical feature you can use to ensure a group of related virtual machines are deployed together.

- All VMs in Availability set perform identical set of functions.
- All VMs in Availability set should have same software installed.
- Azure ensure that VMs in Availability set are run across different hardwares to minimize hardware failure impact.
- Can create VM and Availability set at the same time.

## Update Domain
>  Groups of virtual machines and underlying physical hardware that can be rebooted at the same time.

- During planned maintenance, only one update domain is rebooted at a time.
- By default there are 5 update domains
- You can configure upto 20.
## Fault Domain
> Group of virtual machines that share a common power source and network switch.

- Two fault domains work together to mitigate against hardware failures, network outages, power interruptions, or software updates.
![[Pasted image 20230503230731.png]]
# Availability Zones
> Protects your applications and data from datacenter failures

Read - [[Docs - Architechtural Components#Azure Availability Zones]]
- Availability zones are unique physical locations within an Azure region.
- Each zone is made up of one or more datacenters
- There's a minimum of three separate zones in all enabled regions
- Zone-redundant services replicate your data across availability zones to protect against single-points-of-failure.

Azure services that support availability zones are divided into two categories.

| Category                | Examples                | 
| ----------------------- | ----------------------- |
| Zonal Services          | VM, Disks, IP Addresses |
| Zone-redundant services | Storage, SQL databases  |


# Vertical Scaling
> Increasing or decreasing the virtual machine **size** in response to a workload
> Single machine becomes more powerful.

![[Pasted image 20230503232119.png]]

# Horizontal Scaling
> Adjust the **number** of virtual machines in your configuration to support the changing workload.
> Strength in numbers.

![[Pasted image 20230503232239.png]]

# Azure Virtual Machine Scale Sets
> Virtual Machine Scale Sets automatically changes the number of identical virtual machine instances as demand changes.

- All virtual machine instances are created from the same base operating system image and configuration
- Virtual Machine Scale Sets support up to 1,000 virtual machine instances.
	- If you create and upload your own custom virtual machine images, the limit is 600 virtual machine instances.

> [!Note] Further Reading
> ## Learn more
> -   Review [availability options for Azure Virtual Machines](https://learn.microsoft.com/en-us/azure/virtual-machines/availability). 
>-   Read about [autoscale with Azure Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-autoscale-overview).
>-   Deploy [your application on Azure Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-deploy-app).
>-   Choose [the right number of fault domains for Azure Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/azure/virtual-machine-scale-sets/virtual-machine-scale-sets-manage-fault-domains).
>-   Explore the [Custom Script Extension for Windows virtual machines](https://learn.microsoft.com/en-us/azure/virtual-machines/extensions/custom-script-windows).
>-   Use the [Azure Custom Script Extension Version 2 with Linux virtual machines](https://learn.microsoft.com/en-us/azure/virtual-machines/extensions/custom-script-linux).
Learn more with self-paced training
>-   Build a [scalable application with Azure Virtual Machine Scale Sets](https://learn.microsoft.com/en-us/training/modules/build-app-with-scale-sets/). _Azure subscription required_.
>-   Implement [scale and high availability with Windows Server virtual machines](https://learn.microsoft.com/en-us/training/modules/implement-high-availability-of-windows-server-vms/).

