---
exam: 104
module: Prerequisites 
---
# Create Resource Group
1. Connect account - `Connect-AzAccount`
2. Create Resource Group
```PowerShell
$location = (Get-AzResourceGroup -Name 'TestGroup').Location
$rgName = 'TestGroup'
New-AzResourceGroup -Name $rgName -Location $location
```

```
ResourceGroupName : LocalPS
Location          : centralindia
ProvisioningState : Succeeded
Tags              :  Name   Value
					=====  =====
                    Trial
ResourceId        : /subscriptions/4c0784a2-e3de-4d6d-b25b3bbc7c7487d8/resourceGroups/LocalPS
```

# Create Disk
```PowerShell
$diskConfig = New-AzDiskConfig -Location $location -CreateOption Empty -DiskSizeGB 1 -Sku Standard_LRS
$diskName = 'TestDisk'

New-AzDisk -ResourceGroupName 'TestGroup' -DiskName $diskName -Disk $diskConfig
```

```
ResourceGroupName            : LocalPS
ManagedBy                    :
ManagedByExtended            : {}
Sku                          : Microsoft.Azure.Management.Compute.Models.DiskSku
Zones                        :
TimeCreated                  : 27-04-2023 8.14.52 PM
OsType                       :
HyperVGeneration             :
CreationData                 : Microsoft.Azure.Management.Compute.Models.CreationData
DiskSizeGB                   : 1
DiskSizeBytes                : 1073741824
UniqueId                     : 98b37e15-098c-47fb-8865-2c639a3b17f2
EncryptionSettingsCollection :
ProvisioningState            : Succeeded
DiskIOPSReadWrite            : 500
DiskMBpsReadWrite            : 60
DiskIOPSReadOnly             :
DiskMBpsReadOnly             :
DiskState                    : Unattached
Encryption                   : Microsoft.Azure.Management.Compute.Models.Encryption
MaxShares                    :
ShareInfo                    : {}
Id                           : /subscriptions/4c0784a2-e3de-4d6d-b25b-3bbc7c7487d8/resourceGroups/LocalPS/providers/Microsoft.Compute/disks/TestDisk
Name                         : TestDisk
Type                         : Microsoft.Compute/disks
Location                     : centralindia
ExtendedLocation             :
Tags                         : {}
NetworkAccessPolicy          : AllowAll
DiskAccessId                 :
Tier                         :
BurstingEnabled              :
PurchasePlan                 :
SupportsHibernation          :
SecurityProfile              :
PublicNetworkAccess          : Enabled
SupportedCapabilities        :
DataAccessAuthMode           :
CompletionPercent            :
```

# Configure the disk
```PowerShell
New-AzDiskUpdateConfig -DiskSizeGB 2 | Update-AzDisk -ResourceGroupName $rgName -DiskName $diskName
```

```
ResourceGroupName            : LocalPS
ManagedBy                    :
ManagedByExtended            : {}
Sku                          : Microsoft.Azure.Management.Compute.Models.DiskSku
Zones                        :
TimeCreated                  : 27-04-2023 8.14.52 PM
OsType                       :
HyperVGeneration             :
CreationData                 : Microsoft.Azure.Management.Compute.Models.CreationData
DiskSizeGB                   : 2
```

Check SKU
```PowerShell
(Get-AzDisk -ResourceGroupName $rgName -Name $diskName).Sku
```

```
Name         Tier
----         ----
Standard_LRS Standard
```

# Virtual Machine
Start
```PowerShell
Start-AzVM -Name "MyVM" -ResourceGroupName "MyResourceGroup"
```
Stop
```PowerShell
Stop-AzVM -Name "MyVM" -ResourceGroupName "MyResourceGroup" -Force
```

# Others
1.  `Connect-AzAccount`: This command is used to authenticate and connect to an Azure account.
    
2.  `Get-AzResourceGroup`: This command is used to get a list of all resource groups in an Azure subscription.
    
3.  `New-AzResourceGroup`: This command is used to create a new resource group in an Azure subscription.
    
4.  `Get-AzVM`: This command is used to get a list of all virtual machines in an Azure subscription.
    
5.  `New-AzVM`: This command is used to create a new virtual machine in an Azure subscription.
    
6.  `Get-AzStorageAccount`: This command is used to get a list of all storage accounts in an Azure subscription.
    
7.  `New-AzStorageAccount`: This command is used to create a new storage account in an Azure subscription.
    
8.  `Get-AzWebApp`: This command is used to get a list of all web apps in an Azure subscription.
    
9.  `New-AzWebApp`: This command is used to create a new web app in an Azure subscription.
    
10.  `Get-AzSqlServer`: This command is used to get a list of all SQL servers in an Azure subscription.
    
11.  `New-AzSqlServer`: This command is used to create a new SQL server in an Azure subscription.
    
12.  `Get-AzNetworkSecurityGroup`: This command is used to get a list of all network security groups in an Azure subscription.
    
13.  `New-AzNetworkSecurityGroup`: This command is used to create a new network security group in an Azure subscription