---
exam: 104
module: Storage
---
```dataviewjs
dv.view('toc')
```
# Azure Storage
Azure groups four of these data services together under the name _Azure Storage_
The four services are Azure Blobs, Azure Files, Azure Queues, and Azure Tables.
![[Pasted image 20230502022156.png]]

# Storage Account
> A _storage account_ is a container that groups a set of Azure Storage services together.

![[Pasted image 20230502022633.png]]

- Combining data services into a single storage account enables you to manage them as a group.
- A storage account is an Azure resource and is part of a resource group.
- Azure SQL and Azure Cosmos DB cannot be included in a storage account.
![[Pasted image 20230502022905.png]]

## Settings defined by a storage account
- Subscription
- Location
- Performance
- Replication
- Access Tier
- Secure Transfer required
- Virtual network

## Settings that apply to the account itself
-   Name
-   Deployment model
	-   **Resource Manager**: the current model that uses the Azure Resource Manager API
	-   **Classic**: a legacy offering that uses the classic deployment model
-   Account kind
	-   **Standard - StorageV2 (general purpose v2)**: the current offering that supports all storage types and all of the latest features
	-   **Premium - Page blobs**: Premium storage account type for page blobs only
	-   **Premium - Block blobs**: Premium storage account type for block blobs and append blobs
	-   **Premium - File shares**: Premium storage account type for file shares only

## Account creation tool
The available tools are:

-   Azure Portal
-   Azure CLI (Command-line interface)
-   Azure PowerShell
-   Management client libraries