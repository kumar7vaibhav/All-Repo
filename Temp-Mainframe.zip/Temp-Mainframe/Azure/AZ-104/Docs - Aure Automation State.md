---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Azure Automation State Configuration
> Ensure that the virtual machines (VMs) in a cluster area are in a consistent state, with the same software installed and the same configurations.

Azure Automation State Configuration uses PowerShell DSC. It centrally manages your DSC artifacts and the DSC process.

# PowerShell  DSC
> PowerShell DSC is a declarative management platform that Azure Automation State Configuration uses to configure, deploy, and control systems.

[[Docs - Virtual Machine Extensions#Desired State Configuration]]

> [!INFO] Idempotence
>  Idempotence describes an operation that has the same effect whether you run it once or 10,001 times.

## Local Configuration Manager
> The LCM is responsible for updating the state of a node, like a VM, to match the desired state.

LCM is a component of the Windows Management Framework (WMF) on a Windows operating system.

Every time the LCM runs, it completes the following steps:
1.  **Get**: Gets the current state of the node.
2.  **Test**: Compares the current state of a node against the desired state by using a compiled DSC script (.mof file).
3.  **Set**: Updates the node to match the desired state described in the .mof file.

## Push and Pull architecture of DSC
The LCM on each node can operate in two modes.

- **Push mode**: An administrator manually sends, or _pushes_, the configurations to one or more nodes. 
	![[Pasted image 20230505020043.png]]
      
- **Pull mode**: A _pull server_ holds the configuration information. The LCM on each node polls the pull server at regular intervals, by default every 15 minutes, to get the latest configuration details. 
    In pull mode, each node has to be registered with the pull service.
	![[Pasted image 20230505020101.png]]
	
Both modes have advantages:
- Push mode is easy to set up. 
	- It doesn't need its own dedicated infrastructure, and it can run on a laptop. 
	- Push mode is helpful to test the functionality of DSC. 
- Pull mode is useful in an enterprise deployment that spans a large number of machines. 
	- The LCM regularly polls the pull server and makes sure the nodes are in the desired state. 

## DSC requirements

If your nodes are located in a private network, DSC needs the following port and URLs to communicate with Azure Automation:

-   **Port**: Only TCP 443 is required for outbound internet access.
-   **Global URL**: *.azure-automation.net
-   **Global URL of US Gov Virginia**: *.azure-automation.us
-   **Agent service**: https://`<workspaceId>`.agentsvc.azure-automation.net

## Anatomy of a DSC code block

```PowerShell
Configuration MyDscConfiguration {              ##1
    Node "localhost" {                          ##2
        WindowsFeature MyFeatureInstance {      ##3
            Ensure = 'Present'
            Name = 'Web-Server'
        }
    }
}
MyDscConfiguration -OutputPath C:\temp\         ##4
```

1. **Configuration**: The configuration block is the outermost script block. It starts with the `Configuration` keyword, and you provide a name.
2. Node: The node block determines the names of .mof files that are generated when you compile the configuration.
3. **Resource**: One or more resource blocks can specify the resources to configure.
4. **MyDscConfiguration**: This call invokes the `MyDscConfiguration` block.