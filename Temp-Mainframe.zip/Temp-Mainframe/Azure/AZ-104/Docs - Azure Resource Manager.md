---
exam: 104
module: Prerequisites 
---
# Resource Manager
> [!info] Enables you to work with your resources as a group.
- Perform coordinated operations
- Use templates for deployment
- Manager provides -
	- Security
	- Auditing
	- Tagging

# Consistent Management Layer
![[Pasted image 20230428152132.png]]

# Benefits
1. Manage resources as a group.
2. Have confidence that the resources are deployed in consistent state.
3. Declarative approach through templates.
4. Define dependencies to create order of deployment of resources.
5. Access control through [[Docs - Governance Strategy#Role Based Access Control (RBAC)|RBAC]]
6. Organization through tags.
7. Better billing.

# Guidance
1. Define and deploy through declarative syntax in templates
2. Shouldn't have any manual steps.
3. Imperative commands only to start and stop resources.
4. Group resources based on lifecycles. 
5. Use tags for all other organizing methods.

# Azure Resource Terminology
1. Resource - A manageable item.
2. Resource Group - A container that holds a resource.
3. Resource Provider - A service that supplies the resource.
4. Template - A JSON file used to deploy resources.

# Resource Providers
Provides a set of resources and operations for working with an Azure service.
Like keys and secrets are in Microsoft.KeyValut provider.
Other Examples of providers - 
1.  Microsoft.KeyVault
2.  Microsoft.Authorization
3.  Microsoft.Compute
4.  Microsoft.Network
5.  Microsoft.Storage
6.  Microsoft.Web
7.  Microsoft.Sql
8.  Microsoft.ContainerRegistry
9.  Microsoft.ContainerService
10.  Microsoft.Devices

# Create Resource Groups
[[Docs - Architechtural Components#**Resource group**:]]
Considerations - 
- Resources can exist in only one resource group
- Can't be renamed
- Can have resources of different types
- Can have resources from different regions
- All the resources in your group should share the same lifecycle.
- Resources can be moved at any time. But check [Moving Resources](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/move-support-resources)
- Can be sued for access control.

## Lock types
![[Pasted image 20230428160525.png]]
There are two types of resource locks.
-   **Read-Only locks**, which prevent any changes to the resource.
-   **Delete locks**, which prevent deletion.

Properties
-   You can associate the lock with a subscription, resource group, or resource.
-   Locks are inherited by child resources.

# Reorganizing Azure Resources
When moving resources, both the source group and the target group are locked during the operation. 
> [!Note] Write and delete operations are blocked on the resource groups until the move completes.

To move resources, select the resource group containing those resources, and then select the **Move** button. Select the resources to move and the destination resource group. Acknowledge that you need to update scripts.
