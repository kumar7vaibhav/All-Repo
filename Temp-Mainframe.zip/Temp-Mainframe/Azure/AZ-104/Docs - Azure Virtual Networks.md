---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Plan Virtual Network
 Azure network services offer a range of components with functionalities and capabilities
 ![[Pasted image 20230505154339.png]]
# Subnets
>  Implement logical divisions within virtual network.

Network can be segmented into subnets to help improve security, increase performance, and make it easier to manage.

## Reserved Addresses
> For each subnet, Azure reserves five IP addresses. 
> The first four addresses and the last address.

First - This value identifies the virtual network address
Second - Azure configures this address as the default gateway.
Third & Fourth - Azure maps these Azure DNS IP addresses to the virtual network space.
Last - This value supplies the virtual network broadcast address.

# IP Addressing
> Assign IP addresses to Azure resources

Two types -
1. Private
2. Public
![[Pasted image 20230505155319.png]]
- Can be statically or dynamically assigned.
- Segregated into different subnets
- Use Static IP Address for - 
	- DNS name resolution
	- IP address based security models
	- TLS/SSL certificates linked to an IP address
	- Firewall rules that allow or deny traffic using IP
	- Role-Based virtual machines like DC or DNS

## Private IP Addresses
Enable communication within an Azure virtual network and your on-premises network. 

## Public IP Addresses
Allow your resource to communicate with the internet. Create public IP address to connect with Azure public-facing services.

### Create Public IP Address
![[Pasted image 20230505155806.png]]
If you select **IPv6** for the IP version, the assignment method must be **Dynamic** for the Basic SKU. Standard SKU addresses are **Static** for both IPv4 and IPv6 addresses.

> [!Note] Further Reading
> -   Peruse [Azure Virtual Network documentation](https://learn.microsoft.com/en-us/azure/virtual-network/).
> -   Explore [Azure networking documentation](https://learn.microsoft.com/en-us/azure/networking/).
> - Read about [public IP addresses for virtual networks](https://learn.microsoft.com/en-us/azure/virtual-network/public-ip-addresses).
> -   Read about [private IP addresses for virtual networks](https://learn.microsoft.com/en-us/azure/virtual-network/private-ip-addresses).
> -   Get started with [virtual networks and virtual machines in Azure](https://learn.microsoft.com/en-us/azure/virtual-network/network-overview).

