---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Azure Load Balancer
> Azure Load Balancer delivers high availability and network performance to your applications.
> Efficiently distribute incoming network traffic across back-end servers and resources.


![[Pasted image 20230506214236.png]]

- Can be used for inbound and outbound scenarios
- Types - 
	- Public
	- Internal
- Components - 
	- Front-end IP Configuration
	- Back-End pools
	- Load-Balancing Rules
	- Health Probes

## Public Load Balancer
Administrators use public load balancers to map the public IP addresses and port numbers of incoming traffic to the private IP addresses and port numbers of virutal machines. 

Load Balancer rules are used to specify how to distribute specific types of traffic across multiple VMs or services.

Share the load of incoming web request traffic across multiple web servers.

![[Pasted image 20230506215059.png]]

## Internal Load Balancer
> Direct traffic to resources that reside in a virtual network, or to a resource that use a VPN to access Azure infrastructure. 

![[Pasted image 20230506215446.png]]

- Within Virtual Network
- For cross-premises virtual network
- For multi-tier applications
- For Line-of-Business applications
- With public load balancer

# Load Balancer SKUs
> Standard, Basic, Gateway

- Standard Load Balancer is the newest product. It's essentially a superset of Basic Load Balancer.
- The Basic SKU can be upgraded to the Standard SKU. But, new designs and architectures should use the Standard SKU.
- The Gateway SKU supports high performance and high availability scenarios with third-party network virtual appliances (NVAs).
![[Pasted image 20230506220101.png]]

# Backend Pools
> Each load balancer has one or more back-end pools that are used for distributing traffic.

![[Pasted image 20230506220201.png]]

- When you configure the back-end pools, you can connect to [[Docs - Virtual Machine Availability#Availablity Sets|availability sets]], virtual machines, or [[Docs - Virtual Machine Availability#Azure Virtual Machine Scale Sets|Azure Virtual Machine Scale Sets]].

# Health Probes
> A health probe allows your load balancer to monitor the status of your application.

The probe dynamically adds or removes virtual machines from your load balancer rotation based on the machine response to health checks.

To configure a probe you need:
1. Port
2. URI
3. Interval
4. Unhealthy threshold

![[Pasted image 20230506220544.png]]

- In an HTTP probe, the load balancer probes your back-end pool endpoints every 15 seconds. 
	- A virtual machine instance is considered healthy if it responds with an HTTP 200 message within the specified timeout period (default is 31 seconds). 
	- If any status other than HTTP 200 is returned, the instance is considered unhealthy, and the probe fails.
- A TCP probe relies on establishing a successful TCP session to a defined probe port. 
	- If the specified listener on the virtual machine exists, the probe succeeds. 
	- If the connection is refused, the probe fails.
- A Guest agent probe is a third option that uses the guest agent inside the virtual machine. 
	- This option isn't recommended when an HTTP or TCP custom probe configuration is possible.

# Load Balancer Rules
> Specify how traffic is distributed to your back-end pools.

-  To configure a load-balancing rule, you need to have a frontend, backend, and health probe for your load balancer.
- Configure settings
	- IP Version
	- Frond-end IP Address
	- Back-end pool and Back-end port
	- Health Probe
	- Session persistence

![[Pasted image 20230506220908.png]]


- By default, Azure Load Balancer distributes network traffic equally among multiple virtual machines.
- **Session persistence** specifies how to handle traffic from a client. By default, successive requests from a client are handled by any virtual machine in your pool.
- Load-balancing rules can be used in combination with NAT rules.

> [!note] Further Reading
> -   Peruse [Azure Load Balancer documentation](https://learn.microsoft.com/en-us/azure/load-balancer/).
> -   Read about [Azure Load Balancer](https://learn.microsoft.com/en-us/azure/load-balancer/load-balancer-overview).
> -   Create a [public load balancer for virtual machines in the Azure portal](https://learn.microsoft.com/en-us/azure/load-balancer/quickstart-load-balancer-standard-public-portal).
> -   Create an [internal load balancer for virtual machines in the Azure portal](https://learn.microsoft.com/en-us/azure/load-balancer/quickstart-load-balancer-standard-internal-portal).
> -   Compare [Azure Load Balancer SKUs](https://learn.microsoft.com/en-us/azure/load-balancer/skus).
> -   Explore the [Gateway Load Balancer](https://learn.microsoft.com/en-us/azure/load-balancer/gateway-overview).

