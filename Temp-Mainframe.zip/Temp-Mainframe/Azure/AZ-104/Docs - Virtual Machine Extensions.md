---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Virtual Machine Extensions
> Small applications that provide post-deployment configuration and automation tasks on Azure VMs

-   You can manage virtual machine extensions with the Azure CLI, PowerShell, Azure Resource Manager (ARM) templates, and the Azure portal.
-   Virtual machine extensions can be bundled with a new virtual machine deployment or run against any existing system.
- You can choose from a large set of first and third-party virtual machine extensions.
![[Pasted image 20230503235325.png]]

# Custom Script Extensions
> Used to automatically launch and execute virtual machine customization tasks after initial machine configuration

> [!Tip] The script is allowed 90 minutes to run.

![[Pasted image 20230503235439.png]]
You can also use the PowerShell `Set-AzVmCustomScriptExtension` command to run scripts with Custom Script Extensions.

# Desired State Configuration
> A tool built into PowerShell that can be used to define a Windows host setup through code.

- The configuration script consists of a configuration block, node block, and one or more resource blocks.
```PowerShell
configuration IISInstall
{
   Node "localhost"
   {
      WindowsFeature IIS
      {
         Ensure = "Present"
         Name = "Web-Server"
      }
   }
}
```
- Desired State Configuration centers around creating specific configurations by using scripts.
- You can use Desired State Configuration when Custom Script Extensions don't satisfy the application requirements for your virtual machine.