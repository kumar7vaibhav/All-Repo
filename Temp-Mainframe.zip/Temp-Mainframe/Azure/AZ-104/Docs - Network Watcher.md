---
exam: 104
module: Monitor
---
```dataviewjs
dv.view('toc')
```
# Azure Network Watcher
> Use Azure Network Watcher to monitor, diagnose, and gain insight into their network health and performance.

Network Watcher is a regional service that enables you to monitor and diagnose conditions at a network scenario level.

Features - 
1. IP flow verify
2. Next hop
3. VPN troubleshoot
4. NSG diagnostics
5. Connection troubleshoot

## IP Flow Verify
> Checks connectivity from or to the internet and from or to your on-premises environment.
> Helps you identify if a securtiy rule is blocking traffic to or from your VM to the internet.

![[Pasted image 20230508220819.png]]

## Hop Diagnostics
> Checks if traffic is being directed to the intended destination. 
> Let's you view the next connection point (or next hop) in your network route.

![[Pasted image 20230508220935.png]]

# Visualize the network topology
![[Pasted image 20230508221037.png]]

> [!note] Further Reading
> ## Learn more
> -   Peruse [Azure Network Watcher documentation](https://learn.microsoft.com/en-us/azure/network-watcher/).
> -   Explore an [introduction to Azure Network Watcher IP flow verify](https://learn.microsoft.com/en-us/azure/network-watcher/network-watcher-ip-flow-verify-overview).
> -   Explore an [introduction to Azure Network Watcher next hop](https://learn.microsoft.com/en-us/azure/network-watcher/network-watcher-next-hop-overview).
> -   View the [topology of an Azure virtual network](https://learn.microsoft.com/en-us/azure/network-watcher/view-network-topology).
> -   Diagnose [virtual machine network traffic filter problems in the Azure portal](https://learn.microsoft.com/en-us/azure/network-watcher/diagnose-vm-network-traffic-filtering-problem).
> -   Diagnose [communication problems between virtual networks in the Azure portal](https://learn.microsoft.com/en-us/azure/network-watcher/diagnose-communication-problem-between-networks).