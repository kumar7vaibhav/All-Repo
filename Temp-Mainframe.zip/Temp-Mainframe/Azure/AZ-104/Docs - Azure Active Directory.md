---
exam: 104
module: Identity
---
# Azure Active Directory
> Azure Active Directory (Azure AD) is Microsoft's multi-tenant cloud-based directory and identity management service.

Azure AD helps to support user access to resources and applications.
Some Azure AD features - 
1. Single Sign On Access
2. Ubiquitous Device Support
3. Secure remote access
4. Cloud Extensibility
5. Sensitive data protection
6. Self-service support

## Key Terms
1. Identity - An _identity_ is an object that can be authenticated.
2. Account - An _account_ is an identity that has data associated with it.
3. Azure AD Account - An identity that's created through Azure AD or M365 
4. Azure Tenant (directory) - A single dedicated and trusted instance of Azure AD.
5. Azure Subscription - Used to pay for Azure cloud services

# Azure AD vs AD DS
1. AD DS is primarily a directory service, while Azure AD is a full identity solution.
2. Because Azure AD is based on HTTP and HTTPS, it doesn't use Kerberos authentication. 
3. Azure AD implements HTTP and HTTPS protocols, such as SAML, WS-Federation, and OpenID Connect.
4.  Azure AD includes federation services, and many third-party services like Facebook.
5. Azure AD users and groups are created in a flat structure. There are no organizational units (OUs) or group policy objects (GPOs).
6. Azure AD is a managed service. You manage only users, groups, and policies.
   If you deploy AD DS with virtual machines by using Azure, you manage many other tasks

# Azure AD editions
1. Premium P2
2. Premium P1
3. Microsoft 365 Apps
4. Free
![[Pasted image 20230429212231.png]]

# Azure AD join

The Azure AD join feature works with SSO to provide access to organizational apps and resources and to simplify Windows deployments of work-owned devices.

## Benefits
1. Single Sign On - SSO access to your Azure managed SaaS apps and devices
2. Enterprise State roaming - Securely synchronize their user settings and app settings data to joined devices
3. Access to Microsoft Store for Business - choose from an inventory of applications pre-selected by your organization.
4. Windows Hello
5. Restriction of access - Users access apps that meet your compliance policies.

## Things to consider when using joined devices
- Connect your device to Azure AD in one of two ways:
	1. Register - Provides device an identity in Azure AD that can be used for authentication and can be used to enable or disable the device.
	2. Join - Which registers and changes the local state of device.
- Consider combining registration with other solutions like MDM

# Implement Azure AD Self-Service Password Reset
> The Azure Active Directory self-service password reset (SSPR) feature lets you give users the ability to bypass helpdesk and reset their own passwords.

## Things to know about the Azure AD SSPR feature
-   SSPR requires an Azure AD account with Global Administrator privileges to manage SSPR options. 
- This account can always reset their own passwords, no matter what options are configured.
-   SSPR uses a security group to limit the users who have SSPR privileges.
-   All user accounts in your organization must have a valid license to use SSPR.

> [!Note] Further Links
> https://learn.microsoft.com/en-us/azure/active-directory/devices/overview
> https://learn.microsoft.com/en-us/azure/active-directory/fundamentals/active-directory-whatis
> https://learn.microsoft.com/en-us/azure/active-directory/authentication/concept-sspr-howitworks

