---
exam: 104
module: Network 
---
```dataviewjs
dv.view('toc')
```
# Network Security Groups
> Network Security Groups (NSGs) are a security feature in Azure that allow you to control inbound and outbound traffic to your Azure resources. 

NSGs act as a virtual firewall, filtering network traffic based on rules that you define. 
![[Pasted image 20230505162209.png]]

## Network Security Groups and Subnets
> Assign network security groups to a subnet and create a protected screened subnet (aka Demilitarized Zone)

A DMZ acts as a buffer between resources within your virtual network and the internet.
-   Use the network security group to restrict traffic flow to all machines that reside within the subnet.
-   Each subnet can have a maximum of one associated network security group.

## Network security groups and network interfaces
> Assign network security groups to a network interface card (NIC).

-   Define network security group rules to control all traffic that flows through a NIC.
-   Each network interface that exists in a subnet can have zero, or one, associated network security groups.

# Network Security Group Rules
> Define rules to control the traffic flow in and out of virtual network subnets and network interfaces.

- Azure creates several default security rules.
- Each security rule is assigned a Priority value.
- Can't remove the default security rules.
- Override a default security rule by creating another security rule that has a higher Priority.
![[Pasted image 20230505162818.png]]

![[Pasted image 20230505162823.png]]

# Effective Rules
> Effective rules determine the actual traffic allowed or blocked by the NSG and take into account all rules that apply to a particular resource.

![[Pasted image 20230505163343.png]]

> [!Note] Further Reading
> -   Read about [network security groups](https://learn.microsoft.com/en-us/azure/virtual-network/security-overview). 
> -   Explore [how network security groups filter network traffic](https://learn.microsoft.com/en-us/azure/virtual-network/network-security-group-how-it-works).
> -   Create, change, or delete [network security groups](https://learn.microsoft.com/en-us/azure/virtual-network/manage-network-security-group).
> -   Filter [network traffic with network security groups in the Azure portal](https://learn.microsoft.com/en-us/azure/virtual-network/tutorial-filter-network-traffic).
> -   Read about [application security groups](https://learn.microsoft.com/en-us/azure/virtual-network/application-security-groups) in Azure Virtual Network.

