---
exam: 104
module: Identity
---
# What is Azure RBAC?
[[Docs - Role-Based Access Control]]

Diagram depicts how the classic subscription administrator roles, Azure roles, and Azure AD roles are related at a high level
![[Pasted image 20230430225739.png]]

# How does Azure RBAC work?
![[Docs - Role-Based Access Control#Azure RBAC concepts]]

1. Service Principal (Who)
	Fancy name for a user, group, or application
2. Role definition (What you can do)
	A _role definition_ is a collection of permissions.
3. Scope (Where)
	Scopes are structured in a parent-child relationship

# Azure RBAC is an allow model
Azure RBAC is an _allow_ model. This means that when you're assigned a role, Azure RBAC allows you to perform certain actions, such as read, write, or delete.