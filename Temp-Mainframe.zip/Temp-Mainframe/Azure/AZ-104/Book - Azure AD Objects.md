---
exam: 104
module: Identity 
---
# Azure AD Pricing
![[Pasted image 20230601190037.png]]
# Identities
## Users
1. Create User
2. Invite User
## Groups
1. Security Groups - Just like On-Prem groups
	1. Assigned - Manually assigned
	2. Dynamic User - Automatically group users who meet the policy
2. Microsoft 365 Groups - Provide access to collection of shared resources.
# Administrative Units
Administrative units allow an organization to grant admin permissions that are restricted to a department, region, or any other segment of the organization, so they could control access, manage users, and set policies only in that segment.

The following roles can be assigned within an AU:
• Authentication administrator
• Groups administrator
• Help desk administrator
• License administrator
• Password administrator
• User administrator

> [!note] Remember, you need to assign an Azure AD P1 license to administrators within the AU.
# Manage User and Group Settings
## User
1. Profile
2. Assigned Roles
3. Adminstrative Units
4. Groups
5. Applications
6. Licenses
7. Devices
8. Azure Role Assignments
9. Authentication Methods
## Groups
1. Overview
2. Properties
3. Members
4. Owners
5. Adminitrative Units
6. Groups Memberships
7. Applications
8. Licenses
9. Azure Role Assignments
10. Dynamic Membership rules
# Managing Device Settings
1. Users may join devices to Azure AD
2. Users may register devices to Azure AD
3. Require Multi-Factor Authentication to registered devices
4. Maxium number fo devices per user
5. Manage Additional Local Admins on all Azure AD joined devices
6. Manage Enterprise State Roaming settings.

# Performing Bult Updates
1. Bulk Creation
2. Bulk Invitation
3. Bulk User Deletion
4. Bulk User Downloads

# Manage Guest Accounts
Guest user permission
1. Same as member users	Guests have the same access to Azure AD resources as member users
2. Limited access (default)	Guests can see membership of all non-hidden groups
3. Restricted access (new)	Guests can't see membership of any groups

# Configure Azure AD Join
Join devices directly with Azure AD

Methods- 
1. Bulk Deployment
2. Windows Autopilot
3. Self-service experience

Ways of managing
1. MDM Only
2. Co-Management (SCCM)

# Configure SSPR
By enabling a self-service password for your users, they are able to change their passwords automatically, without calling the help desk.
> [!info] The Azure AD free-tier license only supports cloud users for SSPR, and only password change is supported, not password reset

