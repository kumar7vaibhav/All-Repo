---
exam: 104
module: Identity
---
# Configure Azure Policy
Management groups allows management of subscriptions
- By default all susbcriptions are added to top level or root management groups
- Allows 6 leves of depth
- [[Docs - Governance Strategy#Role Based Access Control (RBAC)| Role Based Access Control]] is applied to all the lower levels.
## Things to consider
- Custom hierarchies and groups
- Policy inheritences
- Compliance rules
- Cost reporting
## Requires
- Management group ID
- Display name

# Implement Azure Policies
- Azure policy is a service in Azure
- You can create, assign and manage policies.
- Policy -> Enforces Rules -> Meet compliance and SLA

# Create Azure Policies
A policy definition describes compliance conditions and the actions to complete when the conditions meet.
Step 1: Create Policy definition.
Step 2: Create an initiative definition
Step 3: Scope the initiative definition
Step 4: Determine compliance

