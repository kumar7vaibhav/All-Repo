---
exam: 104
module: Prerequisites 
---
# Use the Azure Portal
> [!INFO] https://portal.azure.com


# Use Azure Cloud Shell
![[Pasted image 20230427194736.png]]
- Temporary: require files to be mounted again.
- Based on Monaco Editor (Web Based Editor)
- Times out after 20 mins of inactivity.
- Requires a resource group, storage account and Azure File share
- Uses the same Azure file share for both Bash and PowerShell.
- Is assigned to one machine per user account.
- Persists $HOME using a 5-GB image held in your file share.
- Permissions are set as a regular Linux user in Bash.
# Use Azure PowerShell
> [!info] It is a module that you add to local PowerShell application.

Two options.
1. Azure Cloud Shell  - Via browser.
2. Local installation of module in Linux, macOS or Windows. 

In either option you can use it as - 
1. Manual Mode - Run commands
2. Script Mode - Run Scripts
> [Download](https://github.com/Azure/azure-powershell)
> [Docs](https://learn.microsoft.com/en-us/powershell/azure/?view=azps-9.7.0&viewFallbackFrom=azps-6.5.0)
> 	[Create VM with Azure PowerShell](https://learn.microsoft.com/en-us/powershell/azure/azureps-vm-tutorial?view=azps-9.7.0)

[[Azure PowerShell - Examples]]

# Use Azure CLI
>[!info] Azure CLI is a command-line program to connect to Azure and execute administrative commands on Azure resources.

[[Azure CLI - Examples]]

