---
exam: 104
module: Prerequisites 
---
# What is infrastrucutre as code?
_Infrastructure as code_ enables you to describe, through code, the infrastructure that you need for your application.
-   Consistent configurations
-   Improved scalability
-   Faster deployments
-   Better traceability
# What is an ARM template?
ARM templates are JavaScript Object Notation (JSON) files that define the infrastructure and configuration for your deployment. The template uses a _declarative syntax_.
# Benefits
1. Just like application code, you can store the IaC files in a source repository and version it.
2. Templates are idempotent.
   > [!quote] Idempotence is any function that can be executed several times without changing the final result beyond its first iteration.
3. Resource Manager orchestrates the deployment in an order and parallely when possible.
4. Resource Manager checks the file before deployment to make sure it succeeds. 
5. Complex templates can be broken into smaller, reusable components. 
6. In Azure portal, 
	1. You can review the deployment history
	2. Get information about the state of deployment.
	3. Information about the values of all the parameters and outuputs.
7. Integrate the ARM templates into the CI/CD pipeline to automate deployment and testing.

# ARM template file structure
![[Pasted image 20230428215436.png]]

# Deploy an ARM template to Azure
Possible ways - 
1. Deploy a local template
2. Deploy a linked template
3. Deploy in a continuous deployment pipeline.

## 1. Login
```
az login
```
## 2. Define Resource Group
```bash
az group create \
--name "testgroup" \
--location "centralindia"
```
## 3. Deployment
```bash
templateFile="{provide-the-path-to-the-template-file}"
az deployment group create \
  --name blanktemplate \
  --resource-group myResourceGroup \
  --template-file $templateFile
```