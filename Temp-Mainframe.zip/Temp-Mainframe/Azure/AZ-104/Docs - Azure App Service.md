---
exam: 104
module: Compute 
---
```dataviewjs
dv.view('toc')
```
# Azure App Service
> Azure App Service brings together everything you need to create apps

## Benefits
- Multiple languages and frameworks
- DevOps optimizations
- Global scale with high availability
- Connections to SaaS platforms and on-premises data
- Security and compliance
- Application templates
- Visual Studio integration
- Serverless code

## Continuous Integration and Deployment
> You can connect your web app with any of the CI/CD sources and App Service handles the rest for you.

![[Pasted image 20230504014415.png]]

When you create your web app with App Service, you can choose automated or manual deployment.
1. Automated Deployment. (CI)
	1. Azure DevOps
	2. GitHub
	3. Bitbucket
	4. OneDrive
	5. DropBox
2. Manual Deployment
	1. Git
	2. CLI - `az webapp up`
		1. ZIP Deploy `az webapp deployment source config-zip`
		2. WAR Deploy - Java web application using WAR packages
	3. Visual Studio
	4. FTP
## Deployment Slots
> Azure App Service Deployment Slots are separate environments in a single instance where new versions of your app can be tested before swapping them into production. Each slot is a copy of your app with its own hostname, allowing for minimal downtime when deploying new code.

![[Pasted image 20230504015359.png]]

![[Pasted image 20230504015531.png]]

Deployment slot settings fall into three categories:
- Slot-specific app settings and connection strings (if applicable)
- Continuous deployment settings (when enabled)
- Azure App Service authentication settings (when enabled)

## Secure your App Service App
> Azure App Service provides built-in authentication and authorization support.

The security module handles several tasks for your app:
- Authenticate users with the specified provider
- Validate, store, and refresh tokens
- Manage the authenticated session
- Inject identity information into request headers

## Back up and restore your App Service app
> The Backup and Restore feature in Azure App Service lets you easily create backups manually or on a schedule.

- You can configure backups manually or on a schedule.
- Full backups are the default.
- Partial backups are supported. You can specify files and folders to exclude from a backup.
- You restore partial backups of your app or site the same way you restore a regular backup.
- Backups can hold up to 10 GB of app and database content.
- Backups for your app or site are visible on the **Containers** page of your storage account and app (or site) in the Azure portal.

## Azure Application Insights
> Lets you monitor your live applications.

![[Pasted image 20230504020243.png]]
- Application Insights works on various platforms including .NET, Node.js and Java EE.
- The feature can be used for configurations that are hosted on-premises, in a hybrid environment, or in any public cloud.
- Application Insights integrates with your Azure DevOps process, and has connection points to many development tools.
- You can monitor and analyze data from mobile apps by integrating with Visual Studio App Center.

> [!Note] Further Reading
Learn more
>-   Peruse [Azure App Service documentation](https://learn.microsoft.com/en-us/azure/app-service/).
>-   Read about [continuous deployment to Azure App Service](https://learn.microsoft.com/en-us/azure/app-service/deploy-continuous-deployment).
>-   Set up [staging environments in Azure App Service](https://learn.microsoft.com/en-us/azure/app-service/deploy-staging-slots).
> Learn more with self-paced training
>-   Stage [a web app deployment for testing and rollback by using App Service deployment slots](https://learn.microsoft.com/en-us/training/modules/stage-deploy-app-service-deployment-slots/). _Azure subscription required_.
>-   Dynamically meet [changing web app performance requirements with autoscale rules](https://learn.microsoft.com/en-us/training/modules/app-service-autoscale-rules/). _Azure subscription required_.

