# Azure Portal - Visually Understand and Manage Cloud
- By using the Azure portal, a web-based user interface, you can access virtually every feature of Azure.
- The Azure portal is how most users first experience Azure.

# Azure Mobile App - Manage Azure on the go
- Provides iOS and Android access to your Azure resources when you're away from your computer.
- Monitor status of your Azure resources.
- Check for alerts
- Quickly diagnose and fix issues 
- Restart a web app or virtual machine (VM).
- Run the Azure CLI or Azure PowerShell commands to manage your Azure resources.

# Azure PowerShell - One-off Admin Tasks
Azure PowerShell is a shell with which developers and DevOps and IT professionals can execute commands called cmdlets.

These commands call the **Azure Rest API** to perform every possible management task in Azure. 

Cmdlets can be executed to orchestrate:
- Routine setup, teardown, and maintenance of a single resource or multiple connected resources.
- Deployment of an entire infrastructure, which might contain dozens or hundreds of resources, from imperative code.

Azure PowerShell is available for Windows, Linux, and Mac, and you can access it in a web browser via Azure Cloud Shell.


# Azure CLI - One-off Admin Tasks
Azure Command-Line Interface is an executable program with which a professional can execute commands in _Bash_.

> In many respects, the Azure CLI is identical to Azure PowerShell in what you can do with it. Both run on Windows, Linux, and Mac, and can be accessed in a web browser via Cloud Shell. 

> The primary difference is the syntax you use. If you're already proficient in PowerShell or Bash, you can use the tool you prefer.

# ARM Templates - To Deploy entire Cloud Architecture
- Azure Resource Manager templates (ARM templates), you can describe the resources you want to use in a declarative JSON format.
- ARM template is verified before any code is executed to ensure that the resources will be created and connected correctly.