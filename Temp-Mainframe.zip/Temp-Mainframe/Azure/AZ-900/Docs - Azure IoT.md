# [Identify the product options](https://docs.microsoft.com/en-us/learn/modules/iot-fundamentals/2-identify-product-options)
IoT enables devices to gather and then relay information for data analysis. Smart devices are equipped with sensors that collect data.
Devices that are equipped with these kinds of sensors and that can connect to the internet could send their sensor readings to a specific endpoint in Azure via a message.
Add new functionality by sending software updates from Azure IoT services to each device.

# [Azure IoT Hub](https://azure.microsoft.com/services/iot-hub/)
IoT Hub is a managed service that's hosted in the cloud and that acts as a central message hub for bi-directional communication between your IoT application and the devices it manages.

# [Azure IoT Central](https://azure.microsoft.com/services/iot-central/)
IoT Central builds on top of IoT Hub by adding a dashboard that allows you to connect, monitor, and manage your IoT devices. 

- The visual user interface (UI) makes it easy to quickly connect new devices and watch as they begin sending telemetry or error messages. 
- You can watch the overall performance across all devices in aggregate, 
- You can set up alerts that send notifications when a specific device needs maintenance. 
- You can push firmware updates to the device.


![[Pasted image 20220608133418.png]]

# [Azure Sphere](https://azure.microsoft.com/services/azure-sphere/)
Azure Sphere creates an end-to-end, highly secure IoT solution for customers that encompasses everything from the hardware and operating system on the device to the secure method of sending messages from the device to the message hub. 
Azure Sphere has built-in communication and security features for internet-connected devices.

Azure Sphere comes in three parts:
1. Azure Sphere micro-controller unit
2. Customized Linux Operating system
3. Azure Sphere Security Service


