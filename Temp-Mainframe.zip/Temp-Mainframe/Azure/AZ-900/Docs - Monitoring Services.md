# Azure Advisor
[Azure Advisor](https://azure.microsoft.com/services/advisor/) evaluates your Azure resources and makes recommendations to help improve reliability, security, and performance, achieve operational excellence, and reduce costs. 
Advisor is designed to help you save time on cloud optimization. 
The *recommendation service* includes suggested actions you can take right away, postpone, or dismiss.

The recommendations are divided into five categories:
1. **Reliability**: Used to ensure and improve the continuity of your business-critical applications.
2. **Security**: Used to detect threats and vulnerabilities that might lead to security breaches.
3. **Performance**: Used to improve the speed of your applications.
4. **Cost**: Used to optimize and reduce your overall Azure spending.
5. **Operational Excellence**: Used to help you achieve process and workflow efficiency, resource manageability, and deployment best practices.

# Azure Monitor
[Azure Monitor](https://azure.microsoft.com/services/monitor/) is a platform for collecting, analyzing, visualizing, and potentially taking action based on the metric and logging data from your entire Azure and on-premises environment.
![[Pasted image 20220624065726.png]]

- Gain insights into an application's operations and diagnose errors without having to wait for users to report them.

# Azure Service Health
[Azure Service Health](https://azure.microsoft.com/features/service-health/) provides a personalized view of the health of the Azure services, regions, and resources you rely on.

>The *status.azure.com* website, which displays only major issues that broadly affect Azure customers, doesn't provide the full picture.

- Azure Service Health displays both major and smaller, localized issues that affect you.
- After an outage, Service Health provides official incident reports, called root cause analyses (RCAs), which you can share with stakeholders.

Service Health helps you keep an eye on several event types:
- **Service issues** are problems in Azure, such as outages, that affect you right now. 
- **Planned maintenance** events can affect your availability. Service Health allows you to choose when to perform the maintenance to minimize the downtime.
- **Health advisories** are issues that require you to act to avoid service interruption, including service retirements and breaking changes. Health advisories are announced far in advance to allow you to plan.
