# [Explore big data and analytics](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-big-data-analytics)

Data comes in all types of forms and formats. When we talk about big data, we're referring to large volumes of data. This amount of data becomes increasingly hard to make sense of and to base decisions on. The volumes are so large that traditional forms of processing and analysis are no longer appropriate.

## [Azure Synapse Analytics](https://docs.microsoft.com/en-us/azure/sql-data-warehouse/)
Formerly Azure SQL Data Warehouse
Limitless analytics service that brings together enterprise-data warehousing and big data analytics. 
You have a unified experience to ingest, prepare, manage, and serve data for immediate business intelligence and machine learning needs.

## [Azure HDInsight](https://azure.microsoft.com/services/hdinsight/) 
Fully managed, open-source analytics service for enterprises. It's a cloud service that makes it easier, faster, and more cost-effective to process massive amounts of data.
You can run popular open-source frameworks and create cluster types

## [Azure Databricks](https://azure.microsoft.com/services/databricks/)
Helps you unlock insights from all your data and build artificial intelligence solutions.

## [Azure Data Lake Analytics](https://azure.microsoft.com/services/data-lake-analytics/)
An on-demand analytics job service that simplifies big data.
The analytics service can handle jobs of any scale instantly by setting the dial for how much power you need. You only pay for your job when it's running, making it more cost-effective.

