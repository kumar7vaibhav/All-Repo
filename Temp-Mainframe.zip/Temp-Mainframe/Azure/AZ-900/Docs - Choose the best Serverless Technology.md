#  [[Docs - Azure Compute Services#Azure Functions | Azure Functions]]

- Runs in response to an event.
- Created using popular programming language
- Scales automatically.
- Charges for only when the function is triggered. 
- Works in a stateless environment. But can be connected to storage. 
- Ideal for processing incoming data.
- Durable Functions can chain multiple functions together.
- Ideal for when you are concerned about the code and not the underlying platform and infrastructure.

# [[Docs - Azure Compute Services#Azure Logic Apps# | Azure Logic Apps]] 
- You build an app by linking triggers to actions with connectors.
- Low-code/no-code development platform hosted as a cloud service. 
- Helps you automate and orchestrate tasks, business processes, and workflows  
- Simplifies how you design and build scalable solutions, whether in the cloud, on-premises, or both.
- This solution covers 
	1. App integration, 
	2. Data integration, 
	3. System integration, 
	4. Enterprise application integration (EAI), 
	5. Business-to-business (B2B) integration.
- You can choose from a growing gallery of over 200 connectors.