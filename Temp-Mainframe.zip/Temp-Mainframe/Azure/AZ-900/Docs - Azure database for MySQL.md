# [Azure Database for MySQL](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-mysql-database)
Azure Database for MySQL is a relational database service in the cloud, and it's based on the MySQL Community Edition database engine, versions 5.6, 5.7, and 8.0.

Azure Database for MySQL delivers:
-   Built-in high availability with no additional cost.
-   Predictable performance and inclusive, pay-as-you-go pricing.
-   Scale as needed, within seconds.
-   Ability to protect sensitive data at rest and in motion.
-   Automatic backups.
-   Enterprise-grade security and compliance.

![[Pasted image 20220607142807.png]]

In addition, you can migrate your existing MySQL databases with minimal downtime by using the Azure Database Migration Service. 
After you have completed your migration, you can continue to develop your application with the open-source tools and platform of your choice. 
You don't have to learn new skills.


