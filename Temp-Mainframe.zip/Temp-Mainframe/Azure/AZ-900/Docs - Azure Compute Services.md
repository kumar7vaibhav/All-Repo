# Azure Compute Services
Azure compute is an on-demand computing service for running cloud-based applications. It provides computing resources such as disks, processors, memory, networking, and operating systems.

![[Pasted image 20220212110631.png]]

Some of the most prominent services are:
-   Azure Virtual Machines and Virtual Machine sets
-   Azure Container Instances
-   Azure App Service
-   Azure Functions (or _serverless computing_)

Examples of when to use VMs
- During testing and development.
- When running application in the cloud
- When extending your datacenter to the cloud
- During disaster recovery

Scale VMs in Azure
- VM Scale Sets
- Azure Batch

## What are virtual machine sets?
Virtual machine scale sets let you create and manage a group of identical, load-balanced VMs.
Scale sets allow you to centrally manage, configure, and update a large number of VMs in minutes to provide highly available applications. The number of VM instances can automatically increase or decrease in response to demand or a defined schedule.

# Azure Virtual Machines
Azure Virtual Machines, you can create and use VMs in the cloud. 
VMs provide infrastructure as a service (IaaS) in the form of a virtualized server.
VMs are an ideal choice when you need:
- Total control over the operating system (OS).
- The ability to run custom software.
- To use custom hosting configurations.

# Azure Batch
Azure Batch enables large-scale parallel and high-performance computing (HPC) batch jobs with the ability to scale to tens, hundreds, or thousands of VMs.
When you're ready to run a job, Batch does the following:

-   Starts a pool of compute VMs for you.
-   Installs applications and staging data.
-   Runs jobs with as many tasks as you have.
-   Identifies failures.
-   Requeues work.
-   Scales down the pool as work completes.

> There might be situations in which you need raw computing power or supercomputer-level compute power. Azure provides these capabilities.


# Azure App Services
App Service enables you to 
- Build and host web apps, 
- Background jobs
- Mobile back-ends
- RESTful APIs

Offers - 
- Scaling
- High Availability

> This is PaaS allows you to focus on the website and API logic while Azure handles the infra to run and scale your web applications.

Types - 
- Web Apps
- API Apps
- WebJobs
- Mobile Apps


# Azure Containers

What are containers?
Containers are virtualization environment. It is lightweight and designed to be created, scaled out, and stopped dynamically. 
- They are designed to allow you to respond to changes on demand.
- Restart quickly in case of crash 

There are two ways to manage both Docker and Microsoft-based containers in Azure: Azure Container Instances and Azure Kubernetes Service (AKS).

> Most popular engine is Docker.

A Container bundles a single application and it's dependencies. Referred to as Containerizing the app. Hosted on a container host.
A Container Host provides a standardized runtime environment.
Virtual Machines virtualize the hardware while Containers virtualize the OS.

![[Pasted image 20220214003058.png]]

## Container Cluster Orchestration
Easily deploy, manage multiple Containers with help of Cluster Orchestration.

#### How to choose between a VM and a Container?
Depends on how much flexibility you need.
VM provides complete control. While containers provide portability and performance.

# Azure Container Instances
[Azure Container Instances](https://azure.microsoft.com/services/container-instances) offers the fastest and simplest way to run a container in Azure without having to manage any virtual machines or adopt any additional services. It's a PaaS offering that allows you to upload your containers, which it runs for you.

# Azure Kubernetes Service
The task of automating, managing, and interacting with a large number of containers is known as orchestration. 
[Azure Kubernetes Service](https://azure.microsoft.com/services/kubernetes-service) is a complete orchestration service for containers with distributed architectures and large volumes of containers.

# Kubernetes
Popular option for managing Container based workload.
Combines Container management automation with extensive API to create a cloud-native application management. 
![[Pasted image 20220214004200.png]]
Pods - Contains one or more Containers.
![[Pasted image 20220214004224.png]]
Kubernetes manages the placement of Pods on the Cluster Nodes.
![[Pasted image 20220214004249.png]]
If one of the Pods crashes, Kubernetes can create a new instance of it.
If a node is removed. The Container can be moved to other node.

#### Kubernetes Scaling
Kubernetes can scale when demand arises. Horizontal Pod Autoscaling.
#### Kubernetes and staggering update deployment
Kubernetes can stagger any update to the application and can roll back if the update is problematic.
#### Kubernetes Storage and Networking Management
#### Extending Kubernetes Functionality 


# Microservice
Containers are often used to create solutions by using a _microservice architecture_. This architecture is where you break solutions into smaller, independent pieces.
![[Pasted image 20220214011301.png]]
Microservice is a way to simplify an application architecture by focusing on creating
- Smaller 
- More manageable 
- Autonomous 
- Independently deployed 

Web services that addresses a single business domain or capabilities. 

# Azure Functions / Serverless Computing
With serverless computing, Azure takes care of managing the server infrastructure and the allocation and deallocation of resources based on demand.
Includes:
- Abstraction of Servers
- Event Driven Scale
- Micro billing

Types of serverless compute
1. Azure Functions 
   Functions can execute code in almost any modern language
2. Azure Logic Apps
   Logic apps are designed in a web-based designer and can execute logic triggered by Azure services without writing any code. 

## Azure Functions
Functions are commonly used when you need to perform work in response to an event (often via a REST request), timer, or message from another Azure service, and when that work can be completed quickly, within seconds or less.

# Azure Logic Apps
Where functions execute code, logic apps execute workflows that are designed to automate business scenarios and are built from predefined logic blocks.

![[Pasted image 20220602140528.png]]

# Azure Virtual Desktop
Application virtualization service that runs on cloud.
Enables users to use cloud-hosted version of Windows.
Advantages
- Better User Exp
- Enhanced Security
- Simplified Management
- Performance Management
- Multi-Session Windows Deployment
- Bring your own licenses

