# What are the different types of clouds?

## Public Cloud
Services are offered over the public internet and available to anyone who wants to purchase them. Cloud resources, such as servers and storage, are owned and operated by a third-party cloud service provider, and delivered over the internet.
-   No capital expenditures to scale up.
-   Applications can be quickly provisioned and deprovisioned.
-   Organizations pay only for what they use.

## Private Cloud
A private cloud consists of computing resources used exclusively by users from one business or organization. A private cloud can be physically located at your organization's on-site (on-premises) datacenter, or it can be hosted by a third-party service provider.
-   Hardware must be purchased for start-up and maintenance.
-   Organizations have complete control over resources and security.
-   Organizations are responsible for hardware maintenance and updates.

## Hybrid Cloud
A hybrid cloud is a computing environment that combines a public cloud and a private cloud by allowing data and applications to be shared between them.
-   Provides the most flexibility.
-   Organizations determine where to run their applications.
-   Organizations control security, compliance, or legal requirements.


# Cloud Computing Advantages
1. **High Availability**
    Depending on the service-level agreement (SLA) that you choose, your cloud-based apps can provide a continuous user experience with no apparent downtime, even when things go wrong.
2. **Scalability**
   Apps in the cloud can scale _vertically_ and _horizontally_:
	   1. Scale vertically to increase compute capacity by adding RAM or CPUs to a virtual machine.
	   2. Scaling horizontally increases compute capacity by adding instances of resources, such as adding VMs to the configuration.
3. **Elasticity**
   You can configure cloud-based apps to take advantage of autoscaling, so your apps always have the resources they need.
4. **Agility**
    Deploy and configure cloud-based resources quickly as your app requirements change.
5. **Geo-Distribution**
    You can deploy apps and data to regional datacenters around the globe, thereby ensuring that your customers always have the best performance in their region.
6. **Disaster Recovery**
   By taking advantage of cloud-based backup services, data replication, and geo-distribution, you can deploy your apps with the confidence that comes from knowing that your data is safe in the event of disaster.
   

# Capital Expense vs Operational Expenses

- **Capital Expenditure (CapEx)**
Up-front spending on physical infrastructure, and then deducting that up-front expense over time. The up-front cost from CapEx has a value that reduces over time.

- **Operational Expenditure (OpEx)** 
Spending money on services or products now, and being billed for them now. You can deduct this expense in the same year you spend it. There is no up-front cost, as you pay for a service or product as you use it.

>Cloud service providers operate on a _consumption-based model_, which means that end users only pay for the resources that they use. Whatever they use is what they pay for.

# Different Cloud Services
These models define the different levels of shared responsibility that a cloud provider and cloud tenant are responsible for.
- IaaS - Infrastructure as a Service
	- Most Flexible cloud service
	- You configure and manage the hardware for your application
- PaaS - Platform as a Service
	- Focus on application development
	- Platform management is handled by the cloud provider
- SaaS - Software as a Service
	- Pay-as-you-go pricing model
	- Users pay for the software they use on a subscription model.


![[Pasted image 20220212014811.png]]

![[Pasted image 20220212015240.png]]

# What is serverless computing?

Like PaaS, _serverless computing_ enables developers to build applications faster by eliminating the need for them to manage infrastructure. 

With serverless applications, the cloud service provider automatically provisions, scales, and manages the infrastructure required to run the code. 

Serverless architectures are highly scalable and event-driven, only using resources when a specific function or trigger occurs.

It's important to note that servers are still running the code. The "serverless" name comes from the fact that the tasks associated with infrastructure provisioning and management are invisible to the developer.

# Overview of Azure subscriptions, management groups, and resources

![[Pasted image 20220623140004.png]]

- **Resources**: Resources are instances of services that you create, like virtual machines, storage, or SQL databases.
- **Resource groups**: Resources are combined into resource groups, which act as a logical container into which Azure resources like web apps, databases, and storage accounts are deployed and managed.
- **Subscriptions**: A subscription groups together user accounts and the resources that have been created by those user accounts. For each subscription, there are limits or quotas on the amount of resources that you can create and use. Organizations can use subscriptions to manage costs and the resources that are created by users, teams, or projects.
- **Management groups**: These groups help you manage access, policy, and compliance for multiple subscriptions. All subscriptions in a management group automatically inherit the conditions applied to the management group.