# [Azure SQL Managed Instances](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-sql-managed-instance)
Azure SQL Managed Instance is a scalable cloud data service that provides the broadest SQL Server database engine compatibility with all the benefits of a fully managed platform as a service.
Like Azure SQL Database, Azure SQL Managed Instance is a platform as a service (PaaS) database engine, which means that your company will be able to take advantage of the best features of moving your data to the cloud in a fully managed environment.

[Feature Comparison: Azure SQL Database and Azure SQL Managed Instance](https://docs.microsoft.com/en-us/azure/azure-sql/database/features-comparison?view=azuresql)

## Migration
Azure SQL Managed Instance makes it easy to migrate your on-premises data on SQL Server to the cloud using the Azure Database Migration Service (DMS) or native backup and restore. 
After you've discovered all of the features that your company uses, you need to assess which on-premises SQL Server instances you can migrate to Azure SQL Managed Instance to see if you have any blocking issues. 
Once you've resolved any issues, you can migrate your data, then cut over from your on-premises SQL Server to your Azure SQL Managed Instance by changing the connection string in your applications.

![[Pasted image 20220607153347.png]]