# DevOps 
Practices and processes that automate the ongoing development, maintenance, and deployment of software systems.

Microsoft tools enable source-code management, continuous integration and continuous delivery (CI/CD), and automate the creation of testing environments.

# Azure DevOps Services

Azure DevOps Services is a suite of services that address every stage of the software development lifecycle.

- **Azure Repos** is a centralized source-code repository where professionals can publish their code for review and collaboration.
- **Azure Boards** is an agile project management suite that includes Kanban boards, reporting, and tracking ideas.
- **Azure Pipelines** is a CI/CD pipeline automation tool.
- **Azure Artifacts** is a repository for hosting artifacts, such as compiled source code, which can be fed into testing or deployment pipeline steps.
- **Azure Test Plans** is an automated test tool that can be used in a CI/CD pipeline to ensure quality before a software release.

# GitHub and GitHub Actions
Popular code repository for open-source software.
Git is a decentralized source-code management tool, and GitHub is a hosted version of Git.
**GitHub** provide related services 
- for coordinating work, 
- reporting and discussing issues, 
- providing documentation, and more. 

It offers the following functionality:
-   It's a shared source-code repository
-   It facilitates project management, including Kanban boards.
-   It supports issue reporting, discussion, and tracking.
-   It features CI/CD pipeline automation tooling.
-   It includes a wiki for collaborative documentation.
-   It can be run from the cloud or on-premises

**GitHub Actions** enables workflow automation with triggers for many lifecycle events. One such example would be automating a CI/CD _toolchain_.

**Toolchain** is a combination of software tools that aid in the delivery, development, and management of software applications throughout a system's development lifecycle.

# GitHub vs Azure DevOps
GitHub is a lighter-weight tool than Azure DevOps, with a focus on individual developers contributing to the open-source code. 

Azure DevOps, on the other hand, is more focused on enterprise development, with heavier project-management and planning tools, and finer-grained access control.

# Azure DevTest Labs
Azure DevTest Labs provides an automated means of managing the process of building, setting up, and tearing down virtual machines (VMs) that contain builds of your software projects.

