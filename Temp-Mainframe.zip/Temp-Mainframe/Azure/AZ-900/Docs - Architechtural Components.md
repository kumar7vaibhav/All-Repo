# Azure Regions

![[Pasted image 20220212015837.png]]

> A _region_ is a geographical area on the planet that contains at least one but potentially multiple datacenters that are nearby and networked together with a low-latency network.

Why are regions important?
They provide :
- Flexibility
- Scalability
- Redundancy
- Preserve data residency

## Special Azure Regions
Specialized regions that you might need for compliance or legal purposes.
Like US Govt or China 

> Two terms to remember - Geographies and Availability Zones

# Azure Availability Zones
- To ensure data and services are redundant over multiple duplicate hardware environments to protect in case of failure.
- Availability zones are physically separate datacenters within an Azure region.
- Each availability zone is made up of one or more datacenters equipped with independent power, cooling, and networking.

![[Pasted image 20220212020500.png]]
> Not every region is supported. 
> [Supported Regions](https://docs.microsoft.com/en-us/azure/availability-zones/az-region).

Availability zones are primarily for VMs, managed disks, load balancers, and SQL databases. Azure services that support availability zones fall into three categories:
- Zonal Services
- Zone-redundant Services
- Non-regional services

> Availability zones are created by using one or more datacenters. There's a minimum of _three_ zones within a single region

# Azure Region Pairs
Each Azure region is always paired with another region within the same geography (such as US, Europe, or Asia) at least 300 miles away.
![[Pasted image 20220212021044.png]]

Advantages of region pairs
- In case of outage, one region from a pair is always prioritized. 
- Updates are rolled out to one region in a pair at a time to minimize downtime.
- Data continues to reside within the same geography as its pair for tax and law enforcement jurisdiction purposes.


# Azure Resources and Resource groups
## **Resource**: 
A manageable item that's available through Azure. like Virtual machines (VMs), storage accounts, web apps, databases, and virtual networks 

## **Resource group**: 
The resource group includes resources that you want to manage as a group.
![[Pasted image 20220212022435.png]]

- All resources must be in a resource group.
- Resource can only be a member of a single resource group. 
- Many resources can be moved between resource groups.
- Resource groups can't be nested. 
- You need a resource group to provision a resource. 
  
**Life Cycle** 
Easier to manage life cycle of a resource with help of resource group

**Authorization**
With Role Based Access Control you can ease administration and limit access.


# Azure Resource Manager
Azure Resource Manager is the deployment and management service for Azure. It provides a management layer that enables you to create, update, and delete resources in your Azure account. You use management features like access control, locks, and tags to secure and organize your resources after deployment.

![[Pasted image 20220212023112.png]]

### The benefits of using Resource Manager

With Resource Manager, you can:

- Manage your infrastructure through declarative templates rather than scripts. A Resource Manager template is a JSON file.
- Deploy, manage, and monitor all the resources for your solution as a group, rather than handling these resources individually.
- Redeploy your solution throughout the development life cycle.
- Define the dependencies between resources so they're deployed in the correct order.
- Apply access control to all services with RBAC
- Apply tags to resources to logically organize all the resources.
- Clarify your billing by viewing costs for a group that share same tag.

# Azure Subscriptions
A subscription provides you with authenticated and authorized access to Azure products and services. It also allows you to provision resources.

![[Pasted image 20220212023537.png]]

You can define boundaries around Azure Subscriptions
- Billing Boundary
- Access Control Boundary

Create additional subscription to separate
- Environments
- Organizational Structures
- Billing

Subscription Limit - Azure ExpressRoute circuits per subscription in 10

# Customize Billing 
If you have multiple subscriptions, you can organize them into invoice sections. Each invoice section is a line item on the invoice that shows the charges incurred that month.

![[Pasted image 20220212023931.png]]


# Azure Management Groups
You organize subscriptions into containers called management groups and apply your governance conditions to the management groups. 
 
All subscriptions within a management group automatically inherit the conditions applied to the management group. 
Management groups give you enterprise-grade management at a large scale no matter what type of subscriptions you might have. 
 
 All subscriptions within a single management group must trust the same Azure AD tenant.

 ![[Pasted image 20220212024242.png]]

 
- 10,000 management groups can be supported in a single directory.
- A management group tree can support up to six levels of depth. This limit doesn't include the root level or the subscription level.
- Each management group and subscription can support only one parent.
- All subscriptions and management groups are within a single hierarchy in each directory.
