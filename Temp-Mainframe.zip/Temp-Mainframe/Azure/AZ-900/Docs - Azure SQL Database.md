# [Azure SQL Database](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-sql-database)

Azure SQL Database is a relational database based on the latest stable version of the Microsoft SQL Server database engine.
SQL Database is a high-performance, reliable, fully managed, and secure database.

- Azure SQL Database is a platform as a service (PaaS) database engine.
- It handles most of the database-management functions — such as upgrading, patching, backups, and monitoring
- SQL Database provides 99.99 percent availability.
- Microsoft handles all updates to the SQL and operating system code. You don't have to manage the underlying infrastructure.
- Lets you process both relational data and non-relational structures, such as graphs, JSON, spatial, and XML.
- The newest capabilities of SQL Server are released first to SQL Database, and then to SQL Server itself.

## Migration
Migrate your existing SQL Server databases with minimal downtime by using the Azure Database Migration Service.
The Microsoft Data Migration Assistant can generate assessment reports that provide recommendations to help guide you through required changes prior to performing a migration.
The Azure Database Migration Service performs all of the required steps. 
You'll just change the connection string in your apps.