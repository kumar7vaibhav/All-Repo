# Azure VPN Gateway
VPN are deployed to connect two or more trusted private network to one another over an untrusted network. 

# VPN Gateways
A VPN gateway is a type of virtual network gateway. Azure VPN Gateway instances are deployed in a dedicated subnet of the virtual network and enable the following connectivity:
- Connect on-premises datacenters to virtual networks through a _site-to-site_ connection.
- Connect individual devices to virtual networks through a _point-to-site_ connection.
- Connect virtual networks to other virtual networks through a _network-to-network_ connection.
  
[[Docs - Azure Networking Services#4 Communicate with on-premise resources]]

![[Pasted image 20220606144838.png]]

You can deploy only one VPN gateway in each virtual network.
You can use one gateway to connect to multiple locations.

VPN Type based on how the traffic to be encrypted is specified:
1. **Policy Based**
   Policy-based VPN gateways specify statically the IP address of packets that should be encrypted through each tunnel. This type of device evaluates every data packet against those sets of IP addresses to choose the tunnel where that packet is going to be sent through.
2. **Route Based**
   If defining which IP addresses are behind each tunnel is too cumbersome, route-based gateways can be used.

- Both types of VPN Gateways use a pre-shared key as the method of authentication. 
- Both types rely on Internet Key Exchange (IKE).
- IKE is used to set up a security association (an agreement of the encryption) between two endpoints. 
- This association is then passed to the IPSec suite, which encrypts and decrypts data packets encapsulated in the VPN tunnel.

