# Azure Security Center
# Azure Sentinel
# Azure Key Vault
# Azure Dedicated Host
# Layers of Defense in Depth
Here's a brief overview of the role of each layer:

- The _physical security_ layer is the first line of defense to protect computing hardware in the datacenter.
- The _identity and access_ layer controls access to infrastructure and change control.
- The _perimeter_ layer uses distributed denial of service (DDoS) protection to filter large-scale attacks before they can cause a denial of service for users.
- The _network_ layer limits communication between resources through segmentation and access controls.
- The _compute_ layer secures access to virtual machines.
- The _application_ layer helps ensure that applications are secure and free of security vulnerabilities.
- The _data_ layer controls access to business and customer data that you need to protect.

# Security Posture
Your _security posture_ is your organization's ability to protect from and respond to security threats. The common principles used to define a security posture are _confidentiality_, _integrity_, and _availability_, known collectively as CIA.

# Azure Firewall
[Azure Firewall](https://azure.microsoft.com/services/azure-firewall) is a managed, cloud-based network security service that helps protect resources in your Azure virtual networks.

Azure Firewall provides many features, including:
- Built-in high availability.
- Unrestricted cloud scalability.
- Inbound and outbound filtering rules.
- Inbound Destination Network Address Translation (DNAT) support.
- Azure Monitor logging.

With Azure Firewall, you can configure:
- **Application rules** that define fully qualified domain names (FQDNs) that can be accessed from a subnet.
- **Network rules** that define source address, protocol, destination port, and destination address.
- **Network Address Translation (NAT)** rules that define destination IP addresses and ports to translate inbound requests.

# Azure DDoS Protection
[Azure DDoS Protection](https://azure.microsoft.com/services/ddos-protection/) (Standard) helps protect your Azure resources from DDoS attacks.
![[Pasted image 20220624114859.png]]

DDoS Protection provides these service tiers:
- Basic
- Standard

The Standard service tier can help prevent:
-   **Volumetric attacks**
    The goal of this attack is to flood the network layer with a substantial amount of seemingly legitimate traffic.
    
-   **Protocol attacks**
    These attacks render a target inaccessible by exploiting a weakness in the layer 3 and layer 4 protocol stack.
    
-   **Resource-layer (application-layer) attacks (only with web application firewall)**
    These attacks target web application packets to disrupt the transmission of data between hosts. You need a web application firewall (WAF) to protect against L7 attacks. DDoS Protection Standard protects the WAF from volumetric and protocol attacks.


# Network Security Group
A [network security group](https://docs.microsoft.com/en-us/azure/virtual-network/security-overview#network-security-groups?azure-portal=true) enables you to filter network traffic to and from Azure resources within an Azure virtual network.

# Combine Azure services to create a complete network security solution
## Secure the perimeter layer
- Use Azure DDoS Protection to filter large-scale attacks before they can cause a denial of service for users.
- Use perimeter firewalls with Azure Firewall to identify and alert on malicious attacks against your network.

## Secure the network layer
At this layer, the focus is on limiting network connectivity across all of your resources to allow only what's required. Segment your resources and use network-level controls to restrict communication to only what's needed.
- Limit communication between resources by segmenting your network and configuring access controls.
- Deny by default.
- Restrict inbound internet access and limit outbound where appropriate.
- Implement secure connectivity to on-premises networks.

## Combine services
- Network security groups and Azure Firewall
- Azure Application Gateway web application firewall and Azure Firewall