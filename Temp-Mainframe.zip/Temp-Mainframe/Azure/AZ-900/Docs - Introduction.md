[Link](https://docs.microsoft.com/en-us/learn/modules/intro-to-azure-fundamentals/introduction)

Familiarize yourself to Azure service and features.

# Preparation for Exam AZ-900
Describe cloud concepts - 20-25%
Describe core Azure services - 15-20%
Describe core solutions and management tools on Azure - 10-15%
Describe general security and network security features - 10-15%
Describe identity, governance, privacy, and compliance features - 20-25%
Describe Azure cost management and Service Level Agreements - 10-15%

# What is Cloud Computing?
Delivery of computing services over the internet.
Rent compute power and storage to someone else's datacenter.

Services include -
- Servers
- Storage
- Databases
- Networking
- Software
- Analytics
- Intelligence

# Why is it cheaper?
Pay as you go pricing model. Only pay for services that you use.
Lower your operating costs.
Run your infrastructure more effectively
Scale as your business needs change.
Cloud provider takes care of the maintenance of infrastructure.


# What is Azure?
Microsoft's cloud computing platform
Supports IaaS, PaaS and SaaS.
Pay-as-you-go pricing model.
- Virtual Machines
- Cloud based storage
- Azure App Services - Create web based applications.
- Azure Functions
- Azure Container Services
- Fully Managed relational databases
- Azure Cosmos DB
- Artificial Intelligence and Machine Learning


# How Azure Works
Uses Virtualization.
![[Pasted image 20220201175139.png]]

Datacenter -> Mini Racks Servers -> Hypervisor on each server -> Runs on multiple virtual machines.

Network Switch manages Mini Racks Servers

Every server runs Fabric Controller
Fabric Controller is managed by Orchestrator
Orchestrator manages everything on Azure.
Users make request using Orchestrator WebAPI
WebAPI can be called by many apps like Azure Web Portal

# What is the Azure Portal?
Azure portal is a web-based, unified console that provides an alternative to command-line tools.
Manage Azure subscription using a GUI.
You can -
- Build, Manage, and monitor everything from simple web apps to complex cloud deployments
- Create custom dashboards for an organized view of resources
- Configure accessibility options for an optimal experience

# What is Azure Marketplace?
[Azure Marketplace](https://azuremarketplace.microsoft.com/) helps connect users with Microsoft partners, independent software vendors, and startups that are offering their solutions and services, which are optimized to run on Azure.

# Azure Overview

![[Pasted image 20220209130752.png]]

## Most Commonly Used Categories 
-   Compute
-   Networking
-   Storage
-   Mobile
-   Databases
-   Web
-   Internet of Things (IoT)
-   Big data
-   AI
-   DevOps


## Compute
Compute services are often one of the primary reasons why companies move to the Azure platform. Azure provides a range of options for hosting applications and services. Here are some examples of compute services in Azure.
1. Azure Virtual Machines
2. Azure Virtual Machine Scale Sets
3. Azure Kubernetes Service
4. Azure Service Fabric
5. Azure Batch
6. Azure Container Instances
7. Azure Functions


## Networking
Linking compute resources and providing access to applications is the key function of Azure networking. Networking functionality in Azure includes a range of options to connect the outside world to services and features in the global Azure datacenters.
1. Azure Virtual Network
2. Azure Load Balancer
3. Azure Application Gateway
4. Azure VPN Gateway
5. Azure DNS
6. Azure Content Delivery Network
7. Azure DDoS Protection
8. Azure Traffic Manager
9. Azure ExpressRoute
10. Azure Network Watcher
11. Azure Firewall
12. Azure Virtual WAN


## Storage
Four main storage services
1. **Azure Blob storage** - Storage service for very large objects, such as video files or bitmaps.
2. **Azure File storage** - File shares that can be accessed and managed like a file server.
3. **Azure Queue storage** - A data store for queuing and reliably delivering messages between applications.
4. **Azure Table storage** - Table storage is a service that stores non-relational structured data (also known as structured NoSQL data) in the cloud, providing a key/attribute store with a schema less design.

Key features in these storages - Durable, Secure, Scalable, Managed, Accessible.


## Mobile
With Azure, developers can create mobile back-end services for mobile apps quickly and easily. Features that used to take time and increase project risks, such as adding corporate sign-in and then connecting to on-premises resources such as SAP, Oracle, SQL Server, and SharePoint, are now simple to include.
Other features of this service include:

-   Offline data synchronization.
-   Connectivity to on-premises data.
-   Broadcasting push notifications.
-   Autoscaling to match business needs.


## Databases
Azure provides multiple database services to store a wide variety of data types and volumes. And with global connectivity, this data is available to users instantly.
- Azure Cosmos DB
- Azure SQL Database
- Azure Database for MySQL
- Azure Database for PostgreSQL
- SQL Server on Azure Virtual Machines
- Azure Synapse Analytics
- Azure Database Migration Service
- Azure Cache for Redis
- Azure Database for MariaDB


## Web
Azure includes first-class support to build and host web apps and HTTP-based web services. The following Azure services are focused on web hosting.

- Azure App Service
- Azure Notification Hubs
- Azure API Management
- Azure Cognitive Search
- Web Apps feature of Azure App Service
- Azure SignalR Service


## Information of Things
The internet allows any item that's online-capable to access valuable information. This ability for devices to garner and then relay information for data analysis is referred to as IoT.
Many services can assist and drive end-to-end solutions for IoT on Azure
- **IoT Central** 
Fully managed global IoT software as a service (SaaS) solution that makes it easy to connect, monitor, and manage IoT assets at scale

- **Azure IoT Hub**
Messaging hub that provides secure communications between and monitoring of millions of IoT devices.

- **IoT Edge**
Fully managed service that allows data analysis models to be pushed directly onto IoT devices, which allows them to react quickly to state changes without needing to consult cloud-based AI models.


## Big Data
Data from weather systems, communications systems, genomic research, imaging platforms, and many other scenarios generate hundreds of gigabytes of data. 

Open-source cluster technologies have been developed to deal with these large data sets. Azure supports a broad range of technologies and services to provide big data and analytic solutions.

- **Azure Synapse Analytics**
Run analytics at a massive scale by using a cloud-based enterprise data warehouse that takes advantage of massively parallel processing to run complex queries quickly across petabytes of data.

- **Azure HDInsight**
Process massive amounts of data with managed clusters of Hadoop clusters in the cloud.

- **Azure Databricks**
Integrate this collaborative Apache Spark-based analytics service with other big data services in Azure

## Artificial Intelligence
AI, in the context of cloud computing, is based around a broad range of services, the core of which is machine learning. 
Machine learning is a data science technique that allows computers to use existing data to forecast future behaviors, outcomes, and trends. Using machine learning, computers learn without being explicitly programmed.

 - **Azure Machine Learning Service**
Cloud-based environment you can use to develop, train, test, deploy, manage, and track machine learning models.

- **Azure ML Studio**
Collaborative visual workspace where you can build, test, and deploy machine learning solutions by using prebuilt machine learning algorithms and data-handling modules.


## DevOps
DevOps brings together people, processes, and technology by automating software delivery to provide continuous value to your users. With Azure DevOps, you can create _build_ and _release_ pipelines that provide continuous integration, delivery, and deployment for your applications

- **Azure DevOps**
Use development collaboration tools such as high-performance pipelines, free private Git repositories, configurable Kanban boards, and extensive automated and cloud-based load testing. Formerly known as Visual Studio Team Services.

- **Azure DevTest Labs**
Quickly create on-demand Windows and Linux environments to test or demo applications directly from deployment pipelines


# Azure Accounts
![[Pasted image 20220211140550.png]]

![[Pasted image 20220211140636.png]]

