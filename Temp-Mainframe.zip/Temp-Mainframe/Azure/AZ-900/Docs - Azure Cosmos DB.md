# [Azure Cosmos DB](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-cosmos-db)
Azure Cosmos DB is a globally distributed, multi-model database service. 
- You can elastically and independently scale throughput and storage across any number of Azure regions worldwide. 
- You can take advantage of fast, single-digit-millisecond data access by using any one of several popular APIs. 
- Azure Cosmos DB provides comprehensive service level agreements for throughput, latency, availability, and consistency guarantees.  
- Azure Cosmos DB supports schemaless data, which lets you build highly responsive and "Always On" applications to support constantly changing data. 
- You can use this feature to store data that's updated and maintained by users around the world. 
-  At the lowest level, Azure Cosmos DB stores data in atom-record-sequence (ARS) format
![[Pasted image 20220607133854.png]]