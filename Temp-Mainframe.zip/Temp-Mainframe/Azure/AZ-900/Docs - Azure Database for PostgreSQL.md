# [Azure Database for PostgreSQL](https://docs.microsoft.com/en-us/learn/modules/azure-database-fundamentals/azure-postgresql-database)
Azure Database for PostgreSQL is a relational database service in the cloud. The server software is based on the community version of the open-source PostgreSQL database engine. Your familiarity with tools and expertise with PostgreSQL is applicable when you're using Azure Database for PostgreSQL.

Moreover, Azure Database for PostgreSQL delivers the following benefits:
- Built-in high availability compared to on-premises resources. 
- Simple and flexible pricing. 
- Scale up or down as needed, within seconds. 
- Adjustable automatic backups and point-in-time-restore for up to 35 days.
- Enterprise-grade security and compliance to protect sensitive data at rest and in motion. 

Azure Database for PostgreSQL is available in two deployment options: **Single Server** and **Hyperscale (Citus)**.

### Single Server

-   Built-in high availability with no additional cost (99.99 percent SLA).
-   Predictable performance and inclusive, pay-as-you-go pricing.
-   Vertical scale as needed, within seconds.
-   Monitoring and alerting to assess your server.
-   Enterprise-grade security and compliance.
-   The ability to protect sensitive data at rest and in motion.
-   Automatic backups and point-in-time restore for up to 35 days.
- Offers three pricing tiers: Basic, General Purpose, and Memory Optimized.

### Hyperscale (Citus)
The Hyperscale (Citus) option horizontally scales queries across multiple machines by using sharding. Its query engine parallelizes incoming SQL queries across these servers for faster responses on large datasets. It serves applications that require greater scale and performance, generally workloads that are approaching, or already exceed, 100 GB of data.

The Hyperscale (Citus) deployment option supports multi-tenant applications, real-time operational analytics, and high-throughput transactional workloads. Applications built for PostgreSQL can run distributed queries on Hyperscale (Citus) with standard connection libraries and minimal changes.
