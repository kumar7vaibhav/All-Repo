# Azure ExpressRoute Fundamentals
Let's you extend your on-premise networks into the Microsoft cloud over a private connection with the help of a connectivity provider. 
Connectivity can be from:
- Any-to-Any (IP VPN) network.
- Point-to-Point Ethernet network
- Virtual Cross-connection through a connectivity provider

ExpressRoute connections don't go over the public Internet. 
Allows ExpressRoute to offer:
- More reliability
- Faster Speeds
- Consistent Latencies
- Higher Security than over the internet connections

![[Pasted image 20220607120722.png]]

## Features and benefits of ExpressRoute
- Layer 3 (Network layer) connectivity between your on-premise network and the Microsoft Cloud through a connectivity provider. 
- Connectivity to Microsoft cloud services across all regions.
- Global Connectivity to Microsoft services with ExpressRoute
- Dynamic routing between your network and Microsoft via Border Gateway Protocol.
- Built-In redundancy in every peering location for higher reliability.
- Connection uptime SLA
- QoS support for Skype for Business

## Connectivity to Microsoft Cloud Services
ExpressRoute enables direct access to the following services in all regions:
-   Microsoft Office 365
-   Microsoft Dynamics 365
-   Azure compute services, such as Azure Virtual Machines
-   Azure cloud services, such as Azure Cosmos DB and Azure Storage

## Dynamic Routing
ExpressRoute uses the Border Gateway Protocol (BGP) routing protocol. BGP is used to exchange routes between on-premises networks and resources running in Azure. 
This protocol enables dynamic routing between your on-premises network and services running in the Microsoft cloud.

# ExpressRoute connectivity models
ExpressRoute supports the following models that you can use to connect your on-premises network to the Microsoft cloud:
-   CloudExchange colocation
-   Point-to-point Ethernet connection
-   Any-to-any connection
-   Directly from ExpressRoute sites

# Security Considerations
With ExpressRoute, your data doesn't travel over the public internet, so it's not exposed to the potential risks associated with internet communications. 
ExpressRoute is a private connection from your on-premises infrastructure to your Azure infrastructure. 
Even if you have an ExpressRoute connection, DNS queries, certificate revocation list checking, and Azure Content Delivery Network requests are still sent over the public internet.