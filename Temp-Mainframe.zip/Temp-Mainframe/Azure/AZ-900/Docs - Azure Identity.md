# Azure Active Directory 
Azure Active Directory (Azure AD) provides identity services that enable your users to sign in and access both Microsoft cloud applications and cloud applications that you develop.

# Who Uses Azure AD
- IT Admins
- App Devs
- Users
- Online Service Subscribers

# What service does Azure AD provides?
- Authentication
- Single Sign-On
- Application Management
- Device Management
- Users access both external and internal resources

> Use *Azure AD Connect* to sync between Active Directory and Azure AD

# Multifactor Authentication
_Multifactor authentication_ is a process where a user is prompted during the sign-in process for an additional form of identification. Examples include a code on their mobile phone or a fingerprint scan.

Multifactor authentication provides additional security for your identities by requiring two or more elements to fully authenticate.

These elements fall into three categories:
-   **Something the user knows**
    This might be an email address and password.
    
-   **Something the user has**
    This might be a code that's sent to the user's mobile phone.
    
-   **Something the user is**
    This is typically some sort of biometric property, such as a fingerprint or face scan that's used on many mobile devices.

# Conditional Access
Conditional Access is a tool that Azure Active Directory uses to allow (or deny) access to resources based on identity _signals_. 
These signals include 
- who the user is, 
- where the user is, and 
- what device the user is requesting access from.

When to use - 
- Require multifactor authentication to access an application.
- Require access to services only through approved client applications.
- Require users to access your application only from managed devices.
- Block access from untrusted sources, such as access from unknown or unexpected locations.
> To use Conditional Access, you need an Azure AD Premium P1 or P2 license. Or If you have a Microsoft 365 Business Premium license.

