# Azure Virtual Networking
Azure virtual networks enable Azure resources, such as VMs, web apps, and databases, to communicate with each other. 
You can think of an Azure network as an extension of your on-premises network with resources that links other Azure resources.

## Capabilities
### 1. Isolation and Segmentation
Azure virtual network allows you to create multiple isolated virtual networks.
You can divide that IP address space into subnets and allocate part of the defined address space to each named subnet.
You can use the name resolution service that's built in to Azure. 
You can also configure the virtual network to use an internal or an external DNS server.

### 2. Internet Communications
A VM in Azure can connect to the internet by default.
You can connect via the Azure CLI, Remote Desktop Protocol, or Secure Shell.

### 3. Communicate between Azure resources
Enable Azure resources to communicate securely with each other. 
1. **Virtual Networks** - Can connect to VMs and other Azure resources
2. **Service Endpoints** - Connect to other Azure resource types like Azure SQL databases and storage accounts. Helps you link multiple Azure resources to virtual networks to improve security and provide optimal routing between resources.

### 4. Communicate with on-premise resources
Link on-premise and Azure resources
Three mechanisms to achieve this connectivity.
1. **Point-to-site virtual private network** 
    The client computer initiates an encrypted VPN connection to connect that computer to the Azure virtual network.
2. **Site-to-site virtual private network** 
   Links your on-premise VPN device or gateway to the Azure VPN gateway in a virtual network. Azure devices can appear as being on the local network. 
3. **Azure ExpressRoute** 
   Provides a dedicated private connectivity to Azure that doesn't travel over the internet. Provides greater bandwidth and even higher level of security. 

### 5. Route network traffic
Azure routes traffic between subnets on any connected virtual networks, on-premise networks, and the internet. 
You can control routing and override those settings - 
1. **Route Tables** 
   Allows you to define rules about how traffic should be directed.
2. **Border Gateway Protocol**  
   Border Gateway Protocol (BGP) works with Azure VPN gateways, Azure Route Server, or ExpressRoute to propagate on-premises BGP routes to Azure virtual networks.

### 6. Filter network traffic
Enabled you to filter network traffic between subnets by using -
1. **Network security groups**
   A network security group is an Azure resource that can contain multiple inbound and outbound security rules. 
   You can define these rules to allow or block traffic, based on factors such as source and destination IP address, port, and protocol.
2. **Network Virtual Appliances**
   A network virtual appliance carries out a particular network function, such as running a firewall or performing wide area network (WAN) optimization.
   
# Connect Virtual Networks
You can link virtual networks together by using virtual network _peering_. Peering enables resources in each virtual network to communicate with each other. These virtual networks can be in separate regions, which allows you to create a global interconnected network through Azure.

![[Pasted image 20220605235324.png]]
\.
\.


# Virtual Network Settings
When you create an Azure virtual network, you configure a number of basic settings. You'll have the option to configure advanced settings, such as multiple subnets, distributed denial of service (DDoS) protection, Bastion host, Azure firewall, service endpoints, and use of a NAT gateway.

- ![[Pasted image 20220606001633.png]]
- **Subscription** This option only applies if you have multiple subscriptions to choose from.
- **Resource group** Like any other Azure resource, a virtual network needs to exist in a resource group. You can either select an existing resource group or create a new one.
- **Network name** The network name must be unique in your subscription, but it doesn't need to be globally unique. Make the name a descriptive one that's easy to remember and identified from other virtual networks.
- **Region** Select the region where you want the virtual network to exist.
![[Pasted image 20220606001643.png]]
- **Address space** When you set up a virtual network, you define the internal address space in Classless Interdomain Routing (CIDR) format. This address space needs to be unique within your subscription and any other networks that you connect to.
- **Subnet** Within each virtual network address range, you can create one or more subnets that partition the virtual network's address space. Routing between subnets will then depend on the default traffic routes. You also can define custom routes. Alternatively, you can define one subnet that encompasses all the virtual networks' address ranges.
- **Service endpoints** Here, you enable service endpoints. Then you select from the list which Azure service endpoints you want to enable. Options include Azure Cosmos DB, Azure Service Bus, Azure Key Vault, and so on.
- **NAT gateway** A NAT gateway is a fully managed and highly resilient Network Address Translation (NAT) service. You can configure a subnet to use a static outbound IP address when accessing the internet. For more information about NAT gateway, see [Azure Virtual Network NAT overview](https://docs.microsoft.com/en-us/azure/virtual-network/nat-gateway/nat-overview)
![[Pasted image 20220606001650.png]]
- **BastionHost** You can select to enable or disable Azure Bastion in your virtual network. Azure Bastion service provides a secure and seamless RDP/SSH connectivity to your virtual machines directly in the Azure portal over SSL. For more information on Azure Bastion, see [Azure Bastion overview](https://docs.microsoft.com/en-us/azure/bastion/bastion-overview).
- **DDoS Protection Standard** You can select to enable or disable Standard DDoS protection. The Standard DDoS protection is a premium service. For more information on Standard DDoS protection, see [Azure DDoS protection Standard overview](https://docs.microsoft.com/en-us/azure/virtual-network/ddos-protection-overview).
- **Firewall** You can enable or disable Azure Firewall. Azure Firewall service is managed cloud-based network security service that protects your Azure Virtual Network resources. For more information on Azure Firewall, see [Azure Firewall overview](https://docs.microsoft.com/en-us/azure/firewall/overview)