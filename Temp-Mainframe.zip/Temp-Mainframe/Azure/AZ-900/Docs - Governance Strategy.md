# Role-Based Access Control (RBAC)
 Azure role-based access control (Azure RBAC) helps you manage who has access to Azure resources, what they can do with those resources, and what areas they have access to.
 
Azure RBAC is an authorization system built on [Azure Resource Manager](https://docs.microsoft.com/en-us/azure/azure-resource-manager/management/overview) that provides fine-grained access management of Azure resources.