---
date: 2024-06-05
project:
  - AZ104
technology:
  - CloudProvider
  - Azure
type:
  - KBA
tags:
  - azure
  - entraid
---

#  Entra ID
![[Microsoft Entra Product Family.svg|100]]
## Microsoft Entra Connect Sync
Microsoft Entra Connect Sync (formerly Azure AD Connect) is a tool that enables organizations to synchronize on-premises Active Directory (AD) with Azure Active Directory (Azure AD). 
- It ensures that user identities, credentials, and group memberships are consistently available across both on-premises and cloud environments.

## Microsoft Entra Cloud Sync

Microsoft Entra Cloud Sync is a lightweight synchronization service designed to keep on-premises directories, such as Active Directory (AD), in sync with Microsoft Entra ID (formerly Azure Active Directory). 
- It provides a cloud-based alternative to the traditional Microsoft Entra Connect , offering scalability, simplicity, and flexibility, especially for hybrid identity environments.
![](https://learn.microsoft.com/en-us/entra/identity/hybrid/cloud-sync/media/concept-how-it-works/provisioning-4.png)
## Branding
- Get your own domain name.
- By default the tenant name ends with `.onmicrosoft.com`
## Users
- Cloud Accounts
- Hybrid Accounts
- Guests
- External Users
- Can perform bulk operations on users.
	- Creations
	- Deletion
	- Invitation
	- Downloads
- Can invite guest users. Azure B2B
- Reset their own passwords.
	- [Self-service password reset deep dive](https://learn.microsoft.com/en-us/entra/identity/authentication/concept-sspr-howitworks)
## Groups
1. Security Group
2. Microsoft 365 Group
### Type of membership 
1. Assigned
2. Dynamic (Require P1/P2 for the user)
	1. User
	2. Devices
## Administrative Units
> Provide granular admin privileges to selected users over particular Entra ID resources. 
Like a Helpdesk support only needs password reset privileges nothing more. 
- Can be created via UI or PowerShell
- Groups can be added to AU as an object. But the members inside the group are not automatically part of the AU.
- Admins in AU needs to have P1 license. 
## Devices
> Join devices to Entra ID
- User can join devices
- User can register devices.
- Enable `Require Multifactor Authentication`
- Local Admin settings.
### Microsoft Entra Joined Devices
Administrators can secure and control  joined devices using Mobile Device Management (MDM) tools like Microsoft Intune or in co-management scenarios using Microsoft Configuration Manager. 
- These tools provide a means to enforce organization-required configurations like:
	- Requiring storage to be encrypted
	- Password complexity
	- Software installation
	- Software updates

- Methods to join 
	- Windows Autopilot
	- Self-Service
	- [Bulk enrollment](https://learn.microsoft.com/en-us/mem/intune/enrollment/windows-bulk-enroll)
# Role Based Access Control (RBAC)
Restricting access to users based on role.
> Just Enough Access

![[RBAC-GoodNotes.png]]
1. Security Principal (Who?)
	- Users
	- Groups
	- Service Principals
	- Managed Identities
2. Role Definition (What?)
		In JSON `permission = actions - nonActions`
		Non-actions take preference over actions.
	- Owner
	- Contributor
	- Reader
	- User Admin
3. Scope (Where?)
	- Management Group
	- Subscription
	- Resource Group
	- Resource
4. Assignment (How?)
	- Direct
	- Group
	- Rule Based

[[Docs - Role-Based Access Control]]
## Custom Roles
Custom roles can be shared between subscriptions that trust the same Microsoft Entra tenant. There is a limit of 5,000 custom roles per tenant.
[Azure custom roles](https://learn.microsoft.com/en-us/azure/role-based-access-control/custom-roles)
# Regions
- All regions have 3 Availability Zones
- Region Pairs
- Some regions are dedicated to specific sovereign entities
# Subscriptions and Management Group
> Subscription are billing units for Azure resources. 
![](https://learn.microsoft.com/en-us/azure/governance/media/mg-org-sub.png)

Major parts - 
1. [[Azure-MindMap - Overview#Role Based Access Control (RBAC|RBAC]]
2. Policy
3. Budget

[Azure subscription limits and quotas](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/azure-subscription-service-limits)
By understanding and effectively using subscriptions, organizations can achieve better governance, cost management, and resource allocation.
Types - 
1. Free Trial
2. Pay-As-You-Go
3. Enterprise Agreement
4. Visual Studio Subscription
# Policy
> Assesses compliance by comparing resource properties to business rules defined in JSON format. These are known as policy definitions.
[Overview of Azure Policy](https://learn.microsoft.com/en-us/azure/governance/policy/overview)

![[02 Knowledge/Microsoft/Azure/AZ-104/Azure-Policy-Draw.md#^group=De8VFTlVW_lIPYbSR1tB2]]
- [Policy Objects](https://learn.microsoft.com/en-us/azure/governance/policy/overview#azure-policy-objects)
## Resource Evaluation Events
![[02 Knowledge/Microsoft/Azure/AZ-104/Azure-Policy-Draw.md#^group=BlQKVJkVgj5GkWWoNhVfv|resource-policy-evaluation-events]]

## Control the response to an evaluation
- Deny the resource change
- Log the change to the resource
- Alter the resource before the change
- Alter the resource after the change
- Deploy related compliant resources
- Block actions on resources

# Tagging
- Resources don't inherit the tags you apply to a resource group or a subscription.


| Tag type       | Examples                                                                                           | Description                                                                                                                                               |
| -------------- | -------------------------------------------------------------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------- |
| Functional     | `app` = `catalogsearch1`   <br>`webserver` = `apache`  <br>`env` = `prod`  <br>`region` = `eastus` | Categorizes resources by their purposes within a workload, the environment and region they're deployed to, or other functionality and operational details |
| Classification | `confidentiality` = `private` <br>`SLA` = `24hours`                                                | Classifies a resource by how it's used and the policies that apply to it                                                                                  |
| Accounting     | `department` = `finance`  <br>`program` = `business` <br>`region` = `northamerica`                 | Associates a resource with specific groups within an organization for billing purposes                                                                    |
| Purpose        | `businessprocess` = `support` <br>`businessimpact` = `moderate` <br>`revenueimpact` = `high`       | Aligns resources to business functions to better support investment decisions                                                                             |
# Resource Group
> Resource groups are logical containers for grouping multiple resources together. 

[Manage resource groups - Azure portal](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/manage-resource-groups-portal)
- A resource group should group all resources that share a similar or same life cycle
- Resource can belong to only single Resource Group.
- Resources can be moved from the group anytime.
- RG metadata is stored in the same region where the group was created.
- Resources in a RG can be deployed in multiple regions.
- If the resource group's region is temporarily unavailable, then resources in the group cannot be updated since the metadata is unavailable. However, resources deployed in other regions will continue to function as expected, with the caveat that they cannot be updated or managed.
- Limitations on moving resources.
	- Resource type - Should support movement.
	- Resource state - Should support movement.
	- Resource Locks - Active or not.
	- Dependencies - Does it need or is needed by another resource.
	- Regional Restrictions
	- Resource GUID
	- Target Resource Group quotas. 
```PowerShell
New-AzResourceGroup -Name RG01 -Location "West Europe"
```

## Resource Locks
Prevent from accidental user deletion or modification.
- CanNotDelete
- ReadOnly
[Protect your Azure resources with a lock](https://learn.microsoft.com/en-us/azure/azure-resource-manager/management/lock-resources?tabs=json)

**Lock Inheritance** - When you apply a lock at a parent scope, all resources within that scope  inherit the same lock. 

Locks only apply to control plane operations and not data plane operations. 
Meaning it can only lock operations like - 
- Creating or deleting resource
- Modifying the configuration of resource
- Changing the settings of a resource.
But can not lock - 
- Uploading or downloading data from storage.
- Modifying data in database.

**Who can create locks?**
- Owner
- User Access Administrator
# Cost Management
Azure Cost Management is a suite of tools provided by Microsoft Azure to help users and organizations manage and optimize their cloud spending.
[Overview of Cost Management](https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/overview-cost-management)

**Cost Management Scopes** - 
- Management Groups
- Subscriptions
- Resource Groups

**Cost Management Roles** - 
- Owner
- Contributor
- Reader
- Cost Management Contributor
- Cost Management Reader
## Cost Analysis
![](https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/media/reporting-get-started/cost-analysis.png)
- Visualize and Analyze Costs
- Share Cost Views
- View Aggregated Costs
- Estimate Future Costs
- Create and Manage Budgets
- Isolate Spending Irregularities.

**Export Reporting Data** - CSV, PNG, Excel

**Scheduled Reports** - Automatically publish your billing data to a storage account on daily, weekly, or monthly basis.  

## Cost Alerts
There are three main types of cost alerts: budget alerts, credit alerts, and department spending quota alerts.
- **Budget alerts** notify you when spending, based on usage or cost, reaches or exceeds the amount defined in the alert condition of the budget. 
- **Credit alerts** are generated automatically at 90% and at 100% of your Azure Prepayment credit balance.
- **Department spending quota alerts** notify you when department spending reaches a fixed threshold of the quota.

## Budgets
They help you proactively inform others about their spending to manage costs and monitor how spending progresses over time.
[Create and manage budgets](https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/tutorial-acm-create-budgets?tabs=psbudget)
![](https://learn.microsoft.com/en-us/azure/cost-management-billing/costs/media/tutorial-acm-create-budgets/budgets-cost-management.png)

- Alerts based on actual cost and forecasted cost.
- Notifications are triggered. Resources aren't affected.
- Cost and usage data is typically available within 8-24 hours and budgets are evaluated against these costs every 24 hours.
- Budgets reset automatically at the end of a period.
- Trigger an action group.

## Advisor
 It analyzes your resource configuration and usage telemetry and then recommends solutions that can help you improve the cost effectiveness, performance, reliability, and security of your Azure resources.
[Introduction to Azure Advisor](https://learn.microsoft.com/en-us/azure/advisor/advisor-overview)
The recommendations are divided into five categories:
1. Reliability
2. Security
3. Performance
4. Cost
5. Operational Excellence
![](https://learn.microsoft.com/en-us/azure/advisor/media/advisor-overview/advisor-dashboard-overview-m.png)

You can access Advisor recommendations as Owner, Contributor, or Reader of a subscription, Resource Group, or Resource.

## Azure Reservations
Save money by committing 1 Year or 3 Year plans for various Azure resources.
- Opt for reservations when you have workloads that run continuously and are highly stable, with no anticipated changes to the instance type, instance family, or region. 
- When fully utilized, reservations provide the greatest savings.

## Azure Savings Plan
Azure savings plan reduce compute usage costs by making an hourly spend commitment for 1 or 3 years.
- If you have consistent compute spend, but your use different resources which makes Azure reservations infeasible, buying a savings plan gives you the ability to reduce your costs.

# Storage
![[Book - Understanding and Managing Storage]]

## Securing Storage
- [Configure Azure Storage firewalls and virtual networks](https://learn.microsoft.com/en-us/azure/storage/common/storage-network-security?tabs=azure-portal#change-the-default-network-access-rule)
- [Use private endpoints - Azure Storage](https://learn.microsoft.com/en-us/azure/storage/common/storage-private-endpoints)

- Only applications that request data over the specified set of networks or through the specified set of Azure resources can access a storage account. 
- You can limit access to your storage account to requests that come from specified IP addresses, IP ranges, subnets in an Azure virtual network, or resource instances of some Azure services.
## Storage Access Keys
- 2 keys are generated per storage account.
## Shared Access Signature
A shared access signature (SAS) provides secure delegated access to resources in your storage account. With a SAS, you have granular control over how a client can access your data.

### Type of Shared Access Signatures  - 
1. **User Delegation SAS**
   This is a SAS token that is secured by AD credentials. 
2. **Service SAS**
   A service SAS delegates access to a resource in only one of the Azure Storage services: Blob storage, Queue storage, Table storage, or Azure Files.
3. **Account SAS**
   An account SAS delegates access to resources in one or more of the storage services. 
   All of the operations available via a service or user delegation SAS are also available via an account SAS.
### Forms of Shared Access Signatures - 
1. Ad hoc SAS
2. Service SAS with stored access policy
### Storage access policies
- A stored access policy provides an additional level of control over service-level shared access signatures (SAS) on the server side. 
- Policy serves to group SAS and to provide additional restrictions for SAS. 
- You can use a stored access policy to change the start time, expiry time, or permissions for a SAS, or to revoke it after it has been issued.

## AzCopy
AzCopy is a command-line utility that you can use to copy blobs or files to or from a storage account. AzCopy V10 is the currently supported version of AzCopy.

You can provide authorization credentials by using 
1. Microsoft Entra ID
2. Shared Access Signature (SAS) token
## Azure File Sync Service 
Azure File Sync is a service that can synchronize the data from on-premises file shares with Azure Files.
- Make Windows Server local cache for Azure Files.
- Use any of the supported protocols - 
	- Server Message Block
	- Network File System
	- File Transfer Protocol over TLS

## Disks
**Managed Disks**: are managed by Microsoft Azure and you don't need any storage account while created new disk. Since the storage account is managed by Azure you do not have full control of the disks that are being created.

**Un-managed Disks**: = is something which requires you to create a storage account before you create any new disk. Since, the storage account is created and owned by you, you have full control over all the data that is present on your storage account. Additionally, you also need to take care of encryption, data recovery plans etc.
[Azure Managed vs Unmanaged disks](https://buildwindows.wordpress.com/2017/05/31/azure-managed-vs-unmanaged-disks-the-choice/)

### Disk Types
- Ultra Disks
- Premium SSD v2
- Premium SSDs 
- Standard SSDs
- Standard HDDs 

|                    | Ultra Disk             | Premium SSD v2                           | Premium SSD                                    | Standard SSD                                                   | Standard HDD                            |
| ------------------ | ---------------------- | ---------------------------------------- | ---------------------------------------------- | -------------------------------------------------------------- | --------------------------------------- |
| Disk type          | SSD                    | SSD                                      | SSD                                            | SSD                                                            | HDD                                     |
| Scenario           | IO-intensive workloads | low latency and high IOPS and throughput | Production and performance sensitive workloads | Web servers, lightly used enterprise applications and dev/test | Backup, non-critical, infrequent access |
| Max disk size      | 65,536 GiB             | 65,536 GiB                               | 32,767 GiB                                     | 32,767 GiB                                                     | 32,767 GiB                              |
| Max throughput     | 10,000 MB/s            | 1,200 MB/s                               | 900 MB/s                                       | 750 MB/s                                                       | 500 MB/s                                |
| Max IOPS           | 400,000                | 80,000                                   | 20,000                                         | 6,000                                                          | 2,000, 3,000*                           |
| Usable as OS Disk? | No                     | No                                       | Yes                                            | Yes                                                            | Yes                                     |
## Azure Disk Encryption
- It uses the [BitLocker](https://learn.microsoft.com/en-us/windows/security/operating-system-security/data-protection/bitlocker/) feature of Windows to provide volume encryption for the OS and data disks of Azure virtual machines (VMs).
- It is integrated with [Azure Key Vault](https://learn.microsoft.com/en-us/azure/key-vault/) to help you control and manage the disk encryption keys and secrets.

# Virtual Machines
Parts of a VM and how they're billed

| Resource                                                | Description                                                                                                                                                                     | Cost                                                                                      |
| ------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ----------------------------------------------------------------------------------------- |
| Virtual network                                         | For giving your virtual machine the ability to communicate with other resources                                                                                                 | [Virtual Network pricing](https://azure.microsoft.com/pricing/details/virtual-network/)   |
| A virtual Network Interface Card (NIC)                  | For connecting to the virtual network                                                                                                                                           | There's no separate cost for NICs. However, there's a limit.                              |
| A private IP address and sometimes a public IP address. | For communication and data exchange on your network and with external networks                                                                                                  | [IP Addresses pricing](https://azure.microsoft.com/pricing/details/ip-addresses/)         |
| Network security group (NSG)                            | For managing the network traffic to and from your VM.                                                                                                                           | No additional charges                                                                     |
| OS Disk and possibly separate disks for data.           | It's a best practice to keep your data on a separate disk from your operating system, in case you ever have a VM fail, you can detach the data disk, and attach it to a new VM. | [Managed Disks pricing page](https://azure.microsoft.com/pricing/details/managed-disks/). |

## Virtual Machine Sizes

| Type                     | Series         |
| ------------------------ | -------------- |
| General Purpose          | A, B, D, DC    |
| Compute-Optimised        | F, FX          |
| Memory-Optimised         | E, Eb, EC, M   |
| Storage-Optimised        | L              |
| GPU                      | NC, ND, NG, NV |
| High Performance Compute | H, HC, HX      |
## Spot Virtual Machines
Azure offers the ability to buy unused compute capacity for significantly reduced costs.
When configuring spot instances, you define an eviction policy based on capacity and the maximum price you are willing to pay for the VM.

## Networking for Virtual Machine

You create these resources to support communication with a virtual machine:
- Network interfaces
- IP addresses
- Virtual network and subnets

Additionally, consider these optional resources:
- Network security groups
- Load balancers

### Network Interfaces
A network interface (NIC) enables an Azure virtual machine (VM) to communicate with internet, Azure, and on-premises resources.
### IP Addresses
- **Public IP addresses** - Used to communicate inbound and outbound (without network address translation (NAT)) with the Internet and other Azure resources not connected to a virtual network. Assigning a public IP address to a NIC is optional. Public IP addresses have a nominal charge, and there's a maximum number that can be used per subscription.
- **Private IP addresses** - Used for communication within a virtual network, your on-premises network, and the Internet (with NAT). At least one private IP address must be assigned to a VM. 
### Network Security Groups
A network security group (NSG) contains a list of Access Control List (ACL) rules that allow or deny network traffic to subnets, NICs, or both. 
- NSGs can be associated with either subnets or individual NICs connected to a subnet. 
- When an NSG is associated with a subnet, the ACL rules apply to all the VMs in that subnet. 
- Traffic to an individual NIC can be restricted by associating an NSG directly to a NIC.

NSGs contain two sets of rules, inbound and outbound. The priority for a rule must be unique within each set.

Each rule has properties of:
- Protocol
- Source and destination port ranges
- Address prefixes
- Direction of traffic
- Priority
- Access type

### Azure NAT 
Azure NAT Gateway simplifies outbound-only Internet connectivity for virtual networks. When configured on a subnet, all outbound connectivity uses your specified static public IP addresses. Outbound connectivity is possible without load balancer or public IP addresses directly attached to virtual machines.

### Azure Bastion
- Azure Bastion is deployed to provide secure management connectivity to virtual machines in a virtual network. 
- Azure Bastion Service enables you to securely and seamlessly RDP & SSH to the VMs in your virtual network. 
- Connections are made directly from the Azure portal, without the need of an extra client/agent or piece of software. 

## Fault Domain vs Update Domain
Each virtual machine in your availability set has an update domain and fault domain assigned. **Fault domains** indicate the group of virtual machines that share common power source and network switch limiting the impact of potential physical hardware failures, network outages, or power interruptions. **Update domains** indicate the group of virtual machines and underlying physical hardware that can be rebooted at the same time ensuring availability of some virtual machines during a planned maintenance.
![](https://media.licdn.com/dms/image/v2/D4D12AQH7n1U96a_Ruw/article-inline_image-shrink_1000_1488/article-inline_image-shrink_1000_1488/0/1682607372337?e=1729728000&v=beta&t=b4LvWu91TbiUf4zYzWr6XwpAmtXYGGg4mUsYSjjmyro)

## Scale Set
Azure Virtual Machine Scale Sets let you create and manage a group of load balanced VMs. The number of VM instances can automatically increase or decrease in response to demand or a defined schedule.

Benefits
- Easy to create and manage multiple VMs
- Provides high availability and application resiliency by distributing VMs across availability zones or fault domains
- Allows your application to automatically scale as resource demand changes
- Works at large-scale

## Availability Sets
An availability set is a logical feature you can use to ensure a group of related virtual machines are deployed together.
[[Docs - Virtual Machine Availability]]

## Azure Automation State Configuration
Allows you to write, manage, and compile PowerShell Desired State Configuration (DSC) configurations for nodes in any cloud or on-premises datacenter.

## Azure Machine Configuration
Azure Policy's machine configuration feature provides native capability to audit or configure operating system settings as code for machines running in Azure and hybrid Arc-enabled machines. You can use the feature directly per-machine, or orchestrate it at scale by using Azure Policy.

# Azure Containers
Azure Container Instances allow you to package, deploy and manage cloud applications without having to manage the underlying infrastructure.
- **Azure Container Apps**
  Azure Container Apps enables you to build serverless microservices based on containers. Azure Container Apps doesn't provide direct access to the underlying Kubernetes APIs.
- **Azure App Service**
  Fully managed hosting for web applications including websites and web APIs.
- **Azure Container Instances**
  Provides a single pod of Hyper-V isolated containers on demand
- **Azure Kubernetes Service**
  Provides a fully managed Kubernetes option in Azure
- **Azure Functions**
  Serverless Functions-as-a-Service (FaaS) solution. Optimized for ephemeral functions.
- **Azure Spring Apps**
- **Azure Red Hat OpenShift**

# Azure App Service
Azure App Service is an HTTP-based service for hosting web applications, REST APIs, and mobile back ends. You can develop in your favorite language, be it .NET, .NET Core, Java, Node.js, PHP, and Python. Applications run and scale with ease on both Windows and Linux-based environments.

# Networking
## VNet
- A VNet in Azure is a representation of your network in the cloud that is used to connect resources such as virtual machines and other services to each other.
- Defined by one or more IPv4 CIDR ranges.
	- Always loose 5 IPs.
	- `.0` - Network Address
	- `.1` - Gateway
	- `.2` - DNS
	- `.3` - DNS
	- `.255` - Broadcast
- To allow resources in two different VNets to talk to each other, you would need to connect the VNets using VNet peering.
- All resources deployed to a VNet must reside in the same region.
- VNet cannot be part of more than one subscription. 

## VNet Peering
Azure supports the following types of peering:
- **Virtual network peering**: Connecting virtual networks within the same Azure region.
- **Global virtual network peering**: Connecting virtual networks across Azure regions.

Options on the portal for VNet Peering
**Traffic to a remote VNet**: Allows communication between two VNets, as this allows the remote VNet address space to be included as a part of the virtual-network tags.
**Traffic forwarded from a remote VNet**: Allows traffic forwarded by a VNet appliance in a VNet that did not originate from the original VNet to flow via VNet peering to the other VNet.
**Virtual network gateway or Route Server**: This is relevant when a VNet gateway is deployed to the VNet and needs traffic from the peered VNet to flow through the gateway.
**Virtual network deployment model**: Select which deployment model you want with the peered VNet. This will either be classic or the standard resource manager method.
## Routing
### System Routes
- Azure automatically creates system routes and assigns the routes to each subnet in a virtual network. 
- You can't create system routes, nor can you remove system routes, but you can override some system routes with custom routes. 
### Default Routes
- Azure creates default system routes for each subnet, and adds more optional default routes to specific subnets, or every subnet, when you use specific Azure capabilities.
- Each route contains an address prefix and next hop type. When traffic leaving a subnet is sent to an IP address within the address prefix of a route, the route that contains the prefix is the route Azure uses.

|Source|Address prefixes|Next hop type|
|---|---|---|
|Default|Unique to the virtual network|Virtual network|
|Default|0.0.0.0/0|Internet|
|Default|10.0.0.0/8|None|
|Default|172.16.0.0/12|None|
|Default|192.168.0.0/16|None|
|Default|100.64.0.0/10|None|
Depending on the capability, Azure adds optional default routes to either specific subnets within the virtual network, or to all subnets within a virtual network.

| Source                  | Address prefixes                                                                         | Next hop type                 | Subnet that route is added to                      |
| ----------------------- | ---------------------------------------------------------------------------------------- | ----------------------------- | -------------------------------------------------- |
| Default                 | Unique to the virtual network example: 10.1.0.0/16                                       | VNet peering                  | All                                                |
| Virtual network gateway | Prefixes advertised from on-premises via BGP, or configured in the local network gateway | Virtual network gateway       | All                                                |
| Default                 | Multiple                                                                                 | VirtualNetworkServiceEndpoint | Only the subnet a service endpoint is enabled for. |
### User Defined Route Table
- User-defined(static) routes override Azure's default system routes
- When you create a route table and associate it to a subnet, the table's routes are combined with the subnet's default routes. If there are conflicting route assignments, user-defined routes override the default routes.
- Next Hop Types
	- **Virtual appliance**: A virtual appliance is a virtual machine that typically runs a network application, such as a firewall.
	- **Virtual network gateway**: Specify when you want traffic destined for specific address prefixes routed to a virtual network gateway. 
		- The virtual network gateway must be created with type VPN You can't specify a virtual network gateway created as type ExpressRoute in a user-defined route because with ExpressRoute, you must use BGP for custom routes. 
		- You can't specify Virtual Network Gateways if you have VPN and ExpressRoute coexisting connections either.
	- **None**: Specify when you want to drop traffic to an address prefix, rather than forwarding the traffic to a destination.
	- **Virtual network**: Specify the Virtual network option when you want to override the default routing within a virtual network
	- **Internet**: Specify the Internet option when you want to explicitly route traffic destined to an address prefix to the Internet, or if you want traffic destined for Azure services with public IP addresses kept within the Azure backbone network
### Subnets
Reserved IPs in a subnet `10.1.1.0/24` - 
- `10.1.1.0`: This is reserved for the network address.
- `10.1.1.1`: This is reserved for the default gateway.
- `10.1.1.2` and `10.1.1.3`: These are reserved by Azure to map DNS IPs to the VNet space.
- `10.1.1.255`: This is reserved for broadcast traffic.
## Service Endpoints
- Virtual Network (VNet) service endpoint provides secure and direct connectivity to Azure services over an optimized route over the Azure backbone network.
- Service Endpoints enables private IP addresses in the VNet to reach the endpoint of an Azure service without needing a public IP address on the VNet.
- Purpose: Provides secure access to Azure services over Azure's backbone network by extending your virtual network's private address space.
- Traffic Flow: Traffic still uses the public IP addresses of Azure services but is routed through Azure's backbone network.
- Use Case: Useful for securing traffic to Azure services (like Azure Storage or SQL Database) and for controlling traffic flow through network security groups (NSGs).
- Security: Provides access control by ensuring that traffic to Azure services is only allowed from your virtual network and using NSGs to restrict traffic.
- Network Configuration: Does not require DNS changes as it uses the service’s public IP addresses but restricts access to the service to only your virtual network.
## Azure Private Link
Network interface for PaaS services.
- Purpose: Provides a private IP address in your virtual network for Azure services, allowing for secure and private connectivity.
- Traffic Flow: Traffic flows entirely within the Azure backbone network, avoiding exposure to the public internet.
- Use Case: Ideal for accessing Azure PaaS services (like Azure Storage, SQL Database) and Azure-hosted services privately.
- Security: Offers network isolation by using a private IP address, enhancing security by ensuring that the service is accessible only from your virtual network.
- Network Configuration: Requires DNS configuration to map the service’s private endpoint to its private IP address.
![](https://learn.microsoft.com/en-us/azure/private-link/media/private-link-service-overview/private-link-service-workflow.png)

## Azure DNS
The Domain Name System (DNS) is responsible for translating (resolving) a service name to an IP address. Azure DNS provides DNS hosting, resolution, and load balancing for your applications using the Microsoft Azure infrastructure.

Azure DNS supports both internet-facing DNS domains and private DNS zones, and provides the following services:

- **[Azure Public DNS](https://learn.microsoft.com/en-us/azure/dns/public-dns-overview)** is a hosting service for DNS domains. By hosting your domains in Azure, you can manage your DNS records by using the same credentials, APIs, tools, and billing as your other Azure services.
- **[Azure Private DNS](https://learn.microsoft.com/en-us/azure/dns/private-dns-overview)** is a DNS service for your virtual networks. Azure Private DNS manages and resolves domain names in the virtual network without the need to configure a custom DNS solution.
- **[Azure DNS Private Resolver](https://learn.microsoft.com/en-us/azure/dns/dns-private-resolver-overview)** is a service that enables you to query Azure DNS private zones from an on-premises environment and vice versa without deploying VM based DNS servers.
- **[Azure Traffic Manager](https://learn.microsoft.com/en-us/azure/traffic-manager/traffic-manager-overview)** is a DNS-based traffic load balancer. This service allows you to distribute traffic to your public facing applications across the global Azure regions.

## Network Security Group
A network security group contains security rules that allow or deny inbound network traffic to, or outbound network traffic from, several types of Azure resources.
## Azure Firewall
Azure Firewall is a cloud-native network firewall security service that provides  threat protection for cloud workloads.
- **Standard Firewall**
  Azure Firewall Standard provides L3-L7 filtering and threat intelligence feeds directly from Microsoft Cyber Security.
- **Premium Firewall**
  Azure Firewall Premium provides advanced capabilities include signature based IDPS to allow rapid detection of attacks by looking for specific patterns.
- **Basic Firewall**
  Azure Firewall Basic is intended for small and medium size (SMB) customers to secure their Azure cloud environments. Azure Firewall Basic is like Firewall Standard, but has limitations.
## Azure Bastion
Azure Bastion is a fully managed PaaS service to securely connect to virtual machines via private IP address. 
- It provides RDP/SSH connectivity to virtual machines over TLS from the Azure portal, or via the native SSH or RDP client. 
- Using Azure Bastion protects your virtual machines from exposing RDP/SSH ports to the outside world, while still providing secure access using RDP/SSH.
![](https://learn.microsoft.com/en-us/azure/bastion/media/bastion-overview/architecture.png)

## Load Balancing Services
Here are the main load-balancing services currently available in Azure:

- **Azure Front Door** is an application delivery network that provides global load balancing and site acceleration service for web applications. It offers Layer 7 capabilities for your application like SSL offload, path-based routing, fast failover, and caching to improve performance and high availability of your applications.
    ![](https://azure.microsoft.com/en-us/blog/wp-content/uploads/2022/03/4282450a-9abc-461f-8a85-695c3d36d7b6.webp)
    
- **Traffic Manager** (Global Service) is a DNS-based traffic load balancer that enables you to distribute traffic optimally to services across global Azure regions, while providing high availability and responsiveness. Because Traffic Manager is a DNS-based load-balancing service, it load balances only at the domain level. For that reason, it can't fail over as quickly as Azure Front Door, because of common challenges around DNS caching and systems not honoring DNS TTLs.
    ![](https://miro.medium.com/v2/resize:fit:720/format:webp/1*gShU92Rfl-RiebUvV1ucBQ.png)
    
- **Application Gateway** is a web traffic (OSI layer 7) load balancer that enables you to manage traffic to your web applications. Application Gateway can make routing decisions based on additional attributes of an HTTP request, for example URI path or host headers.
    ![](https://learn.microsoft.com/en-us/azure/application-gateway/media/application-gateway-url-route-overview/figure1-720.png)
    
- **Load Balancer**(Regional Service) is a high-performance, ultra-low-latency Layer 4 load-balancing service (inbound and outbound) for all UDP and TCP protocols. It's built to handle millions of requests per second while ensuring your solution is highly available. Load Balancer is zone redundant, ensuring high availability across availability zones. It supports both a regional deployment topology and a [cross-region topology](https://learn.microsoft.com/en-us/azure/load-balancer/cross-region-overview).
	![](https://learn.microsoft.com/en-us/azure/load-balancer/media/load-balancer-overview/load-balancer.png)
	**SKUs**
	- Standard
	- Basic
## Azure VPN Gateway
Azure VPN Gateway is a service that can be used to send encrypted traffic between an Azure virtual network and on-premises locations over the public Internet.

- Send encrypted traffic between an Azure virtual network and on-premises locations over the public Internet.
    - **Site-to-site connection:** A cross-premises IPsec/IKE VPN tunnel connection between the VPN gateway and an on-premises VPN device.
      ![](https://learn.microsoft.com/en-us/azure/vpn-gateway/media/design/multi-site.png)
    - **Point-to-site connection:** VPN over OpenVPN, IKEv2, or SSTP. This type of connection lets you connect to your virtual network from a remote location, such as from a conference or from home.
      ![](https://learn.microsoft.com/en-us/azure/vpn-gateway/media/vpn-gateway-howto-point-to-site-rm-ps/point-to-site-diagram.png)

- Send encrypted traffic between virtual networks.
    - **VNet-to-VNet:** An IPsec/IKE VPN tunnel connection between the VPN gateway and another Azure VPN gateway that uses a _VNet-to-VNet_ connection type. This connection type is designed specifically for VNet-to-VNet connections.
      ![](https://learn.microsoft.com/en-us/azure/vpn-gateway/media/vpn-gateway-howto-vnet-vnet-resource-manager-portal/vnet-vnet-diagram.png)
    - **Site-to-site connection:** An IPsec/IKE VPN tunnel connection between the VPN gateway and another Azure VPN gateway. This type of connection, when used in the VNet-to-VNet architecture, uses the _Site-to-site (IPsec)_ connection type, which allows cross-premises connections to the gateway in addition connections between VPN gateways.
- Configure a site-to-site VPN as a secure failover path for [ExpressRoute](https://learn.microsoft.com/en-us/azure/expressroute/expressroute-introduction).
	![](https://learn.microsoft.com/en-us/azure/vpn-gateway/media/design/expressroute-vpngateway-coexisting-connections-diagram.png)
## ExpressRoute
[[02 Knowledge/Microsoft/Azure/AZ-104/Docs - Azure ExpressRoute]]
Azure ExpressRoute provides a high-speed private connection to connect your on-premises networks to Microsoft cloud services.

# Azure Monitor
Azure Monitor is a monitoring solution for collecting, analyzing, and responding to monitoring data from cloud and on-premises environments.
- Azure Monitor collects and aggregates the data from every layer and component of a system.
- It stores it in a common data platform for consumption by a common set of tools that can correlate, analyze, visualize, and/or respond to the data.
![](https://learn.microsoft.com/en-us/azure/azure-monitor/media/overview/azure-monitor-high-level-abstraction-opt.svg)

## High Level Architecture
![](https://learn.microsoft.com/en-us/azure/azure-monitor/media/overview/overview-simple-20230707-opt.svg)
The diagram depicts the Azure Monitor system components:

- **[Data sources](https://learn.microsoft.com/en-us/azure/azure-monitor/data-sources)** are the types of resources being monitored.
    
- The data is **collected and routed** to the data platform. Clicking on the diagram shows these options, which are also called out in detail later in this article.
    
- The **[data platform](https://learn.microsoft.com/en-us/azure/azure-monitor/data-platform)** stores the collected monitoring data. Azure Monitor's core data platform has stores for metrics, logs, traces, and changes. System Center Operations Manager MI uses its own database hosted in SQL Managed Instance.
    
- The **consumption** section shows the components that use data from the data platform.
    
    - Azure Monitor's core consumption methods include tools to provide **insights**, **visualize**, and **analyze** data. The visualization tools build on the analysis tools and the insights build on top of both the visualization and analysis tools.
    - There are additional mechanisms to help you **respond** to incoming monitoring data.
- The **SCOM MI** path uses the traditional Operations Manager console that SCOM customers are already familiar with.
    
- Interoperability options are shown in the **integrate** section. Not all services integrate at all levels. SCOM MI only integrates with Power BI.